/**
 * Serviço para busca e gerenciamento de CEPs
 */
import { db } from './db';
import { ceps } from '@shared/schema';
import { eq, like, and, or, sql } from 'drizzle-orm';
import { storage } from './storage';

/**
 * Interface para informações de endereço completo baseado em um CEP
 */
export interface CepInfo {
  cep: string;
  logradouro: string;
  bairro?: string;
  cidade: string;
  estado: string;
  latitude?: string;
  longitude?: string;
}

/**
 * Busca informações de um CEP no banco de dados
 * @param cep CEP no formato XXXXX-XXX ou XXXXXXXX
 * @returns Informações do CEP se encontrado, ou undefined
 */
export async function findCepInDatabase(cep: string): Promise<CepInfo | undefined> {
  try {
    // Normalizar o CEP removendo qualquer caractere não numérico
    const normalizedCep = cep.replace(/\D/g, '');
    
    // Se não for um CEP válido (8 dígitos), retornar undefined
    if (normalizedCep.length !== 8) {
      console.log(`CEP inválido: ${cep} (normalizado: ${normalizedCep})`);
      return undefined;
    }
    
    // Formatar o CEP no padrão XXXXX-XXX
    const formattedCep = `${normalizedCep.substring(0, 5)}-${normalizedCep.substring(5)}`;
    
    console.log(`Buscando CEP: ${formattedCep} no banco de dados...`);
    
    // Buscar no banco de dados usando o storage
    const result = await storage.getCep(formattedCep);
    
    if (result) {
      console.log(`CEP encontrado: ${formattedCep} - ${result.logradouro}, ${result.cidade}`);
      return {
        cep: result.cep,
        logradouro: result.logradouro,
        bairro: result.bairro || undefined,
        cidade: result.cidade,
        estado: result.estado,
        latitude: result.latitude || undefined,
        longitude: result.longitude || undefined
      };
    }
    
    console.log(`CEP não encontrado: ${formattedCep}`);
    return undefined;
  } catch (error) {
    console.error('Erro ao buscar CEP:', error);
    return undefined;
  }
}

/**
 * Busca CEPs por cidade e estado
 * @param cidade Nome da cidade
 * @param estado Sigla do estado (SP, MG, etc.)
 * @returns Lista de CEPs encontrados
 */
export async function findCepsByCidade(cidade: string, estado: string): Promise<CepInfo[]> {
  try {
    const results = await storage.getCepsByCidade(cidade, estado);
    
    return results.map(result => ({
      cep: result.cep,
      logradouro: result.logradouro,
      bairro: result.bairro || undefined,
      cidade: result.cidade,
      estado: result.estado,
      latitude: result.latitude || undefined,
      longitude: result.longitude || undefined
    }));
  } catch (error) {
    console.error('Erro ao buscar CEPs por cidade:', error);
    return [];
  }
}

/**
 * Busca CEPs que correspondam a uma consulta de texto livre
 * @param query Texto de busca livre (logradouro, bairro, cidade, etc.)
 * @returns Lista de CEPs correspondentes
 */
export async function searchCeps(query: string): Promise<CepInfo[]> {
  try {
    const searchTerm = `%${query.toLowerCase()}%`;
    
    const results = await db.select().from(ceps).where(
      or(
        like(sql`LOWER(${ceps.logradouro})`, searchTerm),
        like(sql`LOWER(${ceps.bairro})`, searchTerm),
        like(sql`LOWER(${ceps.cidade})`, searchTerm),
        like(ceps.cep, searchTerm)
      )
    ).limit(20);
    
    return results.map(result => ({
      cep: result.cep,
      logradouro: result.logradouro,
      bairro: result.bairro || undefined,
      cidade: result.cidade,
      estado: result.estado,
      latitude: result.latitude || undefined,
      longitude: result.longitude || undefined
    }));
  } catch (error) {
    console.error('Erro ao pesquisar CEPs:', error);
    return [];
  }
}

/**
 * Formata um CEP para o padrão XXXXX-XXX
 * @param cep CEP (com ou sem formatação)
 * @returns CEP formatado
 */
export function formatCep(cep: string): string {
  // Remover caracteres não numéricos
  const digitsOnly = cep.replace(/\D/g, '');
  
  // Verificar se temos 8 dígitos
  if (digitsOnly.length === 8) {
    return `${digitsOnly.substring(0, 5)}-${digitsOnly.substring(5)}`;
  }
  
  // Retornar o valor original se não for possível formatar
  return cep;
}

/**
 * Verifica se uma string é um CEP válido (formato brasileiro)
 * @param text Texto a ser verificado
 * @returns true se for um CEP válido
 */
export function isCepFormat(text: string): boolean {
  // Padrão de CEP: 5 dígitos + hífen opcional + 3 dígitos
  const cepPattern = /^\d{5}[-]?\d{3}$/;
  return cepPattern.test(text);
}