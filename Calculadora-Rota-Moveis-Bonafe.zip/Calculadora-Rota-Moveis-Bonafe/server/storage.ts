import { users, ceps, routes, type User, type InsertUser, type Route, type InsertRoute, type Cep, type InsertCep } from "@shared/schema";
import { db } from "./db";
import { eq, and } from "drizzle-orm";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Métodos para rotas
  getRoute(id: number): Promise<Route | undefined>;
  getRoutesByUserId(userId: number): Promise<Route[]>;
  createRoute(route: InsertRoute): Promise<Route>;
  updateRoute(id: number, route: Partial<InsertRoute>): Promise<Route | undefined>;
  deleteRoute(id: number): Promise<boolean>;
  
  // Métodos para CEPs
  getCep(cep: string): Promise<Cep | undefined>;
  getCepsByCidade(cidade: string, estado: string): Promise<Cep[]>;
  createCep(cep: InsertCep): Promise<Cep>;
  createManyCeps(ceps: InsertCep[]): Promise<void>;
}

// Implementação em banco de dados PostgreSQL
export class DatabaseStorage implements IStorage {
  // Métodos para usuários
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  // Métodos para rotas
  async getRoute(id: number): Promise<Route | undefined> {
    const [route] = await db.select().from(routes).where(eq(routes.id, id));
    return route || undefined;
  }

  async getRoutesByUserId(userId: number): Promise<Route[]> {
    return await db.select().from(routes).where(eq(routes.userId, userId));
  }

  async createRoute(insertRoute: Omit<InsertRoute, 'paradas'> & { paradas?: string[] }): Promise<Route> {
    // Garantir que paradas seja um array válido
    const routeToInsert = {
      ...insertRoute,
      paradas: Array.isArray(insertRoute.paradas) ? insertRoute.paradas : []
    };
    
    const [route] = await db.insert(routes).values(routeToInsert).returning();
    return route;
  }

  async updateRoute(id: number, routeUpdate: Partial<Omit<InsertRoute, 'paradas'>> & { paradas?: string[] }): Promise<Route | undefined> {
    const [updatedRoute] = await db
      .update(routes)
      .set(routeUpdate)
      .where(eq(routes.id, id))
      .returning();
    return updatedRoute || undefined;
  }

  async deleteRoute(id: number): Promise<boolean> {
    const result = await db.delete(routes).where(eq(routes.id, id));
    return result.rowCount ? result.rowCount > 0 : false;
  }

  // Métodos para CEPs
  async getCep(cep: string): Promise<Cep | undefined> {
    // Normalizar o CEP removendo qualquer caractere não numérico
    const normalizedCep = cep.replace(/\D/g, '');
    if (normalizedCep.length !== 8) return undefined;
    
    const formattedCep = `${normalizedCep.substring(0, 5)}-${normalizedCep.substring(5)}`;
    
    const [result] = await db.select().from(ceps).where(eq(ceps.cep, formattedCep));
    return result || undefined;
  }

  async getCepsByCidade(cidade: string, estado: string): Promise<Cep[]> {
    return await db.select()
      .from(ceps)
      .where(and(
        eq(ceps.cidade, cidade),
        eq(ceps.estado, estado)
      ));
  }

  async createCep(insertCep: InsertCep): Promise<Cep> {
    const [cep] = await db.insert(ceps).values(insertCep).returning();
    return cep;
  }

  async createManyCeps(cepsToInsert: InsertCep[]): Promise<void> {
    // Processar em lotes para não sobrecarregar o banco de dados
    const batchSize = 100;
    for (let i = 0; i < cepsToInsert.length; i += batchSize) {
      const batch = cepsToInsert.slice(i, i + batchSize);
      await db.insert(ceps).values(batch).onConflictDoNothing();
    }
  }
}

// Usando a implementação com banco de dados
export const storage = new DatabaseStorage();