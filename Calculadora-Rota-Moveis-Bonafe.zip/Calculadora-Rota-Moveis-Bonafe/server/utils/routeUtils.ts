/**
 * Formata a distância e o tempo totais de uma rota
 * @param route - Rota do Google Directions API
 * @returns Objeto com distância e tempo formatados
 */
export function formatDistanceAndTime(route: any) {
  let distanceValue = 0;
  let durationValue = 0;

  // Somar distância e duração de todos os trechos
  for (const leg of route.legs) {
    distanceValue += leg.distance.value;
    durationValue += leg.duration.value;
  }

  // Formatar distância
  let distanciaTotal: string;
  if (distanceValue < 1000) {
    distanciaTotal = `${distanceValue} m`;
  } else {
    const km = distanceValue / 1000;
    distanciaTotal = `${km.toFixed(1)} km`;
  }

  // Formatar tempo
  let tempoTotal: string;
  if (durationValue < 60) {
    tempoTotal = `${durationValue} segundos`;
  } else if (durationValue < 3600) {
    const minutes = Math.round(durationValue / 60);
    tempoTotal = `${minutes} ${minutes === 1 ? 'minuto' : 'minutos'}`;
  } else {
    const hours = Math.floor(durationValue / 3600);
    const minutes = Math.round((durationValue % 3600) / 60);
    
    if (minutes === 0) {
      tempoTotal = `${hours} ${hours === 1 ? 'hora' : 'horas'}`;
    } else {
      tempoTotal = `${hours} ${hours === 1 ? 'hora' : 'horas'} e ${minutes} ${minutes === 1 ? 'minuto' : 'minutos'}`;
    }
  }

  return { distanciaTotal, tempoTotal };
}

/**
 * Formata as instruções de uma rota para exibição amigável
 * @param instructions - Instruções HTML da API do Google Maps
 * @returns Instruções formatadas sem tags HTML
 */
export function formatInstructions(instructions: string): string {
  // Remover tags HTML
  return instructions
    .replace(/<[^>]*>/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

/**
 * Calcula o consumo estimado de combustível com base na distância
 * @param distanceInKm - Distância em quilômetros
 * @param fuelEfficiency - Consumo médio em km/l
 * @param fuelPrice - Preço do combustível por litro
 * @returns Objeto com litros consumidos e custo estimado
 */
export function calculateFuelConsumption(
  distanceInKm: number, 
  fuelEfficiency: number, 
  fuelPrice: number
) {
  const liters = distanceInKm / fuelEfficiency;
  const cost = liters * fuelPrice;
  
  return {
    liters: liters.toFixed(2),
    cost: cost.toFixed(2)
  };
}

/**
 * Converte segundos em formato de hora legível
 * @param seconds - Tempo total em segundos
 * @returns Tempo formatado (HH:MM ou MM:SS)
 */
export function formatTime(seconds: number): string {
  if (seconds < 60) {
    return `${seconds}s`;
  } else if (seconds < 3600) {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}m ${remainingSeconds}s`;
  } else {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    return `${hours}h ${minutes}m`;
  }
}
