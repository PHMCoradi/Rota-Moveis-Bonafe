/**
 * Script para criar as tabelas no banco de dados
 */
import { sql } from 'drizzle-orm';
import { db, pool } from './db';
import { users, routes, ceps, waypoints } from '@shared/schema';

async function createTables() {
  try {
    console.log('Criando tabelas no banco de dados PostgreSQL...');

    // Criar tabela de usuários
    await db.execute(sql`
      CREATE TABLE IF NOT EXISTS "users" (
        "id" SERIAL PRIMARY KEY,
        "username" TEXT NOT NULL UNIQUE,
        "password" TEXT NOT NULL,
        "nome" TEXT,
        "empresa" TEXT
      );
    `);
    console.log('Tabela "users" criada com sucesso!');

    // Criar tabela de rotas
    await db.execute(sql`
      CREATE TABLE IF NOT EXISTS "routes" (
        "id" SERIAL PRIMARY KEY,
        "user_id" INTEGER REFERENCES "users"("id"),
        "nome" TEXT NOT NULL,
        "origem" TEXT NOT NULL,
        "destino" TEXT NOT NULL,
        "paradas" JSON DEFAULT '[]',
        "distancia_total" TEXT,
        "tempo_total" TEXT,
        "data_criacao" TIMESTAMP DEFAULT NOW(),
        "rota_json" JSON
      );
    `);
    console.log('Tabela "routes" criada com sucesso!');

    // Criar tabela de waypoints
    await db.execute(sql`
      CREATE TABLE IF NOT EXISTS "waypoints" (
        "id" SERIAL PRIMARY KEY,
        "route_id" INTEGER REFERENCES "routes"("id"),
        "endereco" TEXT NOT NULL,
        "ordem" INTEGER NOT NULL
      );
    `);
    console.log('Tabela "waypoints" criada com sucesso!');

    // Criar tabela de CEPs
    await db.execute(sql`
      CREATE TABLE IF NOT EXISTS "ceps" (
        "id" SERIAL PRIMARY KEY,
        "cep" TEXT NOT NULL UNIQUE,
        "logradouro" TEXT NOT NULL,
        "bairro" TEXT,
        "cidade" TEXT NOT NULL,
        "estado" TEXT NOT NULL,
        "latitude" TEXT,
        "longitude" TEXT
      );
    `);
    console.log('Tabela "ceps" criada com sucesso!');

    // Criar índices para melhorar a performance
    await db.execute(sql`CREATE INDEX IF NOT EXISTS idx_ceps_cep ON "ceps" ("cep");`);
    await db.execute(sql`CREATE INDEX IF NOT EXISTS idx_ceps_cidade_estado ON "ceps" ("cidade", "estado");`);
    console.log('Índices criados com sucesso!');

    console.log('Todas as tabelas foram criadas com sucesso!');

  } catch (error) {
    console.error('Erro ao criar tabelas:', error);
  } finally {
    // Não fechar a conexão aqui para permitir que o script de população use a mesma conexão
  }
}

// Exportar a função para ser usada por outros módulos
export { createTables };