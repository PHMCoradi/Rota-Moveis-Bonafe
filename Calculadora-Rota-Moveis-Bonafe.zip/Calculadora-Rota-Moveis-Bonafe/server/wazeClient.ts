/**
 * Cliente para a API do Waze para obter informações de trânsito em tempo real
 * Baseado no serviço Waze Transport API
 */

import axios from 'axios';

interface WazeAlert {
  id: string;
  type: string;         // ACCIDENT, JAM, ROAD_CLOSED, etc.
  subtype: string;      // Subtipo de alerta
  location: {
    x: number;          // Longitude
    y: number;          // Latitude
  };
  street?: string;      // Nome da rua
  city?: string;        // Nome da cidade
  country: string;      // Código do país (BR para Brasil)
  reportRating: number; // Rating do alerta
  confidence: number;   // Nível de confiança
  reliability: number;  // Confiabilidade
  roadType: number;     // Tipo de estrada
  magvar?: number;      // Direção
  nThumbsUp: number;    // Confirmações positivas
  nComments: number;    // Número de comentários
  reportDescription?: string; // Descrição do reporte
  reportMood?: number;  // Sentimento
  creationTime: string; // Data de criação
  pubMillis: number;    // Timestamp em ms
}

interface WazeJam {
  id: string;
  city: string;
  street: string;
  level: number;        // Nível de congestionamento (1-5)
  length: number;       // Comprimento do congestionamento em metros
  speedKMH: number;     // Velocidade atual em KM/h
  delay: number;        // Atraso em segundos
  roadType: number;     // Tipo de estrada
  line: number[][];     // Coordenadas do congestionamento [longitude, latitude]
  segments: string[];   // Segmentos da estrada
  turnType: string;     // Tipo de curva
  blockingAlertUuid?: string; // ID do alerta que está causando o congestionamento
  startNode?: string;   // Nó inicial
  endNode?: string;     // Nó final
}

interface WazeTrafficResponse {
  alerts: WazeAlert[];
  jams: WazeJam[];
  startTime?: string;
  endTime?: string;
  isCached?: boolean;
  serverTime?: number;
}

// Tipos de alerta do Waze
export enum WazeAlertType {
  ACCIDENT = 'ACCIDENT',
  JAM = 'JAM',
  ROAD_CLOSED = 'ROAD_CLOSED',
  HAZARD = 'HAZARD',
  WEATHERHAZARD = 'WEATHERHAZARD',
  CONSTRUCTION = 'CONSTRUCTION',
  POLICE = 'POLICE'
}

/**
 * Alerta de tráfego formatado para uso na aplicação
 */
export interface TrafficAlert {
  id: string;
  type: string;
  description: string;
  location: {
    lat: number;
    lng: number;
  };
  street?: string;
  city?: string;
  confidence: number;
  creationTime: Date;
  thumbsUp: number;
}

/**
 * Informação de congestionamento formatada para uso na aplicação
 */
export interface TrafficJam {
  id: string;
  street: string;
  city: string;
  level: number;          // 1-5 (5 = pior)
  length: number;         // em metros
  speedKMH: number;
  delay: number;          // em segundos
  line: [number, number][]; // [lat, lng]
  description: string;
}

/**
 * Cliente para API do Waze
 */
export class WazeClient {
  private readonly baseURL = 'https://www.waze.com/row-rtserver/web/TGeoRSS';
  
  /**
   * Converte o tipo de alerta do Waze para uma descrição amigável em português
   */
  private getAlertTypeDescription(type: string): string {
    const descriptions: Record<string, string> = {
      'ACCIDENT': 'Acidente',
      'JAM': 'Congestionamento',
      'ROAD_CLOSED': 'Via bloqueada',
      'HAZARD': 'Perigo na pista',
      'WEATHERHAZARD': 'Perigo climático',
      'CONSTRUCTION': 'Obras',
      'POLICE': 'Fiscalização policial'
    };
    
    return descriptions[type] || type;
  }
  
  /**
   * Descrição do nível de congestionamento
   */
  private getJamLevelDescription(level: number): string {
    const levels: Record<number, string> = {
      1: 'Leve',
      2: 'Moderado',
      3: 'Intenso',
      4: 'Severo',
      5: 'Parado'
    };
    
    return levels[level] || 'Desconhecido';
  }
  
  /**
   * Obter informações de trânsito para uma área específica
   * @param lat Latitude do centro da área
   * @param lng Longitude do centro da área
   * @param radius Raio em metros (padrão: 10000m = 10km)
   * @returns Alertas e congestionamentos na área
   */
  async getTrafficInfo(lat: number, lng: number, radius: number = 10000): Promise<{
    alerts: TrafficAlert[];
    jams: TrafficJam[];
  }> {
    try {
      console.log(`Buscando informações de trânsito do Waze em (${lat},${lng}) com raio de ${radius}m`);
      
      // Parâmetros da API do Waze
      const params = {
        left: lng - 0.1,   // Longitude oeste
        right: lng + 0.1,  // Longitude leste
        bottom: lat - 0.1, // Latitude sul
        top: lat + 0.1,    // Latitude norte
        ma: 500,           // Número máximo de alertas
        mj: 500,           // Número máximo de congestionamentos
        mu: 0,             // Número de usuários (não usado)
      };
      
      // Fazendo a requisição para a API do Waze
      const response = await axios.get(this.baseURL, { params });
      const data: WazeTrafficResponse = response.data;
      
      // Processando alertas retornados
      const alerts: TrafficAlert[] = data.alerts
        .filter(alert => {
          // Filtrando alertas dentro do raio informado
          const alertLat = alert.location.y;
          const alertLng = alert.location.x;
          const distance = this.calculateDistance(lat, lng, alertLat, alertLng);
          return distance <= radius / 1000; // Convertendo para km
        })
        .map(alert => ({
          id: alert.id,
          type: alert.type,
          description: this.getAlertTypeDescription(alert.type),
          location: {
            lat: alert.location.y,
            lng: alert.location.x
          },
          street: alert.street,
          city: alert.city,
          confidence: alert.confidence,
          creationTime: new Date(alert.pubMillis),
          thumbsUp: alert.nThumbsUp
        }));
      
      // Processando congestionamentos retornados
      const jams: TrafficJam[] = data.jams
        .filter(jam => {
          // Verificar se pelo menos um ponto do congestionamento está dentro do raio
          if (jam.line && jam.line.length > 0) {
            for (const point of jam.line) {
              const jamLng = point[0];
              const jamLat = point[1];
              const distance = this.calculateDistance(lat, lng, jamLat, jamLng);
              if (distance <= radius / 1000) {
                return true;
              }
            }
          }
          return false;
        })
        .map(jam => {
          // Converter coordenadas de [lng, lat] para [lat, lng]
          const line: [number, number][] = jam.line.map(point => [point[1], point[0]]);
          
          // Descrição do congestionamento
          const levelText = this.getJamLevelDescription(jam.level);
          const speedText = jam.speedKMH > 0 ? `${jam.speedKMH} km/h` : 'parado';
          const delayText = jam.delay > 60 
            ? `${Math.floor(jam.delay / 60)} min ${jam.delay % 60} s` 
            : `${jam.delay} s`;
          
          const description = `${levelText}: ${speedText}, atraso de ${delayText}`;
          
          return {
            id: jam.id,
            street: jam.street || 'Rua não identificada',
            city: jam.city || '',
            level: jam.level,
            length: jam.length,
            speedKMH: jam.speedKMH,
            delay: jam.delay,
            line,
            description
          };
        });
      
      console.log(`Encontrados ${alerts.length} alertas e ${jams.length} congestionamentos`);
      
      return {
        alerts,
        jams
      };
      
    } catch (error) {
      console.error('Erro ao buscar informações de trânsito do Waze:', error);
      
      // Retornar estrutura vazia em caso de erro
      return {
        alerts: [],
        jams: []
      };
    }
  }
  
  /**
   * Calcula a distância entre dois pontos em quilômetros
   * Usa a fórmula de Haversine
   */
  private calculateDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
    const R = 6371; // Raio da Terra em km
    const dLat = this.deg2rad(lat2 - lat1);
    const dLon = this.deg2rad(lon2 - lon1);
    const a = 
      Math.sin(dLat/2) * Math.sin(dLat/2) +
      Math.cos(this.deg2rad(lat1)) * Math.cos(this.deg2rad(lat2)) * 
      Math.sin(dLon/2) * Math.sin(dLon/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return R * c; // Distância em km
  }
  
  /**
   * Converte graus para radianos
   */
  private deg2rad(deg: number): number {
    return deg * (Math.PI/180);
  }
}

export const wazeClient = new WazeClient();