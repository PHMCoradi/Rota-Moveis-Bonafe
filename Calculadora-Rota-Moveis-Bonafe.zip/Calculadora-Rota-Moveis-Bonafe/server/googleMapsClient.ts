import { Client, TravelMode, UnitSystem } from "@googlemaps/google-maps-services-js";

/**
 * Classe para encapsular a interação com a API do Google Maps
 */
export class GoogleMapsClient {
  private client: Client;
  private apiKey: string;

  constructor(apiKey: string) {
    this.client = new Client({});
    this.apiKey = apiKey;
  }

  /**
   * Calcula a rota entre dois pontos com paradas opcionais
   */
  async calculateRoute(
    origin: string,
    destination: string, 
    waypoints?: string[],
    optimizeWaypoints: boolean = true
  ) {
    try {
      const waypointsArray = waypoints && waypoints.length > 0
        ? waypoints.map(point => ({ location: point, stopover: true }))
        : [];

      const response = await this.client.directions({
        params: {
          origin,
          destination,
          waypoints: waypointsArray,
          optimizeWaypoints,
          language: "pt-BR",
          region: "br",
          mode: TravelMode.driving,
          units: UnitSystem.metric,
          key: this.apiKey,
        },
        timeout: 5000, // 5 segundos de timeout
      });

      return response.data;
    } catch (error) {
      console.error("Erro ao calcular rota no Google Maps:", error);
      throw new Error("Falha ao calcular a rota. Verifique os endereços e tente novamente.");
    }
  }

  /**
   * Geocodifica um endereço para obter coordenadas
   */
  async geocodeAddress(address: string) {
    try {
      const response = await this.client.geocode({
        params: {
          address,
          language: "pt-BR",
          region: "br",
          key: this.apiKey,
        },
        timeout: 3000,
      });

      if (response.data.results.length === 0) {
        throw new Error(`Endereço não encontrado: ${address}`);
      }

      return response.data.results[0];
    } catch (error) {
      console.error("Erro ao geocodificar endereço:", error);
      throw new Error("Falha ao encontrar coordenadas para o endereço informado.");
    }
  }

  /**
   * Calcula a distância entre dois endereços
   */
  async calculateDistance(origin: string, destination: string) {
    try {
      const response = await this.client.distancematrix({
        params: {
          origins: [origin],
          destinations: [destination],
          language: "pt-BR",
          region: "br",
          key: this.apiKey,
        },
        timeout: 3000,
      });

      if (
        !response.data.rows[0] ||
        !response.data.rows[0].elements[0] ||
        response.data.rows[0].elements[0].status !== "OK"
      ) {
        throw new Error("Não foi possível calcular a distância entre os endereços.");
      }

      return response.data.rows[0].elements[0];
    } catch (error) {
      console.error("Erro ao calcular distância:", error);
      throw new Error("Falha ao calcular a distância entre os endereços.");
    }
  }
}
