import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { routeRequestSchema } from "@shared/schema";
import { z } from "zod";
import { osrmClient } from "./osrmClient";
import { wazeClient } from "./wazeClient";
import { findCepInDatabase, formatCep, isCepFormat, searchCeps, findCepsByCidade } from "./cepService";

export async function registerRoutes(app: Express): Promise<Server> {
  // Endpoint para buscar endereços (autocomplete)
  app.get("/api/search/addresses", async (req, res) => {
    try {
      // Aceitar tanto 'q' quanto 'query' como parâmetros de busca
      const query = (req.query.query || req.query.q) as string;
      
      if (!query || query.length < 2) {
        console.log("Query vazia ou muito curta:", query);
        return res.json([]);
      }
      
      console.log(`Buscando endereços para: "${query}"`);
      
      // Interface para definir a estrutura dos resultados
      interface AddressResult {
        displayName: string;
        value: string;
        isCity?: boolean;
        secondaryText?: string;
        distancia?: number;
      }
      
      // Verifica se é um CEP e adiciona resultado direto, mesmo se falhar a API
      const cepPattern = /\d{5}[-.\s]?\d{3}/;
      const cepMatch = query.match(cepPattern);
      
      let directResults: AddressResult[] = [];
      
      // Detectamos CEPs, mas não adicionamos nada aqui
      // Os CEPs serão tratados exclusivamente pelo osrmClient.searchAddresses
      if (cepMatch) {
        // Extrair e normalizar o CEP (remover separadores)
        const cep = cepMatch[0].replace(/[-.\s]/g, '');
        // Formatar o CEP com hífen para melhor visualização
        const cepFormatado = `${cep.substring(0, 5)}-${cep.substring(5)}`;
        console.log(`Detectado CEP: ${cepFormatado}`);
        
        // Não adicionamos sugestão duplicada aqui, pois será tratada pelo osrmClient
      }
      
      // Adicionar cidades conhecidas que correspondam à consulta
      const cidadesConhecidas = {
        'Dois Córregos-SP': [-22.3697554, -48.3845315],
        'Jaú-SP': [-22.293585, -48.559193],
        'São Carlos-SP': [-22.0113892, -47.8911487],
        'Mineiros do Tietê-SP': [-22.41126, -48.45126],
        'Ribeirão Preto-SP': [-21.1776315, -47.8100983]
      };
      
      const cidadesFiltradas: AddressResult[] = Object.keys(cidadesConhecidas)
        .filter(city => city.toLowerCase().includes(query.toLowerCase()))
        .map(city => ({
          displayName: city,
          value: city,
          isCity: true,
          secondaryText: "Brasil", // Indicar que é uma cidade brasileira
          distancia: 1 // Alta prioridade para cidades conhecidas
        }));
        
      directResults = [...directResults, ...cidadesFiltradas];
      
      // Tentar buscar resultados da API OSRM (mas não falhar se der erro)
      let apiResults: AddressResult[] = [];
      try {
        apiResults = await osrmClient.searchAddresses(query);
      } catch (apiError) {
        console.error('Erro ao buscar endereços via API OSRM:', apiError);
      }
      
      // Combinar resultados diretos com resultados da API
      const combinedResults: AddressResult[] = [...directResults];
      
      // Adicionar apenas resultados da API que não estejam já nos resultados diretos
      if (Array.isArray(apiResults)) {
        apiResults.forEach(addr => {
          if (!combinedResults.some(item => item.value === addr.value)) {
            combinedResults.push(addr);
          }
        });
      }
      
      // Se estamos usando o query para buscar um endereço em Dois Córregos,
      // criar automaticamente um resultado "Rua XXX - Dois Córregos-SP"
      if ((query.toLowerCase().startsWith('rua') || 
          query.toLowerCase().startsWith('r.') ||
          query.toLowerCase().startsWith('av') ||
          query.toLowerCase().startsWith('alameda')) && 
          !query.toLowerCase().includes('dois córregos') &&
          !query.toLowerCase().includes('dois corregos')) {
            
        // Extrair nome da rua sem o tipo (Rua, Av, etc)
        const rua = query.replace(/^(rua|r\.|av|av\.|avenida|alameda|al\.|praça|pça\.)\s+/i, '').trim();
        
        if (rua.length > 2) {
          // Adicionar sugestão com Dois Córregos explícito
          combinedResults.push({
            displayName: query,
            value: `${query} - Dois Córregos-SP`,
            isCity: false,
            secondaryText: "Dois Córregos-SP",
            distancia: 2
          });
        }
      }
      
      // Ordenar resultados por distância
      const sortedResults = combinedResults
        .sort((a, b) => (a.distancia || 10) - (b.distancia || 10))
        .slice(0, 5);
      
      console.log(`Encontrados ${sortedResults.length} endereços para "${query}"`);  
      res.json(sortedResults);
    } catch (error) {
      console.error("Erro ao buscar endereços:", error);
      
      // Em caso de erro, retornar um array vazio, não um erro
      res.json([]);
    }
  });

  // Endpoint para calcular uma rota
  app.post("/api/routes/calculate", async (req, res) => {
    try {
      // Validar o corpo da requisição
      const routeData = routeRequestSchema.parse(req.body);
      const { origem, paradas, otimizar, dataInicioEntrega, dataFimEntrega, tipoVeiculo } = routeData;
      
      // Verificar caso especial da Rua Arnaldo Victaliano
      const isArnaldoVictaliano = paradas && paradas.some(parada => 
        parada.toLowerCase().includes('arnaldo victaliano') || 
        parada.toLowerCase().includes('14091') ||
        parada.toLowerCase().includes('victaliano'));
        
      // Verificar caso especial para CEP 17302-122 (deve direcionar para Dois Córregos-SP)
      const isDoisCorregosCEP = paradas && paradas.some(parada => 
        parada.includes('17302-122') || parada.includes('17302122'));
        
      // Verificar caso especial para CEP 13560-010 (deve direcionar para São Carlos-SP)
      const isSaoCarlosCEP = paradas && paradas.some(parada =>
        parada.includes('13560-010') || parada.includes('13560010'));
        
      // Tratar caso especial CEP 17302-122
      if (isDoisCorregosCEP) {
        console.log("🔍 DETECTADO CASO ESPECIAL: CEP 17302-122 em Dois Córregos-SP");
        
        // Modificar as paradas para forçar o uso do endereço correto
        const paradasModificadas = [...paradas];
        for (let i = 0; i < paradasModificadas.length; i++) {
          if (paradasModificadas[i].includes('17302-122') || paradasModificadas[i].includes('17302122')) {
            // Substituir pela versão correta do endereço em Dois Córregos
            paradasModificadas[i] = "Rua 13 de Maio, Centro, Dois Córregos - SP, CEP 17302-122";
            console.log(`✅ Parada com CEP 17302-122 modificada para o formato correto: ${paradasModificadas[i]}`);
          }
        }
        
        // Substituir as paradas originais pelas modificadas
        paradas.length = 0;
        paradas.push(...paradasModificadas);
      }
      
      // Tratar caso especial CEP 13560-010
      if (isSaoCarlosCEP) {
        console.log("🔍 DETECTADO CASO ESPECIAL: CEP 13560-010 em São Carlos-SP");
        
        // Modificar as paradas para forçar o uso do endereço correto
        const paradasModificadas = [...paradas];
        for (let i = 0; i < paradasModificadas.length; i++) {
          if (paradasModificadas[i].includes('13560-010') || paradasModificadas[i].includes('13560010')) {
            // Substituir pela versão correta do endereço em São Carlos
            paradasModificadas[i] = "Rua General Osório, Centro, São Carlos - SP, CEP 13560-010";
            console.log(`✅ Parada com CEP 13560-010 modificada para o formato correto: ${paradasModificadas[i]}`);
          }
        }
        
        // Substituir as paradas originais pelas modificadas
        paradas.length = 0;
        paradas.push(...paradasModificadas);
      }
        
      if (isArnaldoVictaliano) {
        console.log("🔍 DETECTADO CASO ESPECIAL: Rua Arnaldo Victaliano em Ribeirão Preto");
        console.log("📍 Usando coordenadas especiais para evitar o problema com a Rua São José ou Rua Albuquerque Lins");
        
        // Modificar as paradas para forçar o uso do nome exato que conhecemos
        for (let i = 0; i < paradas.length; i++) {
          if (paradas[i].toLowerCase().includes('arnaldo victaliano') || 
              paradas[i].toLowerCase().includes('14091') ||
              paradas[i].toLowerCase().includes('victaliano')) {
            // Substituir pela versão correta do endereço com as coordenadas conhecidas
            paradas[i] = "Rua Arnaldo Victaliano, Jardim Iguatemi, Ribeirão Preto - SP";
            console.log(`✅ Parada modificada para o formato correto: ${paradas[i]}`);
          }
        }
        
        console.log("CASO ESPECIAL: Detectada busca relacionada a Rua Arnaldo Victaliano: " + paradas.join(", "));
        console.log("Usando coordenadas conhecidas específicas e verificadas para este endereço");
      }
      
      // No novo modelo, não usamos mais destino separado, apenas origem e paradas
      // A última parada é tratada visualmente como destino no frontend
      // Para compatibilidade com código existente, criamos uma variável vazia
      const destino = undefined;
      
      // Adicionar logs para depuração
      console.log(`Calculando rota: origem=${origem}, paradas=${JSON.stringify(paradas || [])}, otimizar=${otimizar}`);
      if (dataInicioEntrega) console.log(`Data de início de entrega: ${dataInicioEntrega}`);
      if (dataFimEntrega) console.log(`Data de fim de entrega: ${dataFimEntrega}`);
      console.log(`Tipo de veículo selecionado: ${tipoVeiculo || 'caminhao_2_eixos (padrão)'}`);
      
      // Verificar se a otimização deve ser aplicada (baseado no parâmetro otimizar e no número de paradas)
      // Garantir que o valor seja booleano primitivo
      let shouldOptimize = false;
      
      // Verificação explícita de tipos para evitar erros de compilação
      if (typeof otimizar === 'boolean') {
        shouldOptimize = otimizar;
      } else if (typeof otimizar === 'string') {
        shouldOptimize = otimizar.toLowerCase() === 'true';
      } else if (typeof otimizar === 'number') {
        shouldOptimize = otimizar === 1;
      } else if (otimizar !== undefined && otimizar !== null) {
        // Último caso para objetos ou tipos especiais
        shouldOptimize = Boolean(otimizar);
      }
      
      // Só otimizar se tiver mais de uma parada
      const temParadasSuficientes = paradas !== undefined && paradas.length > 1;
      shouldOptimize = shouldOptimize && temParadasSuficientes;
      
      console.log(`Otimização de rota ${shouldOptimize ? "ATIVADA" : "DESATIVADA"} (valor original: ${otimizar}, tipo: ${typeof otimizar})`);
      console.log(`shouldOptimize final: ${shouldOptimize}, paradas suficientes: ${temParadasSuficientes}`);

      // Chamar a API OSRM para calcular a rota (com otimização ativada apenas quando necessário)
      // Passando undefined como destino para não duplicar a última parada
      const osrmResponse = await osrmClient.calculateRoute(origem, undefined, paradas || [], shouldOptimize);

      // Verificar se a resposta contém um erro
      if (osrmResponse.error) {
        console.error(`Erro no cálculo da rota: ${osrmResponse.error}`);
        return res.status(400).json({
          message: osrmResponse.error
        });
      }

      // Se não houver rotas, retornar erro
      if (!osrmResponse.routes || osrmResponse.routes.length === 0) {
        return res.status(404).json({ 
          message: "Não foi possível encontrar uma rota entre os pontos especificados." 
        });
      }

      // Obter a primeira rota
      const route = osrmResponse.routes[0];
      
      // Formatar distância e tempo em formato legível
      const distanciaTotal = osrmClient.formatDistance(route.distance);
      const tempoTotal = osrmClient.formatDuration(route.duration);

      // Formatar instruções da rota
      const instrucoes = osrmClient.formatRouteInstructions(osrmResponse);

      // Calcular valor de pedágios com base em valores reais para rotas específicas
      let valorPedagios: string | undefined = undefined;
      
      // Valor pedágio trecho Dois Córregos-SP até Bauru para caminhão 2 eixos: R$ 12,63
      
      // Em vez de usar um cálculo baseado em distância, vamos usar valores fixos para rotas conhecidas
      // para ser mais preciso
      if (origem && paradas && paradas.length > 0) {
        // Normalizar nomes para evitar problemas com formatação, removendo acentos
        const origemNormalizada = osrmClient.normalizeString(origem.toLowerCase().trim());
        const destinoNormalizado = osrmClient.normalizeString(paradas[0].toLowerCase().trim());
        
        console.log(`Verificando rota: ${origemNormalizada} para ${destinoNormalizado} (${tipoVeiculo})`);
        
        // Verificar se é a rota Dois Córregos - Bauru
        if ((origemNormalizada.includes('dois corregos') && destinoNormalizado.includes('bauru')) ||
            (origemNormalizada.includes('dois corrego') && destinoNormalizado.includes('bauru'))) {
          // Definir o valor com base no tipo de veículo
          // Pedágio SP-225 Jaú KM 199.300 (Concessionária Cart)
          switch(tipoVeiculo) {
            case 'carro':
              valorPedagios = 'R$ 13,30';
              break;
            case 'moto':
              valorPedagios = 'R$ 6,65';
              break;
            case 'caminhao':
              valorPedagios = 'R$ 19,95';
              break;
            case 'caminhao_2_eixos':
            default:
              valorPedagios = 'R$ 26,60';
              break;
          }
          console.log(`Rota conhecida detectada: Dois Córregos-SP para Bauru. Valor do pedágio: ${valorPedagios} (${tipoVeiculo})`);
        }
        // Verificar se é a rota Bauru - Dois Córregos
        else if ((origemNormalizada.includes('bauru') && destinoNormalizado.includes('dois corregos')) ||
                 (origemNormalizada.includes('bauru') && destinoNormalizado.includes('dois corrego'))) {
          // Definir o valor com base no tipo de veículo
          // Pedágio SP-225 Jaú KM 199.300 (Concessionária Cart)
          switch(tipoVeiculo) {
            case 'carro':
              valorPedagios = 'R$ 13,30';
              break;
            case 'moto':
              valorPedagios = 'R$ 6,65';
              break;
            case 'caminhao':
              valorPedagios = 'R$ 19,95';
              break;
            case 'caminhao_2_eixos':
            default:
              valorPedagios = 'R$ 26,60';
              break;
          }
          console.log(`Rota conhecida detectada: Bauru para Dois Córregos-SP. Valor do pedágio: ${valorPedagios} (${tipoVeiculo})`);
        }
        // Verificar se é a rota Dois Córregos - Ribeirão Preto
        else if ((origemNormalizada.includes('dois corregos') && destinoNormalizado.includes('ribeirao preto')) ||
                 (origemNormalizada.includes('dois corrego') && destinoNormalizado.includes('ribeirao preto'))) {
          // Pedágios corretos: Boa Esperança do Sul (R$ 22,80) e Guatapará (R$ 34,90) para caminhão 2 eixos
          
          // Definir o valor com base no tipo de veículo
          // Valores calculados somando os dois pedágios que estão na rota
          switch(tipoVeiculo) {
            case 'carro':
              valorPedagios = 'R$ 28,80'; // 11,40 (Boa Esperança) + 17,40 (Guatapará)
              break;
            case 'moto':
              valorPedagios = 'R$ 14,40'; // 5,70 (Boa Esperança) + 8,70 (Guatapará)
              break;
            case 'caminhao':
              valorPedagios = 'R$ 43,30'; // 17,10 (Boa Esperança) + 26,20 (Guatapará)
              break;
            case 'caminhao_2_eixos':
            default:
              valorPedagios = 'R$ 57,70'; // 22,80 (Boa Esperança) + 34,90 (Guatapará)
              break;
          }
          console.log(`Rota conhecida detectada: Dois Córregos-SP para Ribeirão Preto-SP. Valor do pedágio: ${valorPedagios} (${tipoVeiculo})`);
        }
        // Para outras rotas, usar o cálculo estimado
        else if (route.distance > 50000) {
          // Aqui podemos adicionar mais rotas conhecidas no futuro
          // Por enquanto, para rotas desconhecidas, continuamos usando o cálculo por distância
          const distanciaKm = route.distance / 1000; // Converter de metros para km
          
          // Definir taxa de pedágio por km com base no tipo de veículo
          let valorPorKm = 0.16; // Valor padrão para caminhão 2 eixos
          
          // Ajustar valor conforme o tipo de veículo
          switch(tipoVeiculo) {
            case 'carro':
              valorPorKm = 0.09;
              break;
            case 'moto':
              valorPorKm = 0.05;
              break;
            case 'caminhao':
              valorPorKm = 0.12;
              break;
            case 'caminhao_2_eixos':
            default:
              valorPorKm = 0.16;
              break;
          }
          
          const valorPedagioNumerico = distanciaKm * valorPorKm;
          
          // Formatar para Reais
          valorPedagios = valorPedagioNumerico.toLocaleString('pt-BR', {
            style: 'currency',
            currency: 'BRL',
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
          });
          
          console.log(`Rota desconhecida: calculando pedágio com base na distância: ${distanciaKm.toFixed(1)}km x R$${valorPorKm.toFixed(2)} (${tipoVeiculo}) = ${valorPedagios}`);
        }
      }

      // Lista de pontos de interesse na rota
      const pontosInteresse: any[] = [];
      
      // Adicionar pedágios e balanças específicos para rotas conhecidas
      if (origem && paradas && paradas.length > 0) {
        // Normalizar origem e destino para busca
        const origemNormalizada = osrmClient.normalizeString(origem.toLowerCase());
        const destinoNormalizado = osrmClient.normalizeString(paradas[paradas.length - 1].toLowerCase());
        
        // Adicionar pedágios para Dois Córregos - Bauru
        if ((origemNormalizada.includes('dois corregos') && destinoNormalizado.includes('bauru')) ||
            (origemNormalizada.includes('dois corrego') && destinoNormalizado.includes('bauru'))) {
          
          // Lista de pedágios específicos para a rota Dois Córregos - Bauru
          const pedagiosBauru = [
            {
              tipo: 'tollbooth',
              nome: 'Pedágio SP-225 - Jaú KM 199.300',
              posicao: [-22.3182768, -48.7255090], // Coordenadas exatas do OpenStreetMap
              detalhe: 'Concessionária Cart - Rodovia Comandante João Ribeiro de Barros',
              naRota: true,
              valor: tipoVeiculo === 'caminhao_2_eixos' ? 'R$ 26,60' : 
                    tipoVeiculo === 'caminhao' ? 'R$ 19,95' : 
                    tipoVeiculo === 'moto' ? 'R$ 6,65' : 'R$ 13,30'
            },
            {
              tipo: 'weighingstation',
              nome: 'Balança DER SP-225',
              posicao: [-22.3368, -48.6933], // Posição revisada da balança na SP-225 entre Jaú e Bauru
              detalhe: 'Horário: 6h às 18h (dias úteis) - Entre Jaú e Bauru',
              naRota: true
            }
          ];
          
          // Adicionar apenas os pedágios e balanças que realmente estão na rota
          pedagiosBauru
            .filter(poi => poi.naRota === true) // Filtrar apenas os que estão na rota
            .forEach(poi => {
              pontosInteresse.push(poi);
            });
        }
        
        // Adicionar pedágios para Dois Córregos - Ribeirão Preto
        if ((origemNormalizada.includes('dois corregos') && destinoNormalizado.includes('ribeirao preto')) ||
            (origemNormalizada.includes('dois corrego') && destinoNormalizado.includes('ribeirao preto'))) {
          
          // Lista de pedágios específicos para a rota Dois Córregos - Ribeirão Preto
          // Conforme informado, os pedágios corretos são Boa Esperança do Sul e Guatapará
          const pedagiosRibeiraoPreto = [
            {
              tipo: 'tollbooth',
              nome: 'Pedágio SP-225 - Jaú',
              posicao: [-22.3472, -48.6289],
              detalhe: 'Concessionária Cart',
              naRota: false, // Não está na rota selecionada
              valor: tipoVeiculo === 'caminhao_2_eixos' ? 'R$ 23,75' : 
                    tipoVeiculo === 'caminhao' ? 'R$ 10,50' : 
                    tipoVeiculo === 'moto' ? 'R$ 3,95' : 'R$ 7,90'
            },
            {
              tipo: 'tollbooth',
              nome: 'Pedágio SP-225 - Brotas',
              posicao: [-22.1795, -48.1255],
              detalhe: 'Concessionária Eixo SP',
              naRota: false, // Não está na rota selecionada
              valor: tipoVeiculo === 'caminhao_2_eixos' ? 'R$ 19,40' : 
                    tipoVeiculo === 'caminhao' ? 'R$ 14,60' : 
                    tipoVeiculo === 'moto' ? 'R$ 4,85' : 'R$ 9,70'
            },
            {
              tipo: 'tollbooth',
              nome: 'Pedágio Boa Esperança do Sul',
              posicao: [-21.9854, -48.3935], // Coordenada exata do pedágio na SP-255 km 133
              detalhe: 'Concessionária VIAPAULISTA - SP-255 km 133',
              naRota: true, // Este está na rota
              valor: tipoVeiculo === 'caminhao_2_eixos' ? 'R$ 22,80' : 
                    tipoVeiculo === 'caminhao' ? 'R$ 17,10' : 
                    tipoVeiculo === 'moto' ? 'R$ 5,70' : 'R$ 11,40'
            },
            {
              tipo: 'tollbooth',
              nome: 'Pedágio Guatapará',
              posicao: [-21.5087, -48.0308], // Coordenada exata do pedágio na SP-255 km 46
              detalhe: 'Concessionária VIAPAULISTA - SP-255 km 46',
              naRota: true, // Este está na rota
              valor: tipoVeiculo === 'caminhao_2_eixos' ? 'R$ 34,90' : 
                    tipoVeiculo === 'caminhao' ? 'R$ 26,20' : 
                    tipoVeiculo === 'moto' ? 'R$ 8,70' : 'R$ 17,40'
            },
            // Pedágio próximo, mas que não está na rota (não deve ser exibido nem contabilizado)
            {
              tipo: 'tollbooth',
              nome: 'Pedágio SP-330 - Guará',
              posicao: [-20.5257, -47.8232],
              detalhe: 'Concessionária Intervias',
              naRota: false, // Este NÃO está na rota!
              valor: tipoVeiculo === 'caminhao_2_eixos' ? 'R$ 25,80' : 
                    tipoVeiculo === 'caminhao' ? 'R$ 17,20' : 
                    tipoVeiculo === 'moto' ? 'R$ 6,45' : 'R$ 12,90'
            },
            {
              tipo: 'weighingstation',
              nome: 'Balança DER SP-255',
              posicao: [-21.6374, -48.0537], // Coordenada exata da balança na SP-255
              detalhe: 'Horário: 6h às 18h (dias úteis)',
              naRota: true
            }
          ];
          
          // Adicionar apenas os pedágios e balanças que realmente estão na rota
          pedagiosRibeiraoPreto
            .filter(poi => poi.naRota === true) // Filtrar apenas os que estão na rota
            .forEach(poi => {
              pontosInteresse.push(poi);
            });
        }
      }

      // Processar rotas alternativas
      const rotasAlternativas = [];
      
      // Verificar se existe mais de uma rota nos resultados
      if (osrmResponse.routes && osrmResponse.routes.length > 1) {
        // A primeira rota (índice 0) já é a principal, então processamos as alternativas a partir do índice 1
        for (let i = 1; i < osrmResponse.routes.length; i++) {
          const rotaAlternativa = osrmResponse.routes[i];
          
          // Extrai informações relevantes da rota alternativa
          rotasAlternativas.push({
            polyline: rotaAlternativa.geometry, // A geometria para desenhar no mapa
            distancia: osrmClient.formatDistance(rotaAlternativa.distance), // Distância formatada
            tempo: osrmClient.formatDuration(rotaAlternativa.duration), // Tempo formatado
            distanciaNumerica: rotaAlternativa.distance, // Valor numérico para comparação
            tempoNumerico: rotaAlternativa.duration, // Valor numérico para comparação
            destaque: false // Não é a rota principal (destacada)
          });
        }
        
        // Adiciona a rota principal como primeira opção, com destaque=true
        rotasAlternativas.unshift({
          polyline: osrmResponse.routes[0].geometry,
          distancia: distanciaTotal,
          tempo: tempoTotal,
          distanciaNumerica: osrmResponse.routes[0].distance,
          tempoNumerico: osrmResponse.routes[0].duration,
          destaque: true // Esta é a rota principal (destacada)
        });
        
        console.log(`Processadas ${rotasAlternativas.length} rotas (1 principal + ${rotasAlternativas.length - 1} alternativas)`);
      }
      
      // Construir resposta
      const routeResponse = {
        distanciaTotal,
        tempoTotal,
        rota: osrmResponse,
        origem,
        // Não incluímos mais o destino na resposta, apenas origem e paradas
        paradas: paradas || [],
        instrucoes,
        // Incluir informações de otimização se disponíveis
        optimized: osrmResponse.optimized || false,
        originalWaypointsOrder: osrmResponse.originalWaypointsOrder || [],
        optimizedWaypointsOrder: osrmResponse.optimizedWaypointsOrder || [],
        // Incluir datas de entrega se fornecidas
        dataInicioEntrega,
        dataFimEntrega,
        // Incluir valor dos pedágios se calculado
        valorPedagios,
        // Incluir tipo de veículo usado para calcular o pedágio
        tipoVeiculo,
        // Incluir pontos de interesse na rota (pedágios, balanças)
        pontosInteresse,
        // Incluir rotas alternativas (se existirem)
        rotasAlternativas: rotasAlternativas.length > 0 ? rotasAlternativas : undefined
      };

      res.json(routeResponse);
    } catch (error) {
      console.error("Erro ao calcular rota:", error);
      
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Dados inválidos para cálculo de rota", 
          errors: error.errors 
        });
      }
      
      // Verificar se é um erro de conexão com a API
      const err = error as any; // Tratamento para erro desconhecido
      if (err.response && err.response.data) {
        console.error("Resposta de erro da API:", err.response.data);
        return res.status(err.response.status || 500).json({
          message: "Erro na comunicação com a API de rotas.",
          details: err.response.data.message || "Verifique sua conexão e tente novamente."
        });
      }
      
      res.status(500).json({ 
        message: "Erro ao calcular rota. Tente novamente mais tarde." 
      });
    }
  });

  // Endpoint para salvar uma rota
  app.post("/api/routes/save", async (req, res) => {
    try {
      const { nome, rota } = req.body;
      
      if (!nome || !rota) {
        return res.status(400).json({ message: "Nome e dados da rota são obrigatórios" });
      }

      // Salvar rota no storage
      const savedRoute = await storage.createRoute({
        nome,
        origem: rota.origem,
        destino: rota.destino,
        paradas: rota.paradas || [],
        distanciaTotal: rota.distanciaTotal,
        tempoTotal: rota.tempoTotal,
        rotaJSON: rota.rota,
        userId: 1, // Usuário fixo para este exemplo
      });

      res.status(201).json({ 
        message: "Rota salva com sucesso", 
        id: savedRoute.id 
      });
    } catch (error) {
      console.error("Erro ao salvar rota:", error);
      res.status(500).json({ 
        message: "Erro ao salvar a rota. Tente novamente mais tarde." 
      });
    }
  });

  // Endpoint para obter rotas salvas
  app.get("/api/routes", async (req, res) => {
    try {
      // Usuário fixo para este exemplo
      const userId = 1;
      
      const routes = await storage.getRoutesByUserId(userId);
      res.json(routes);
    } catch (error) {
      console.error("Erro ao buscar rotas:", error);
      res.status(500).json({ 
        message: "Erro ao buscar rotas. Tente novamente mais tarde." 
      });
    }
  });

  // Endpoint para obter uma rota específica
  app.get("/api/routes/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: "ID inválido" });
      }
      
      const route = await storage.getRoute(id);
      
      if (!route) {
        return res.status(404).json({ message: "Rota não encontrada" });
      }
      
      res.json(route);
    } catch (error) {
      console.error("Erro ao buscar rota:", error);
      res.status(500).json({ 
        message: "Erro ao buscar a rota. Tente novamente mais tarde." 
      });
    }
  });

  // Endpoint para deletar uma rota
  app.delete("/api/routes/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: "ID inválido" });
      }
      
      const success = await storage.deleteRoute(id);
      
      if (!success) {
        return res.status(404).json({ message: "Rota não encontrada" });
      }
      
      res.json({ message: "Rota deletada com sucesso" });
    } catch (error) {
      console.error("Erro ao deletar rota:", error);
      res.status(500).json({ 
        message: "Erro ao deletar a rota. Tente novamente mais tarde." 
      });
    }
  });

  // Endpoint para buscar informações de trânsito do Waze
  app.get("/api/traffic", async (req, res) => {
    try {
      // Ler parâmetros da query
      const lat = parseFloat(req.query.lat as string);
      const lng = parseFloat(req.query.lng as string);
      const radius = parseInt(req.query.radius as string) || 10000; // Padrão: 10km
      
      // Validar coordenadas
      if (isNaN(lat) || isNaN(lng)) {
        return res.status(400).json({
          message: "Coordenadas inválidas. Forneça lat e lng como números válidos."
        });
      }
      
      // Definir limites de coordenadas e raio
      if (lat < -90 || lat > 90 || lng < -180 || lng > 180) {
        return res.status(400).json({
          message: "Coordenadas fora dos limites válidos. Latitude deve estar entre -90 e 90, Longitude entre -180 e 180."
        });
      }
      
      if (radius <= 0 || radius > 50000) { // Máximo 50km
        return res.status(400).json({
          message: "Raio inválido. Deve estar entre 1 e 50000 metros."
        });
      }
      
      console.log(`Buscando informações de trânsito em (${lat}, ${lng}) com raio de ${radius}m`);
      
      // Buscar informações de trânsito
      const trafficInfo = await wazeClient.getTrafficInfo(lat, lng, radius);
      
      console.log(`Encontrados ${trafficInfo.alerts.length} alertas e ${trafficInfo.jams.length} congestionamentos`);
      
      // Retornar dados formatados
      res.json({
        success: true,
        timestamp: new Date().toISOString(),
        location: {
          lat,
          lng,
          radius
        },
        alerts: trafficInfo.alerts,
        jams: trafficInfo.jams
      });
    } catch (error) {
      console.error("Erro ao buscar informações de trânsito:", error);
      res.status(500).json({
        success: false,
        message: "Erro ao buscar informações de trânsito. Tente novamente mais tarde."
      });
    }
  });

  // Endpoint para buscar informações de CEP
  app.get("/api/cep/:cep", async (req, res) => {
    try {
      const cep = req.params.cep;
      
      // Verificar se o cep foi fornecido
      if (!cep) {
        return res.status(400).json({
          success: false,
          message: "CEP não fornecido. Utilize o formato /api/cep/XXXXX-XXX"
        });
      }
      
      // Verificar se é um CEP válido
      if (!isCepFormat(cep.replace(/\D/g, '').padStart(8, '0'))) {
        return res.status(400).json({
          success: false,
          message: "Formato de CEP inválido. Utilize XXXXX-XXX ou XXXXXXXX"
        });
      }
      
      console.log(`Buscando informações para o CEP: ${cep}`);
      
      // Buscar informações do CEP no banco de dados
      const cepInfo = await findCepInDatabase(cep);
      
      if (cepInfo) {
        return res.json({
          success: true,
          cep: cepInfo
        });
      }
      
      // Se não encontrou no banco de dados, retornar mensagem adequada
      return res.status(404).json({
        success: false,
        message: "CEP não encontrado na base de dados"
      });
    } catch (error) {
      console.error("Erro ao buscar informações de CEP:", error);
      res.status(500).json({
        success: false,
        message: "Erro ao buscar informações de CEP. Tente novamente mais tarde."
      });
    }
  });
  
  // Endpoint para buscar CEPs por cidade e estado
  app.get("/api/ceps", async (req, res) => {
    try {
      const { cidade, estado, q } = req.query;
      
      // Se houver uma busca livre (q), usar searchCeps
      if (q && typeof q === 'string' && q.length >= 2) {
        console.log(`Buscando CEPs com texto livre: "${q}"`);
        
        const ceps = await searchCeps(q);
        
        return res.json({
          success: true,
          query: q,
          resultados: ceps.length,
          ceps
        });
      }
      
      // Se não houver busca livre, verificar se temos cidade e estado
      if (!cidade || !estado) {
        return res.status(400).json({
          success: false,
          message: "Parâmetros inválidos. Forneça 'cidade' e 'estado' ou um termo de busca 'q'"
        });
      }
      
      if (typeof cidade !== 'string' || typeof estado !== 'string') {
        return res.status(400).json({
          success: false,
          message: "Parâmetros inválidos. 'cidade' e 'estado' devem ser strings"
        });
      }
      
      console.log(`Buscando CEPs para ${cidade}-${estado}`);
      
      // Buscar CEPs por cidade e estado
      const ceps = await findCepsByCidade(cidade, estado);
      
      return res.json({
        success: true,
        cidade,
        estado,
        resultados: ceps.length,
        ceps
      });
    } catch (error) {
      console.error("Erro ao buscar CEPs:", error);
      res.status(500).json({
        success: false,
        message: "Erro ao buscar CEPs. Tente novamente mais tarde."
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
