/**
 * Script para popular a base de dados de CEPs
 * Foco nos estados de São Paulo (SP) e Minas Gerais (MG)
 */
import { db, pool } from './db';
import { ceps, type InsertCep } from '@shared/schema';
import { cepDatabase } from '../ceps_output';
import { createTables } from './migrateTables';
import { sql } from 'drizzle-orm';

async function populateCepsFromLocal() {
  try {
    console.log('Iniciando importação de CEPs para o banco de dados...');
    
    // Primeiro vamos importar os CEPs do arquivo cepDatabase local
    const localCeps: InsertCep[] = [];
    
    for (const [cepKey, cepInfo] of Object.entries(cepDatabase)) {
      const formattedCep = `${cepKey.substring(0, 5)}-${cepKey.substring(5)}`;
      
      localCeps.push({
        cep: formattedCep,
        logradouro: cepInfo.logradouro,
        bairro: cepInfo.bairro || '',
        cidade: cepInfo.cidade,
        estado: cepInfo.estado,
        latitude: cepInfo.latitude ? String(cepInfo.latitude) : null,
        longitude: cepInfo.longitude ? String(cepInfo.longitude) : null,
      });
    }
    
    // Inserir os CEPs no banco de dados
    if (localCeps.length > 0) {
      console.log(`Importando ${localCeps.length} CEPs do arquivo local...`);
      
      // Processar em lotes para não sobrecarregar o banco de dados
      const batchSize = 100;
      for (let i = 0; i < localCeps.length; i += batchSize) {
        const batch = localCeps.slice(i, i + batchSize);
        await db.insert(ceps).values(batch).onConflictDoNothing();
      }
      
      console.log('CEPs locais importados com sucesso!');
    }
    
    // Adicionando CEPs comuns de São Paulo e Minas Gerais
    const additionalCeps: InsertCep[] = [
      // Principais cidades de São Paulo
      { cep: '01000-000', logradouro: 'Centro', bairro: 'Centro', cidade: 'São Paulo', estado: 'SP', latitude: '-23.5505', longitude: '-46.6333' },
      { cep: '13560-001', logradouro: 'Avenida São Carlos', bairro: 'Centro', cidade: 'São Carlos', estado: 'SP', latitude: '-22.0175', longitude: '-47.8908' },
      { cep: '13560-002', logradouro: 'Rua Episcopal', bairro: 'Centro', cidade: 'São Carlos', estado: 'SP', latitude: '-22.0175', longitude: '-47.8908' },
      { cep: '13560-003', logradouro: 'Rua Nove de Julho', bairro: 'Centro', cidade: 'São Carlos', estado: 'SP', latitude: '-22.0175', longitude: '-47.8908' },
      { cep: '13560-004', logradouro: 'Rua Aquidaban', bairro: 'Centro', cidade: 'São Carlos', estado: 'SP', latitude: '-22.0175', longitude: '-47.8908' },
      { cep: '13560-005', logradouro: 'Rua São Joaquim', bairro: 'Centro', cidade: 'São Carlos', estado: 'SP', latitude: '-22.0175', longitude: '-47.8908' },
      { cep: '13560-006', logradouro: 'Rua Dona Alexandrina', bairro: 'Centro', cidade: 'São Carlos', estado: 'SP', latitude: '-22.0175', longitude: '-47.8908' },
      { cep: '13560-007', logradouro: 'Rua Jesuíno de Arruda', bairro: 'Centro', cidade: 'São Carlos', estado: 'SP', latitude: '-22.0175', longitude: '-47.8908' },
      { cep: '13560-008', logradouro: 'Rua Bento Carlos', bairro: 'Centro', cidade: 'São Carlos', estado: 'SP', latitude: '-22.0175', longitude: '-47.8908' },
      { cep: '13560-009', logradouro: 'Rua Conde do Pinhal', bairro: 'Centro', cidade: 'São Carlos', estado: 'SP', latitude: '-22.0175', longitude: '-47.8908' },
      { cep: '13560-010', logradouro: 'Rua General Osório', bairro: 'Centro', cidade: 'São Carlos', estado: 'SP', latitude: '-22.0175', longitude: '-47.8908' },
      { cep: '13560-011', logradouro: 'Rua Treze de Maio', bairro: 'Centro', cidade: 'São Carlos', estado: 'SP', latitude: '-22.0175', longitude: '-47.8908' },
      { cep: '13560-012', logradouro: 'Rua Sete de Setembro', bairro: 'Centro', cidade: 'São Carlos', estado: 'SP', latitude: '-22.0175', longitude: '-47.8908' },
      
      // Outras cidades importantes de São Paulo
      { cep: '14801-300', logradouro: 'Centro', bairro: 'Centro', cidade: 'Araraquara', estado: 'SP', latitude: '-21.7845', longitude: '-48.1751' },
      { cep: '18035-000', logradouro: 'Centro', bairro: 'Centro', cidade: 'Sorocaba', estado: 'SP', latitude: '-23.5015', longitude: '-47.4526' },
      { cep: '15020-000', logradouro: 'Centro', bairro: 'Centro', cidade: 'São José do Rio Preto', estado: 'SP', latitude: '-20.8113', longitude: '-49.3758' },
      { cep: '12400-000', logradouro: 'Centro', bairro: 'Centro', cidade: 'Pindamonhangaba', estado: 'SP', latitude: '-22.9246', longitude: '-45.4613' },
      { cep: '13501-000', logradouro: 'Centro', bairro: 'Centro', cidade: 'Rio Claro', estado: 'SP', latitude: '-22.4156', longitude: '-47.5692' },
      { cep: '17201-000', logradouro: 'Centro', bairro: 'Centro', cidade: 'Jaú', estado: 'SP', latitude: '-22.2953', longitude: '-48.5586' },
      { cep: '16200-000', logradouro: 'Centro', bairro: 'Centro', cidade: 'Birigüi', estado: 'SP', latitude: '-21.2886', longitude: '-50.3399' },
      { cep: '12500-000', logradouro: 'Centro', bairro: 'Centro', cidade: 'Guaratinguetá', estado: 'SP', latitude: '-22.8168', longitude: '-45.1933' },
      
      // Principais cidades de Minas Gerais
      { cep: '30000-000', logradouro: 'Centro', bairro: 'Centro', cidade: 'Belo Horizonte', estado: 'MG', latitude: '-19.9167', longitude: '-43.9345' },
      { cep: '30140-000', logradouro: 'Savassi', bairro: 'Savassi', cidade: 'Belo Horizonte', estado: 'MG', latitude: '-19.9326', longitude: '-43.9354' },
      { cep: '32150-000', logradouro: 'Centro', bairro: 'Centro', cidade: 'Contagem', estado: 'MG', latitude: '-19.9319', longitude: '-44.0539' },
      { cep: '38400-000', logradouro: 'Centro', bairro: 'Centro', cidade: 'Uberlândia', estado: 'MG', latitude: '-18.9188', longitude: '-48.2769' },
      { cep: '37950-000', logradouro: 'Centro', bairro: 'Centro', cidade: 'São Sebastião do Paraíso', estado: 'MG', latitude: '-20.9167', longitude: '-46.9833' },
      { cep: '36770-000', logradouro: 'Centro', bairro: 'Centro', cidade: 'Cataguases', estado: 'MG', latitude: '-21.3925', longitude: '-42.6896' },
      { cep: '37900-000', logradouro: 'Centro', bairro: 'Centro', cidade: 'Passos', estado: 'MG', latitude: '-20.7187', longitude: '-46.6088' },
      { cep: '38180-000', logradouro: 'Centro', bairro: 'Centro', cidade: 'Araxá', estado: 'MG', latitude: '-19.5902', longitude: '-46.9438' },
      { cep: '36500-000', logradouro: 'Centro', bairro: 'Centro', cidade: 'Ubá', estado: 'MG', latitude: '-21.1207', longitude: '-42.9425' },
      { cep: '35170-000', logradouro: 'Centro', bairro: 'Centro', cidade: 'Coronel Fabriciano', estado: 'MG', latitude: '-19.5184', longitude: '-42.6276' },
      { cep: '37130-000', logradouro: 'Centro', bairro: 'Centro', cidade: 'Alfenas', estado: 'MG', latitude: '-21.4291', longitude: '-45.9474' },
      { cep: '35135-000', logradouro: 'Centro', bairro: 'Centro', cidade: 'Patrocínio', estado: 'MG', latitude: '-18.9386', longitude: '-46.9934' },
      { cep: '35010-000', logradouro: 'Centro', bairro: 'Centro', cidade: 'Governador Valadares', estado: 'MG', latitude: '-18.8528', longitude: '-41.9497' },
      { cep: '37200-000', logradouro: 'Centro', bairro: 'Centro', cidade: 'Lavras', estado: 'MG', latitude: '-21.2453', longitude: '-44.9996' },
      { cep: '36025-000', logradouro: 'Centro', bairro: 'Centro', cidade: 'Juiz de Fora', estado: 'MG', latitude: '-21.7596', longitude: '-43.3496' },
      { cep: '37704-000', logradouro: 'Centro', bairro: 'Centro', cidade: 'Poços de Caldas', estado: 'MG', latitude: '-21.7886', longitude: '-46.5614' },
      { cep: '35400-000', logradouro: 'Centro', bairro: 'Centro', cidade: 'Ouro Preto', estado: 'MG', latitude: '-20.3856', longitude: '-43.5035' },
      
      // Adicionando mais CEPs específicos de Ribeirão Preto
      { cep: '14091-000', logradouro: 'Parque Ribeirão Preto', bairro: 'Parque Ribeirão Preto', cidade: 'Ribeirão Preto', estado: 'SP', latitude: '-21.1900', longitude: '-47.7963' },
      { cep: '14091-100', logradouro: 'Rua Arnaldo Victaliano', bairro: 'Jardim Iguatemi', cidade: 'Ribeirão Preto', estado: 'SP', latitude: '-21.1946', longitude: '-47.7821' },
      { cep: '14091-200', logradouro: 'Rua Sebastião Maia', bairro: 'Jardim Iguatemi', cidade: 'Ribeirão Preto', estado: 'SP', latitude: '-21.1946', longitude: '-47.7821' },
      { cep: '14091-300', logradouro: 'Rua José Peres da Silva', bairro: 'Jardim Iguatemi', cidade: 'Ribeirão Preto', estado: 'SP', latitude: '-21.1946', longitude: '-47.7821' },
      { cep: '14091-400', logradouro: 'Rua João Lúcio da Silva', bairro: 'Jardim Iguatemi', cidade: 'Ribeirão Preto', estado: 'SP', latitude: '-21.1946', longitude: '-47.7821' },
      { cep: '14091-500', logradouro: 'Rua Juracy Faria Cardoso', bairro: 'Jardim Iguatemi', cidade: 'Ribeirão Preto', estado: 'SP', latitude: '-21.1946', longitude: '-47.7821' },
      { cep: '14091-510', logradouro: 'Rua Arnaldo Victaliano', bairro: 'Jardim Iguatemi', cidade: 'Ribeirão Preto', estado: 'SP', latitude: '-21.1946', longitude: '-47.7821' },
      { cep: '14091-520', logradouro: 'Rua Arnaldo Victaliano', bairro: 'Jardim Iguatemi', cidade: 'Ribeirão Preto', estado: 'SP', latitude: '-21.1946', longitude: '-47.7821' },
      { cep: '14091-530', logradouro: 'Rua Arnaldo Victaliano', bairro: 'Jardim Iguatemi', cidade: 'Ribeirão Preto', estado: 'SP', latitude: '-21.1946', longitude: '-47.7821' },
      { cep: '14091-540', logradouro: 'Avenida Costábile Romano', bairro: 'Jardim Iguatemi', cidade: 'Ribeirão Preto', estado: 'SP', latitude: '-21.1946', longitude: '-47.7821' },
      { cep: '14091-550', logradouro: 'Avenida Costábile Romano', bairro: 'Jardim Iguatemi', cidade: 'Ribeirão Preto', estado: 'SP', latitude: '-21.1946', longitude: '-47.7821' },
      
      // Adicionando CEPs específicos de Bauru (importantes para a aplicação)
      { cep: '17201-010', logradouro: 'Centro', bairro: 'Centro', cidade: 'Bauru', estado: 'SP', latitude: '-22.3147', longitude: '-49.0690' },
      { cep: '17201-020', logradouro: 'Rua Batista de Carvalho', bairro: 'Centro', cidade: 'Bauru', estado: 'SP', latitude: '-22.3190', longitude: '-49.0711' },
      { cep: '17201-030', logradouro: 'Avenida Getúlio Vargas', bairro: 'Jardim Europa', cidade: 'Bauru', estado: 'SP', latitude: '-22.3138', longitude: '-49.0680' },
      { cep: '17201-040', logradouro: 'Rua Gustavo Maciel', bairro: 'Centro', cidade: 'Bauru', estado: 'SP', latitude: '-22.3139', longitude: '-49.0685' },
      { cep: '17201-050', logradouro: 'Rua Padre João', bairro: 'Centro', cidade: 'Bauru', estado: 'SP', latitude: '-22.3155', longitude: '-49.0687' },
      { cep: '17010-130', logradouro: 'Rua Batista de Carvalho', bairro: 'Centro', cidade: 'Bauru', estado: 'SP', latitude: '-22.3190', longitude: '-49.0711' },
      { cep: '17010-140', logradouro: 'Rua Primeiro de Agosto', bairro: 'Centro', cidade: 'Bauru', estado: 'SP', latitude: '-22.3187', longitude: '-49.0720' },
      
      // Adicionando mais CEPs específicos de Dois Córregos
      { cep: '17300-000', logradouro: 'Centro', bairro: 'Centro', cidade: 'Dois Córregos', estado: 'SP', latitude: '-22.3696', longitude: '-48.3843' },
      { cep: '17300-100', logradouro: 'Avenida Marechal Castelo Branco', bairro: 'Centro', cidade: 'Dois Córregos', estado: 'SP', latitude: '-22.3696', longitude: '-48.3843' },
      { cep: '17300-200', logradouro: 'Avenida Antônio Sanches', bairro: 'Centro', cidade: 'Dois Córregos', estado: 'SP', latitude: '-22.3696', longitude: '-48.3843' },
      { cep: '17300-300', logradouro: 'Rua XV de Novembro', bairro: 'Centro', cidade: 'Dois Córregos', estado: 'SP', latitude: '-22.3696', longitude: '-48.3843' },
      { cep: '17300-400', logradouro: 'Rua IX de Julho', bairro: 'Centro', cidade: 'Dois Córregos', estado: 'SP', latitude: '-22.3696', longitude: '-48.3843' },
      { cep: '17300-500', logradouro: 'Rua Tiradentes', bairro: 'Centro', cidade: 'Dois Córregos', estado: 'SP', latitude: '-22.3696', longitude: '-48.3843' },
      { cep: '17301-000', logradouro: 'Bairro Jardim Arco Íris', bairro: 'Jardim Arco Íris', cidade: 'Dois Córregos', estado: 'SP', latitude: '-22.3676', longitude: '-48.3860' },
      { cep: '17302-000', logradouro: 'Bairro Vila Bandeirante', bairro: 'Vila Bandeirante', cidade: 'Dois Córregos', estado: 'SP', latitude: '-22.3730', longitude: '-48.3820' },
      { cep: '17302-120', logradouro: 'Rua 13 de Maio', bairro: 'Centro', cidade: 'Dois Córregos', estado: 'SP', latitude: '-22.3696', longitude: '-48.3843' },
      { cep: '17302-121', logradouro: 'Rua 13 de Maio', bairro: 'Centro', cidade: 'Dois Córregos', estado: 'SP', latitude: '-22.3696', longitude: '-48.3843' },
      { cep: '17302-122', logradouro: 'Rua 13 de Maio', bairro: 'Centro', cidade: 'Dois Córregos', estado: 'SP', latitude: '-22.3696', longitude: '-48.3843' },
      { cep: '17302-123', logradouro: 'Rua 13 de Maio', bairro: 'Centro', cidade: 'Dois Córregos', estado: 'SP', latitude: '-22.3696', longitude: '-48.3843' },
      { cep: '17302-124', logradouro: 'Rua 13 de Maio', bairro: 'Centro', cidade: 'Dois Córregos', estado: 'SP', latitude: '-22.3696', longitude: '-48.3843' },
      { cep: '17303-000', logradouro: 'Bairro Residencial Ouro Verde', bairro: 'Residencial Ouro Verde', cidade: 'Dois Córregos', estado: 'SP', latitude: '-22.3750', longitude: '-48.3830' },
    ];
    
    // Inserir os CEPs adicionais no banco de dados
    if (additionalCeps.length > 0) {
      console.log(`Importando ${additionalCeps.length} CEPs adicionais...`);
      
      // Processar em lotes para não sobrecarregar o banco de dados
      const batchSize = 100;
      for (let i = 0; i < additionalCeps.length; i += batchSize) {
        const batch = additionalCeps.slice(i, i + batchSize);
        await db.insert(ceps).values(batch).onConflictDoNothing();
      }
      
      console.log('CEPs adicionais importados com sucesso!');
    }
    
    // Contar quantos CEPs temos agora no banco de dados
    const count = await db.select({ count: sql`count(*)` }).from(ceps);
    console.log(`Total de CEPs no banco de dados: ${count[0].count}`);
    
    console.log('Importação de CEPs concluída com sucesso!');
  } catch (error) {
    console.error('Erro ao importar CEPs:', error);
  } finally {
    // Fechar a conexão com o banco de dados
    await pool.end();
  }
}

// Importando o tipo sql já foi feito acima

// Função principal que orquestra o processo inteiro
async function setupDatabase() {
  try {
    console.log('Iniciando setup completo do banco de dados...');
    
    // Primeiro, criar as tabelas
    console.log('Criando tabelas no banco de dados...');
    await createTables();
    console.log('Tabelas criadas com sucesso!');
    
    // Depois, popular com dados de CEPs
    console.log('Populando banco de dados com CEPs...');
    await populateCepsFromLocal();
    console.log('CEPs importados com sucesso!');
    
    console.log('Setup completo do banco de dados concluído com sucesso!');
  } catch (error) {
    console.error('Erro durante o setup do banco de dados:', error);
  } finally {
    // Fechar a conexão com o banco de dados
    await pool.end();
  }
}

// Executar o script principal
setupDatabase();