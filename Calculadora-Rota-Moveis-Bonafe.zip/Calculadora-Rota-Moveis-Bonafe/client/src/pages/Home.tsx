import { useState, lazy, Suspense, useEffect } from "react";
import { useMutation } from "@tanstack/react-query";
import { RouteForm } from "@/components/RouteForm";
import { LeafletMapComponent } from "@/components/LeafletMapComponent";
import { RouteActions } from "@/components/RouteActions";
import { PedagioDebugger } from "@/components/PedagioDebugger";
import { EconomyDashboard } from "@/components/EconomyDashboard";
import { TruckRestrictions } from "@/components/TruckRestrictions";
import { PeriodEvents } from "@/components/PeriodEvents";
import { RotaSumario } from "@/components/RotaSumario";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useLocation } from "wouter";

// Importar componente de mapa alternativo como lazy load para fallback
const LeafletMapComponentV2 = lazy(() => import('@/components/LeafletMapComponentV2').then(
  module => ({ default: module.LeafletMapComponentV2 })
));

// Definir o tipo de interface para instrução de rota
interface RouteInstruction {
  summary: string;
  distance: string;
  duration: string;
  steps: Array<{
    instruction: string;
    distance: string;
    duration: string;
  }>;
}

// Definir o tipo de veículo
type VehicleType = "carro" | "moto" | "caminhao" | "caminhao_2_eixos";

// Definir interface para pontos de interesse (POIs)
interface RoutePointOfInterest {
  tipo: 'tollbooth' | 'weighingstation';
  nome: string;
  posicao: [number, number];
  detalhe?: string;
  valor?: string;
  naRota?: boolean;
}

// Definir interface para rotas alternativas
interface RouteAlternative {
  polyline?: string;
  distancia?: string;
  tempo?: string;
  distanciaNumerica: number;
  tempoNumerico: number;
  destaque?: boolean;
}

// Definir interface de resposta de rota
interface RouteResponse {
  distanciaTotal: string;
  tempoTotal: string;
  rota?: any;
  origem: string;
  destino?: string;
  paradas?: string[];
  instrucoes?: RouteInstruction[];
  optimized?: boolean;
  originalWaypointsOrder?: string[];
  optimizedWaypointsOrder?: string[];
  dataInicioEntrega?: string;
  dataFimEntrega?: string;
  valorPedagios?: string;
  tipoVeiculo?: VehicleType;
  pontosInteresse?: RoutePointOfInterest[];
  rotasAlternativas?: RouteAlternative[];
}

export default function Home() {
  const { toast } = useToast();
  const [routeResult, setRouteResult] = useState<RouteResponse | null>(null);
  const [previewRoute, setPreviewRoute] = useState<RouteResponse | null>(null);
  const [isPreviewMode, setIsPreviewMode] = useState(false);
  const [activeTab, setActiveTab] = useState("mapa");
  const [location] = useLocation();
  const [sharedRouteData, setSharedRouteData] = useState<any>(null);
  
  // Efeito para carregar parâmetros da URL - isso é executado primeiro para armazenar os dados
  useEffect(() => {
    try {
      // Verificar se temos um parâmetro de rota na URL
      const urlParams = new URLSearchParams(window.location.search);
      const routeParam = urlParams.get('route');
      
      if (!routeParam) {
        return; // Sem parâmetro de rota, não faz nada
      }
      
      // Decodificar o parâmetro de rota Base64
      const decodedData = JSON.parse(atob(routeParam));
      console.log("Dados da rota carregados da URL:", decodedData);
      
      // Armazenar os dados para processamento posterior
      setSharedRouteData(decodedData);
    } catch (error) {
      console.error("Erro ao processar rota compartilhada:", error);
      toast({
        variant: "destructive",
        title: "Erro ao carregar rota compartilhada",
        description: "O link compartilhado parece ser inválido ou está corrompido.",
      });
    }
  }, [location, toast]);

  // Mutation para cálculo completo da rota
  const calculateRouteMutation = useMutation({
    mutationFn: async (routeData: { 
      origem: string; 
      paradas?: string[];
      nome?: string;
      otimizar?: boolean;
      dataInicioEntrega?: string;
      dataFimEntrega?: string;
      tipoVeiculo?: string;
    }) => {
      // apiRequest já retorna dados JSON, não há necessidade de chamar .json()
      console.log("Calculando rota com dados:", routeData);
      return await apiRequest("POST", "/api/routes/calculate", routeData);
    },
    onSuccess: (data: RouteResponse) => {
      setRouteResult(data);
      setIsPreviewMode(false); // Desativa modo de preview
      toast({
        title: "Rota calculada com sucesso!",
        description: `Distância total: ${data.distanciaTotal}, Tempo estimado: ${data.tempoTotal}`,
      });
    },
    onError: (error: any) => {
      let errorMessage = "Ocorreu um erro ao calcular a rota. Tente novamente.";
      
      if (error.response) {
        if (error.response.data?.message) {
          errorMessage = error.response.data.message;
        }
      } else if (error instanceof Error) {
        errorMessage = error.message;
      }
      
      toast({
        variant: "destructive",
        title: "Erro ao calcular rota",
        description: errorMessage,
      });
    },
  });
  
  // Mutation para pré-visualização da rota
  const previewRouteMutation = useMutation({
    mutationFn: async (routeData: { 
      origem: string; 
      paradas?: string[];
      otimizar?: boolean;
      dataInicioEntrega?: string;
      dataFimEntrega?: string;
      tipoVeiculo?: string;
    }) => {
      // apiRequest já retorna dados JSON, não há necessidade de chamar .json()
      console.log("Preview de rota com dados:", routeData);
      return await apiRequest("POST", "/api/routes/calculate", routeData);
    },
    onSuccess: (data: RouteResponse) => {
      setPreviewRoute(data);
      setIsPreviewMode(true);
      
      // Mudar para a aba de mapa para visualizar a rota
      setActiveTab("mapa");
    },
    onError: () => {
      // Não mostramos erros no preview para não interromper o fluxo do usuário
      setPreviewRoute(null);
      setIsPreviewMode(false);
    },
  });

  const handleRouteCalculation = (formData: { 
    origem: string; 
    paradas?: string[];
    nome?: string;
    otimizar?: boolean;
    dataInicioEntrega?: string;
    dataFimEntrega?: string;
    tipoVeiculo?: string;
  }) => {
    calculateRouteMutation.mutate(formData);
  };
  
  // Função para lidar com pré-visualização de rota
  const handleRoutePreview = (formData: {
    origem: string;
    paradas?: string[];
    otimizar?: boolean;
    dataInicioEntrega?: string;
    dataFimEntrega?: string;
    tipoVeiculo?: string;
  }) => {
    previewRouteMutation.mutate(formData);
  };
  
  // Efeito para processar os dados compartilhados quando necessário
  useEffect(() => {
    // Se temos dados de rota compartilhada e a mutação não está em andamento
    if (sharedRouteData && !calculateRouteMutation.isPending) {
      try {
        // Mapear os dados para o formato esperado pela API
        const routeData = {
          origem: sharedRouteData.o, // origem
          paradas: sharedRouteData.p, // paradas
          tipoVeiculo: sharedRouteData.v, // tipo de veículo
          dataInicioEntrega: sharedRouteData.di, // data de início de entrega (opcional)
          dataFimEntrega: sharedRouteData.df, // data de fim de entrega (opcional)
          otimizar: sharedRouteData.opt === 1 // otimização ativada ou não
        };
        
        // Verificar se temos pelo menos a origem
        if (routeData.origem) {
          console.log("Processando cálculo de rota compartilhada:", routeData);
          
          // Processar o cálculo da rota
          calculateRouteMutation.mutate(routeData);
          
          // Mostrar toast informando que uma rota compartilhada foi carregada
          toast({
            title: "Rota compartilhada carregada",
            description: "Carregamos uma rota que foi compartilhada com você.",
          });
          
          // Limpar os dados para não processar novamente
          setSharedRouteData(null);
        }
      } catch (error) {
        console.error("Erro ao processar rota compartilhada:", error);
        setSharedRouteData(null);
      }
    }
  }, [sharedRouteData, calculateRouteMutation, toast]);

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6 text-center">Calculadora de Rotas para Transportadoras</h1>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-1">
          <Card>
            <CardContent className="p-4">
              <RouteForm 
                onSubmit={handleRouteCalculation}
                onPreviewRoute={handleRoutePreview}
                isLoading={calculateRouteMutation.isPending || previewRouteMutation.isPending}
              />
            </CardContent>
          </Card>

          {(routeResult || (isPreviewMode && previewRoute)) && (
            <Card className="mt-4">
              <CardContent className="p-4">
                <RotaSumario routeResult={isPreviewMode ? previewRoute : routeResult} />
              </CardContent>
            </Card>
          )}
          
          {/* Componente RouteActions foi movido para cá, abaixo do resumo da rota */}
          {routeResult && (
            <Card className="mt-4">
              <CardContent className="p-4">
                <RouteActions routeResult={routeResult} />
              </CardContent>
            </Card>
          )}
        </div>

        <div className="lg:col-span-2">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="mb-4 w-full justify-start">
              <TabsTrigger value="mapa">Mapa</TabsTrigger>
              <TabsTrigger value="detalhes">Detalhes da Rota</TabsTrigger>
              <TabsTrigger value="debug">Debug</TabsTrigger>
            </TabsList>
            
            <TabsContent value="mapa" className="m-0">
              <Card>
                <CardContent className="p-4">
                  <div className="h-[500px] relative">
                    <Suspense fallback={<div className="flex h-full items-center justify-center">Carregando mapa...</div>}>
                      <LeafletMapComponentV2 
                        routeResult={isPreviewMode ? previewRoute : routeResult} 
                      />
                    </Suspense>
                    {isPreviewMode && previewRoute && (
                      <div className="mt-2 p-2 bg-yellow-50 border border-yellow-200 rounded text-sm">
                        <p className="font-medium text-yellow-700">Modo de pré-visualização</p>
                        <p className="text-yellow-600 text-xs">
                          Distância estimada: {previewRoute.distanciaTotal}, 
                          Tempo estimado: {previewRoute.tempoTotal}
                        </p>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
              
              {routeResult && routeResult.paradas && (
                <Card className="mt-6">
                  <CardContent className="p-4">
                    <TruckRestrictions 
                      origem={routeResult.origem}
                      paradas={routeResult.paradas}
                      destino={routeResult.destino}
                    />
                  </CardContent>
                </Card>
              )}
              
              {routeResult && routeResult.paradas && (
                <PeriodEvents 
                  origem={routeResult.origem}
                  paradas={routeResult.paradas}
                  destino={routeResult.destino}
                  dataInicioEntrega={routeResult.dataInicioEntrega}
                  dataFimEntrega={routeResult.dataFimEntrega}
                />
              )}
            </TabsContent>
              
            <TabsContent value="detalhes" className="m-0">
              <Card>
                <CardContent className="p-4">
                  {routeResult && routeResult.instrucoes && routeResult.instrucoes.length > 0 ? (
                    <div className="route-details">
                      <h3 className="text-lg font-semibold mb-2">Instruções da Rota</h3>
                      <div className="space-y-2">
                        {routeResult.instrucoes.map((segmento, idx) => (
                          <div key={idx} className="border-b pb-2 mb-2">
                            <h4 className="font-medium">
                              {idx === 0 
                                ? `Da origem para ${routeResult.paradas && routeResult.paradas.length > 0 
                                  ? `parada ${idx + 1}` 
                                  : 'o destino'}`
                                : idx === (routeResult.instrucoes?.length || 0) - 1 && routeResult.paradas 
                                  ? `Da parada ${idx} para o destino` 
                                  : `Da parada ${idx} para parada ${idx + 1}`
                              }
                            </h4>
                            <div className="text-sm text-gray-600">
                              Distância: {segmento.distance}, Tempo: {segmento.duration}
                            </div>
                            <ol className="list-decimal pl-5 mt-2 text-sm">
                              {segmento.steps.map((step, stepIndex) => (
                                <li key={stepIndex} className="mb-1">
                                  <div>{step.instruction}</div>
                                  <div className="text-xs text-gray-500">
                                    {step.distance} - {step.duration}
                                  </div>
                                </li>
                              ))}
                            </ol>
                          </div>
                        ))}
                      </div>
                    </div>
                  ) : (
                    <div className="text-center py-10 text-gray-500">
                      {routeResult 
                        ? "Calculando instruções da rota... Aguarde."
                        : "Calcule uma rota para ver os detalhes"}
                    </div>
                  )}
                </CardContent>
              </Card>
              
              {routeResult && routeResult.paradas && (
                <Card className="mt-4">
                  <CardContent className="p-4">
                    <TruckRestrictions 
                      origem={routeResult.origem}
                      paradas={routeResult.paradas}
                      destino={routeResult.destino}
                    />
                  </CardContent>
                </Card>
              )}
            </TabsContent>
            
            <TabsContent value="debug" className="m-0">
              <Card>
                <CardContent className="p-4">
                  <PedagioDebugger />
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}
