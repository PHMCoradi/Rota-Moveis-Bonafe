declare module 'canvas-confetti' {
  interface ConfettiOptions {
    particleCount?: number;
    angle?: number;
    spread?: number;
    startVelocity?: number;
    decay?: number;
    gravity?: number;
    drift?: number;
    ticks?: number;
    origin?: {
      x?: number;
      y?: number;
    };
    colors?: string[];
    shapes?: string[];
    scalar?: number;
    zIndex?: number;
    disableForReducedMotion?: boolean;
    useWorker?: boolean;
  }

  function confetti(options?: ConfettiOptions): Promise<null>;
  function create(canvas: HTMLCanvasElement, options?: { resize?: boolean; useWorker?: boolean }): {
    (options?: ConfettiOptions): Promise<null>;
    reset: () => void;
  };
  function reset(): void;

  export default confetti;
  export { create, reset };
}