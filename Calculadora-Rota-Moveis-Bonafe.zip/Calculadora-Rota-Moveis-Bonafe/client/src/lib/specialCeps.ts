/**
 * Mapeamento especial de CEPs para coordenadas específicas
 * Esse arquivo contém as coordenadas precisas para CEPs problemáticos
 */

// Interface para o tipo de dado de coordenadas especiais
export interface SpecialCoordinates {
  lat: number;
  lng: number;
  name: string;
}

// Mapeamento de CEPs para coordenadas especiais
export const specialCepsCoordinates: Record<string, SpecialCoordinates> = {
  // Ribeirão Preto - SP
  // Rua Arnaldo Victaliano (Jardim Iguatemi)
  '14091-530': {
    lat: -21.19465085439178,
    lng: -47.78211921523098,
    name: 'Rua Arnaldo Victaliano, Jardim Iguatemi, Ribeirão Preto - SP'
  },
  '14091530': {
    lat: -21.19465085439178,
    lng: -47.78211921523098,
    name: 'Rua Arnaldo Victaliano, Jardim Iguatemi, Ribeirão Preto - SP'
  },

  // Dois Córregos - SP
  // Rua 13 de Maio (Centro)
  '17302-122': {
    lat: -22.369668,
    lng: -48.384283,
    name: 'Rua 13 de Maio, Centro, Dois Córregos - SP'
  },
  '17302122': {
    lat: -22.369668,
    lng: -48.384283,
    name: 'Rua 13 de Maio, Centro, Dois Córregos - SP'
  },

  // São Carlos - SP
  // Rua General Osório (Centro)
  '13560-010': {
    lat: -22.017496,
    lng: -47.89067,
    name: 'Rua General Osório, Centro, São Carlos - SP'
  },
  '13560010': {
    lat: -22.017496,
    lng: -47.89067,
    name: 'Rua General Osório, Centro, São Carlos - SP'
  },

  // Araraquara - SP
  // Rua Itália (Centro)
  '14800-022': {
    lat: -21.253034,
    lng: -48.979304,
    name: 'Rua Itália, Centro, Araraquara - SP'
  },
  '14800022': {
    lat: -21.253034,
    lng: -48.979304,
    name: 'Rua Itália, Centro, Araraquara - SP'
  },

  // Atibaia - SP
  // Rua Prefeito José Pires (Centro)
  '12946-851': {
    lat: -22.666643,
    lng: -46.984514,
    name: 'Rua Prefeito José Pires, Centro, Atibaia - SP'
  },
  '12946851': {
    lat: -22.666643,
    lng: -46.984514,
    name: 'Rua Prefeito José Pires, Centro, Atibaia - SP'
  },

  // Jaú - SP
  // Avenida Brasil (Centro)
  '17320-015': {
    lat: -22.325387,
    lng: -49.052985,
    name: 'Avenida Brasil, Centro, Jaú - SP'
  },
  '17320015': {
    lat: -22.325387,
    lng: -49.052985,
    name: 'Avenida Brasil, Centro, Jaú - SP'
  },

  // Bauru - SP
  // Avenida Getúlio Vargas (Jardim Europa)
  '17201-030': {
    lat: -22.313841,
    lng: -49.068033,
    name: 'Avenida Getúlio Vargas, Jardim Europa, Bauru - SP'
  },
  '17201030': {
    lat: -22.313841,
    lng: -49.068033,
    name: 'Avenida Getúlio Vargas, Jardim Europa, Bauru - SP'
  },
  // Adicionar para o CEP 17201-010 também
  '17201-010': {
    lat: -22.314689,
    lng: -49.068985,
    name: 'Centro, Bauru - SP'
  },
  '17201010': {
    lat: -22.314689,
    lng: -49.068985,
    name: 'Centro, Bauru - SP'
  },
  // Adicionar para o CEP 13010-002 também
  '13010-002': {
    lat: -22.903103,
    lng: -47.060410,
    name: 'Campinas - SP'
  },
  '13010002': {
    lat: -22.903103,
    lng: -47.060410,
    name: 'Campinas - SP'
  }
};

/**
 * Função para obter coordenadas de um CEP específico
 * @param cep CEP a ser verificado (com ou sem formatação)
 * @returns Coordenadas especiais ou undefined se não encontrado
 */
export function getSpecialCoordinates(cep: string): SpecialCoordinates | undefined {
  // Normalizar CEP para busca (remover caracteres não numéricos)
  const normalizedCep = cep.replace(/\D/g, '');
  
  // Verificar primeiro o formato com hífen (XXXXX-XXX)
  const formattedCep = `${normalizedCep.substring(0, 5)}-${normalizedCep.substring(5)}`;
  
  // Tentar buscar com formato XXXXX-XXX e depois com formato sem hífen
  return specialCepsCoordinates[formattedCep] || specialCepsCoordinates[normalizedCep];
}

/**
 * Verifica se um endereço contém algum dos CEPs especiais
 * @param address Endereço completo a ser verificado
 * @returns Coordenadas especiais para o CEP encontrado ou undefined
 */
export function findSpecialCepInAddress(address: string): SpecialCoordinates | undefined {
  // Extrair CEP do endereço (se presente)
  const cepMatch = address.match(/\d{5}[-.\s]?\d{3}/);
  if (cepMatch) {
    const cep = cepMatch[0];
    return getSpecialCoordinates(cep);
  }
  
  // Verificar todos os CEPs especiais para ver se fazem parte do endereço
  for (const [cep, coordinates] of Object.entries(specialCepsCoordinates)) {
    // Para CEPs sem hífen, adicionar o hífen para evitar falsos positivos
    if (cep.length === 8) continue; // Pulamos os CEPs sem hífen no teste
    
    if (address.includes(cep)) {
      return coordinates;
    }
  }
  
  // Verificar se o endereço contém algum dos nomes das ruas especiais
  // (casos como Arnaldo Victaliano, General Osório, etc)
  const addressLower = address.toLowerCase();
  
  if (addressLower.includes('arnaldo victaliano')) {
    return specialCepsCoordinates['14091-530'];
  }
  
  if (addressLower.includes('13 de maio') && addressLower.includes('dois córregos')) {
    return specialCepsCoordinates['17302-122'];
  }
  
  if (addressLower.includes('general osório') && addressLower.includes('são carlos')) {
    return specialCepsCoordinates['13560-010'];
  }
  
  if (addressLower.includes('rua itália') && addressLower.includes('araraquara')) {
    return specialCepsCoordinates['14800-022'];
  }
  
  if (addressLower.includes('prefeito josé pires') && addressLower.includes('atibaia')) {
    return specialCepsCoordinates['12946-851'];
  }
  
  if (addressLower.includes('avenida brasil') && addressLower.includes('jaú')) {
    return specialCepsCoordinates['17320-015'];
  }
  
  if (addressLower.includes('getúlio vargas') && addressLower.includes('bauru')) {
    return specialCepsCoordinates['17201-030'];
  }
  
  // Adicionar os novos CEPs
  if (addressLower.includes('bauru')) {
    // Preferir um CEP específico se disponível, caso contrário usar o genérico
    for (const bairroCep of ['17201-030', '17201-010']) {
      if (addressLower.includes(bairroCep.replace('-', ''))) {
        return specialCepsCoordinates[bairroCep];
      }
    }
    // Caso genérico para Bauru
    return specialCepsCoordinates['17201-010']; 
  }
  
  // Campinas
  if (addressLower.includes('campinas') || addressLower.includes('13010')) {
    return specialCepsCoordinates['13010-002'];
  }
  
  return undefined;
}