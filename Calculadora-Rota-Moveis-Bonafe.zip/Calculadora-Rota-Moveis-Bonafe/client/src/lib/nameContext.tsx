import React, { createContext, useState, useContext, useEffect } from 'react';

// Interface do contexto
interface CustomNameContextType {
  customNames: Record<string, string>;
  updateName: (key: string, name: string) => void;
  removeName: (key: string) => void;
  clearAll: () => void; // Novo método para limpar todos os nomes
}

// Criando o contexto com valor padrão
const CustomNameContext = createContext<CustomNameContextType>({
  customNames: {},
  updateName: () => {},
  removeName: () => {},
  clearAll: () => {} // Implementação vazia para o valor padrão
});

// Hook para usar o contexto
export const useCustomNames = () => useContext(CustomNameContext);

// Função utilitária para limpar completamente todos os nomes personalizados
export function clearAllCustomNames() {
  try {
    // Remover completamente do localStorage
    localStorage.removeItem('paradaNomes');
    // Depois definir como objeto vazio
    localStorage.setItem('paradaNomes', JSON.stringify({}));
    console.log('Todos os nomes personalizados foram limpos');
    return {};
  } catch (error) {
    console.error('Erro ao limpar nomes personalizados:', error);
    return {};
  }
}

// Função utilitária para forçar a sincronização de nomes a partir de um objeto de novos nomes
export function forceUpdateCustomNames(newNames: Record<string, string>) {
  try {
    // Primeiro limpar todos os nomes do localStorage
    localStorage.removeItem('paradaNomes');
    
    // Depois definir os novos nomes
    localStorage.setItem('paradaNomes', JSON.stringify(newNames));
    
    console.log('Nomes personalizados forçados para atualização:', newNames);
    
    // Verificar se a atualização foi bem-sucedida
    const storedNames = localStorage.getItem('paradaNomes');
    const parsedNames = storedNames ? JSON.parse(storedNames) : {};
    
    if (Object.keys(parsedNames).length !== Object.keys(newNames).length) {
      console.warn('Aviso: Diferença no número de nomes personalizados após atualização forçada');
      console.warn('Esperado:', Object.keys(newNames).length);
      console.warn('Atual:', Object.keys(parsedNames).length);
    }
    
    return parsedNames;
  } catch (error) {
    console.error('Erro ao forçar atualização de nomes personalizados:', error);
    return {};
  }
}

// Função utilitária para redefinir nomes e adicionar valores padrão
export function resetCustomNamesAndAddDefaults() {
  try {
    // Primeiro limpar todos os nomes
    clearAllCustomNames();
    
    // Valores padrão para nomes personalizados
    const defaultNames: Record<string, string> = {
      "17302-122": "TESTE 3",
      "14091-530": "TESTE 4"
    };
    
    // Salvar no localStorage
    localStorage.setItem('paradaNomes', JSON.stringify(defaultNames));
    console.log('Nomes personalizados redefinidos para valores padrão:', defaultNames);
    
    // Não recarregar a página para não interromper o fluxo de importação
    // O contexto será atualizado pela próxima renderização
    
    return defaultNames;
  } catch (error) {
    console.error('Erro ao redefinir nomes personalizados:', error);
    return {};
  }
}

// Função para extrair CEP de um endereço
function extractCepFromAddress(address: string): string | null {
  const cepRegex = /\b(\d{5})[-.\s]?(\d{3})\b/;
  const match = address.match(cepRegex);
  if (match) {
    return `${match[1]}-${match[2]}`;
  }
  return null;
}

// Hook personalizado para obter nome personalizado de uma parada
export function useGetNomePersonalizado() {
  const { customNames } = useCustomNames();
  
  return (endereco: string): string | null => {
    try {
      // Estratégia 1: Verificar por CEP
      const cep = extractCepFromAddress(endereco);
      if (cep && customNames[cep]) {
        // Retornar o nome exatamente como está armazenado, sem formatação
        const name = customNames[cep];
        return name;
      }
      
      // Estratégia 2: Verificar endereço completo
      if (customNames[endereco]) {
        // Retornar o nome exatamente como está armazenado, sem formatação
        const name = customNames[endereco];
        return name;
      }
      
      // Retornar null se não encontrar nome personalizado
      return null;
    } catch (error) {
      console.error('Erro ao buscar nome personalizado:', error);
      return null;
    }
  };

  // A formatação de nomes foi removida para preservar o formato original
}

// Provedor do contexto
export const CustomNameProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [customNames, setCustomNames] = useState<Record<string, string>>({});

  // Carregar nomes personalizados do localStorage ao montar o componente
  useEffect(() => {
    try {
      const storedNames = localStorage.getItem('paradaNomes');
      if (storedNames) {
        const parsedNames = JSON.parse(storedNames);
        
        // Remover o nome fixo para o CEP 14091-530 que estava predefinido
        if (parsedNames["14091-530"] === "Pedro") {
          delete parsedNames["14091-530"];
          // Atualizar o localStorage sem esse nome fixo
          localStorage.setItem('paradaNomes', JSON.stringify(parsedNames));
          console.log('Nome fixo "Pedro" para CEP 14091-530 removido');
        }
        
        setCustomNames(parsedNames);
        console.log('Nomes personalizados carregados do localStorage:', parsedNames);
      }
    } catch (error) {
      console.error('Erro ao carregar nomes personalizados:', error);
    }
  }, []);

  // Atualizar um nome personalizado
  const updateName = (key: string, name: string) => {
    const updatedNames = { ...customNames, [key]: name };
    setCustomNames(updatedNames);
    
    // Persistir no localStorage
    try {
      localStorage.setItem('paradaNomes', JSON.stringify(updatedNames));
      console.log(`Nome personalizado atualizado: ${key} => ${name}`);
    } catch (error) {
      console.error('Erro ao salvar nome personalizado:', error);
    }
  };

  // Remover um nome personalizado
  const removeName = (key: string) => {
    const updatedNames = { ...customNames };
    delete updatedNames[key];
    setCustomNames(updatedNames);
    
    // Persistir no localStorage
    try {
      localStorage.setItem('paradaNomes', JSON.stringify(updatedNames));
      console.log(`Nome personalizado removido: ${key}`);
    } catch (error) {
      console.error('Erro ao remover nome personalizado:', error);
    }
  };

  // Limpar todos os nomes personalizados - versão melhorada para evitar problemas de sincronização
  const clearAll = () => {
    console.log('Executando clearAll no contexto - Estado anterior:', customNames);
    
    try {
      // Remover do localStorage primeiro (método mais direto)
      localStorage.removeItem('paradaNomes');
      
      // Definir explicitamente como objeto vazio no localStorage
      localStorage.setItem('paradaNomes', JSON.stringify({}));
      
      // Certificar-se que o localStorage realmente foi atualizado
      const checkStorage = localStorage.getItem('paradaNomes');
      console.log('Estado do localStorage após remoção:', checkStorage);
      
      // Limpar o estado do React DEPOIS de limpar localStorage
      setCustomNames({});
      
      // Forçar uma renderização imediata com um setTimeout de 0ms
      setTimeout(() => {
        const emptyObject = {};
        setCustomNames(emptyObject);
        console.log('Estado do React após limpeza:', emptyObject);
        
        // Dupla verificação do localStorage
        const finalCheck = localStorage.getItem('paradaNomes');
        console.log('Verificação final do localStorage:', finalCheck);
        
        // Exibir mensagem de conclusão
        console.log('Todos os nomes personalizados foram limpos pelo contexto - atualizando UI');
      }, 0);
    } catch (error) {
      console.error('Erro ao limpar todos os nomes personalizados:', error);
    }
  };

  return (
    <CustomNameContext.Provider value={{ customNames, updateName, removeName, clearAll }}>
      {children}
    </CustomNameContext.Provider>
  );
};