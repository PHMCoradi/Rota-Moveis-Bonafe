/**
 * Arquivo com informações sobre restrições de trânsito de caminhões em cidades brasileiras
 * Dados baseados em informações das prefeituras e DENATRAN
 */

export interface TruckRestriction {
  cidade: string;
  uf: string;
  descricao: string;
  horarios: string[];
  diasSemana: string[];
  tiposVeiculo: string[];
  areas: string;
  excecoes: string;
  observacoes?: string;
}

// Lista de restrições para caminhões em cidades brasileiras
export const truckRestrictions: TruckRestriction[] = [
  {
    cidade: "São Paulo",
    uf: "SP",
    descricao: "Zona de Máxima Restrição de Circulação (ZMRC)",
    horarios: ["7h às 10h", "17h às 20h"],
    diasSemana: ["Segunda a Sexta"],
    tiposVeiculo: ["Caminhões em geral (VUC tem regras especiais)"],
    areas: "Centro expandido, definido por um minianel viário",
    excecoes: "Veículos Urbanos de Carga (VUC), serviços essenciais, casos específicos com autorização especial",
    observacoes: "Multa para descumprimento: infração média, 4 pontos na CNH"
  },
  {
    cidade: "Ribeirão Preto",
    uf: "SP",
    descricao: "Restrição para veículos pesados no centro",
    horarios: ["7h às 19h"],
    diasSemana: ["Segunda a Sexta", "7h às 13h aos Sábados"],
    tiposVeiculo: ["Caminhões acima de 2 eixos"],
    areas: "Região central delimitada pelas avenidas principais",
    excecoes: "Caminhões com autorização especial, veículos de serviços essenciais",
    observacoes: "Caminhões de 2 eixos podem circular mediante autorização prévia em alguns horários"
  },
  {
    cidade: "Bauru",
    uf: "SP",
    descricao: "Restrição no centro comercial",
    horarios: ["8h às 18h"],
    diasSemana: ["Segunda a Sexta", "8h às 13h aos Sábados"],
    tiposVeiculo: ["Caminhões acima de 6m de comprimento"],
    areas: "Quadrilátero central",
    excecoes: "Carga e descarga em horários específicos mediante autorização",
    observacoes: "Verificar sinalização local para rotas alternativas"
  },
  {
    cidade: "Campinas",
    uf: "SP",
    descricao: "Zona de Restrição Máxima",
    horarios: ["7h às 20h"],
    diasSemana: ["Segunda a Sexta", "7h às 14h aos Sábados"],
    tiposVeiculo: ["Caminhões em geral"],
    areas: "Centro expandido e principais corredores comerciais",
    excecoes: "Caminhões de pequeno porte para entregas locais em horários específicos",
    observacoes: "Necessária autorização especial para operações de carga/descarga"
  },
  {
    cidade: "Rio Claro",
    uf: "SP",
    descricao: "Restrição no centro",
    horarios: ["8h às 18h"],
    diasSemana: ["Segunda a Sexta"],
    tiposVeiculo: ["Caminhões acima de 7 toneladas"],
    areas: "Área central",
    excecoes: "Veículos de serviços públicos e emergências",
    observacoes: "Consultar Prefeitura para autorizações especiais"
  },
  {
    cidade: "Jaú",
    uf: "SP",
    descricao: "Restrição no centro comercial",
    horarios: ["9h às 19h"],
    diasSemana: ["Segunda a Sexta", "9h às 13h aos Sábados"],
    tiposVeiculo: ["Caminhões acima de 2 eixos"],
    areas: "Centro comercial",
    excecoes: "Serviços essenciais",
    observacoes: "Há áreas de estacionamento específicas nas bordas da cidade"
  },
  {
    cidade: "Araraquara",
    uf: "SP",
    descricao: "Restrição na zona central",
    horarios: ["8h às 19h"],
    diasSemana: ["Segunda a Sexta", "8h às 14h aos Sábados"],
    tiposVeiculo: ["Caminhões acima de 7 toneladas"],
    areas: "Perímetro central",
    excecoes: "Veículos com autorização especial da prefeitura",
    observacoes: "Caminhões menores podem solicitar permissão para entregas"
  },
  {
    cidade: "Belo Horizonte",
    uf: "MG",
    descricao: "Zona de Restrição de Circulação",
    horarios: ["7h às 20h"],
    diasSemana: ["Segunda a Sexta", "7h às 14h aos Sábados"],
    tiposVeiculo: ["Caminhões acima de 5 toneladas"],
    areas: "Centro e principais avenidas",
    excecoes: "Caminhões com autorização especial, serviços essenciais",
    observacoes: "Verificar atualização das normas junto à BHTrans"
  },
  {
    cidade: "Curitiba",
    uf: "PR",
    descricao: "Zona de Restrição de Tráfego",
    horarios: ["7h às 19h"],
    diasSemana: ["Segunda a Sexta"],
    tiposVeiculo: ["Caminhões em geral"],
    areas: "Centro e vias principais",
    excecoes: "Veículos autorizados para carga e descarga em horários específicos",
    observacoes: "Consultar a regulamentação atualizada da URBS"
  },
  {
    cidade: "Porto Alegre",
    uf: "RS",
    descricao: "Área de Restrição ao Tráfego de Veículos Pesados",
    horarios: ["7h às 19h"],
    diasSemana: ["Segunda a Sexta", "7h às 14h aos Sábados"],
    tiposVeiculo: ["Caminhões acima de 10 toneladas"],
    areas: "Centro histórico e comercial",
    excecoes: "Serviços públicos, mudanças (com autorização prévia)",
    observacoes: "Existem locais específicos para carga e descarga"
  }
];

/**
 * Verifica se uma cidade tem restrições de circulação para caminhões
 * @param cidade Nome da cidade para verificar
 * @param uf UF da cidade (opcional, para maior precisão)
 * @returns Array de restrições encontradas para a cidade
 */
export function verificarRestricoesCidade(cidade: string, uf?: string): TruckRestriction[] {
  // Normalizar para comparação
  const cidadeNormalizada = cidade.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
  
  return truckRestrictions.filter(restricao => {
    const restricaoCidadeNormalizada = restricao.cidade.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
    
    // Se temos UF, verificar também
    if (uf) {
      return restricaoCidadeNormalizada.includes(cidadeNormalizada) && restricao.uf === uf;
    }
    
    // Sem UF, verificar apenas cidade
    return restricaoCidadeNormalizada.includes(cidadeNormalizada);
  });
}

/**
 * Extrai o nome da cidade de um endereço completo
 * @param endereco Endereço completo
 * @returns Nome da cidade extraído
 */
export function extrairCidadeDeEndereco(endereco: string): { cidade: string, uf?: string } {
  // Verificar se é um CEP
  const cepRegex = /^\d{5}-?\d{3}$/;
  if (cepRegex.test(endereco.trim())) {
    // Se for um CEP, vamos retornar uma cidade genérica
    // Será tratado melhor quando tivermos a base de CEPs completa
    // Tratamento específico para cidades conhecidas por CEP
    if (endereco.startsWith('14') && !endereco.startsWith('140')) {
      return { cidade: "Ribeirão Preto", uf: "SP" };
    } else if (endereco.startsWith('17')) {
      return { cidade: "Bauru", uf: "SP" };
    } else if (endereco.startsWith('13')) {
      return { cidade: "Campinas", uf: "SP" };
    } else if (endereco.startsWith('01') || endereco.startsWith('02') || 
               endereco.startsWith('03') || endereco.startsWith('04') || 
               endereco.startsWith('05') || endereco.startsWith('06') || 
               endereco.startsWith('07') || endereco.startsWith('08')) {
      return { cidade: "São Paulo", uf: "SP" };
    }
    
    // CEP sem cidade específica identificada
    return { cidade: "Não identificada (CEP)" };
  }

  // Verificar formato cidade-UF
  const cidadeUfMatch = endereco.match(/([A-Za-zÀ-ÖØ-öø-ÿ\s]+)-(SP|MG|PR|RS|SC|MS|MT|GO|DF|RJ|ES|BA|SE|AL|PE|PB|RN|CE|PI|MA|TO|PA|AP|RR|AM|AC|RO)/i);
  if (cidadeUfMatch) {
    return { 
      cidade: cidadeUfMatch[1].trim(),
      uf: cidadeUfMatch[2].toUpperCase()
    };
  }
  
  // Verificar se contém Ribeirão Preto em qualquer parte do texto
  if (endereco.toLowerCase().includes('ribeirao preto') || endereco.toLowerCase().includes('ribeirão preto')) {
    return { cidade: "Ribeirão Preto", uf: "SP" };
  }
  
  // Tentar extrair da vírgula - formato comum "Rua X, Bairro, Cidade - UF"
  const parts = endereco.split(',');
  if (parts.length >= 3) {
    // A cidade geralmente é o penúltimo antes do UF
    let cidadeParte = parts[parts.length - 2].trim();
    
    // Verificar se tem traço com UF
    const cidadeUfTraco = cidadeParte.match(/(.+)\s*-\s*(SP|MG|PR|RS|SC|MS|MT|GO|DF|RJ|ES|BA|SE|AL|PE|PB|RN|CE|PI|MA|TO|PA|AP|RR|AM|AC|RO)/i);
    if (cidadeUfTraco) {
      return { 
        cidade: cidadeUfTraco[1].trim(),
        uf: cidadeUfTraco[2].toUpperCase()
      };
    }
    
    return { cidade: cidadeParte };
  }
  
  // Se não conseguiu extrair, retorna uma parte do endereço que pode conter a cidade
  // Isso é uma aproximação
  const partesEspaco = endereco.split(' ');
  if (partesEspaco.length > 3) {
    // Tenta pegar uma parte intermediária que pode ser a cidade
    return { cidade: partesEspaco[Math.floor(partesEspaco.length / 2)] };
  }
  
  // Último recurso, retorna o endereço como está
  return { cidade: endereco };
}

/**
 * Verifica restrições para um array de cidades
 * @param cidades Array de nomes de cidades
 * @returns Array de restrições para as cidades informadas
 */
export function verificarRestricoesCidades(cidades: Array<string | { cidade: string, uf?: string }>): TruckRestriction[] {
  const todasRestricoes: TruckRestriction[] = [];
  
  cidades.forEach(cidadeItem => {
    let cidade: string;
    let uf: string | undefined;
    
    if (typeof cidadeItem === 'string') {
      const extraido = extrairCidadeDeEndereco(cidadeItem);
      cidade = extraido.cidade;
      uf = extraido.uf;
    } else {
      cidade = cidadeItem.cidade;
      uf = cidadeItem.uf;
    }
    
    const restricoes = verificarRestricoesCidade(cidade, uf);
    
    // Adiciona apenas restrições que ainda não estão na lista
    restricoes.forEach(restricao => {
      if (!todasRestricoes.some(r => r.cidade === restricao.cidade && r.uf === restricao.uf)) {
        todasRestricoes.push(restricao);
      }
    });
  });
  
  return todasRestricoes;
}