import { DirectionsResult } from "@googlemaps/google-maps-services-js";

// Interface para resposta do Google Maps Directions API
export interface GoogleMapsDirectionsResponse {
  routes: {
    legs: {
      distance: {
        text: string;
        value: number;
      };
      duration: {
        text: string;
        value: number;
      };
      start_address: string;
      end_address: string;
      steps: {
        distance: {
          text: string;
          value: number;
        };
        duration: {
          text: string;
          value: number;
        };
        html_instructions: string;
        travel_mode: string;
      }[];
    }[];
  }[];
}

// Interface para os detalhes da rota calculada
export interface RouteDetails {
  origin: string;
  destination: string;
  waypoints?: string[];
  distance: string;
  duration: string;
  directions: DirectionsResult;
  created: Date;
}

// Interface para os pontos de uma rota
export interface WaypointData {
  location: string;
  stopover: boolean;
}

// Configurações para a exportação da rota
export interface RouteExportOptions {
  includeMap: boolean;
  includeDirections: boolean;
  format: 'pdf' | 'csv' | 'print';
}
