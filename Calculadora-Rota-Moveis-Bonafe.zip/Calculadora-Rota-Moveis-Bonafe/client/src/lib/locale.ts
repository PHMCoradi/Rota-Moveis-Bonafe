// Configuração de locale para o português brasileiro

import { format, formatRelative, formatDistance, formatDistanceToNow } from 'date-fns';
import { pt } from 'date-fns/locale';

// Formato usado para datas completas
export const formatBR = (date: Date, formatStr = 'PPP') => {
  return format(date, formatStr, { locale: pt });
};

// Formato para datas relativas
export const formatRelativeBR = (date: Date, baseDate: Date) => {
  return formatRelative(date, baseDate, { locale: pt });
};

// Formato para distâncias temporais
export const formatDistanceBR = (date: Date, baseDate: Date) => {
  return formatDistance(date, baseDate, { locale: pt, addSuffix: true });
};

// Formato relativo ao momento atual
export const formatDistanceToNowBR = (date: Date) => {
  return formatDistanceToNow(date, { locale: pt, addSuffix: true });
};

// Formato para números
export const formatNumberBR = (value: number) => {
  return new Intl.NumberFormat('pt-BR', {
    minimumFractionDigits: 0,
    maximumFractionDigits: 2
  }).format(value);
};

// Formato para valores monetários
export const formatCurrencyBR = (value: number) => {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL',
  }).format(value);
};

// Configurações gerais para a localização
export const brazilianConfig = {
  dateFormat: 'dd/MM/yyyy',
  timeFormat: 'HH:mm',
  dateTimeFormat: 'dd/MM/yyyy HH:mm',
  currencySymbol: 'R$',
  decimalSeparator: ',',
  thousandsSeparator: '.',
  weekStartsOn: 0, // Domingo = 0, Segunda = 1
  locale: pt
};