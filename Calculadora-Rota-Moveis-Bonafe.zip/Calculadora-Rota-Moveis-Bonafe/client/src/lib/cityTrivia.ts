/**
 * Arquivo de curiosidades sobre cidades brasileiras
 * Utilizado para exibir informações interessantes durante aniversários
 */

export interface CityTrivia {
  cityName: string;             // Nome da cidade (sem UF)
  foundationYear: number;       // Ano de fundação
  nicknames: string[];          // Apelidos ou títulos da cidade
  famousFor: string[];          // O que a cidade é conhecida por
  funFacts: string[];           // Curiosidades divertidas
  economyHighlights: string[];  // Destaques econômicos
  importantLandmarks: string[]; // Pontos turísticos importantes
  imageUrl?: string;            // URL de imagem representativa (opcional)
}

/**
 * Base de dados com curiosidades sobre cidades brasileiras
 */
export const cityTriviaDatabase: Record<string, CityTrivia> = {
  "São Paulo": {
    cityName: "São Paulo",
    foundationYear: 1554,
    nicknames: ["Terra da Garoa", "Sampa", "Locomotiva do Brasil", "Capital Financeira"],
    famousFor: [
      "Maior cidade do Brasil e da América do Sul",
      "Centro financeiro do país",
      "Diversidade cultural e gastronômica",
      "Avenida Paulista"
    ],
    funFacts: [
      "Tem a maior frota de helicópteros do mundo",
      "A cidade possui mais de 12 mil restaurantes",
      "O Mercado Municipal vende mais de 1.500 tipos de frutas",
      "O metrô transporta mais de 5 milhões de pessoas por dia"
    ],
    economyHighlights: [
      "Representa 11% do PIB brasileiro",
      "Maior centro financeiro da América Latina",
      "Sede de mais de 60% das multinacionais instaladas no Brasil",
      "Polo da indústria criativa e tecnológica"
    ],
    importantLandmarks: [
      "MASP - Museu de Arte de São Paulo",
      "Parque Ibirapuera",
      "Edifício Copan",
      "Catedral da Sé"
    ],
    imageUrl: "https://images.unsplash.com/photo-1578002171601-902495eeea74"
  },
  
  "Rio de Janeiro": {
    cityName: "Rio de Janeiro",
    foundationYear: 1565,
    nicknames: ["Cidade Maravilhosa", "Capital do Samba", "Cidade Olímpica"],
    famousFor: [
      "Cristo Redentor",
      "Praias de Copacabana e Ipanema",
      "Carnaval carioca",
      "Pão de Açúcar"
    ],
    funFacts: [
      "O nome Rio de Janeiro foi dado porque os exploradores acharam que a Baía de Guanabara era a foz de um rio",
      "O bondinho do Pão de Açúcar é o terceiro mais antigo do mundo",
      "A Floresta da Tijuca é a maior floresta urbana do mundo",
      "Foi capital do Brasil por quase 200 anos"
    ],
    economyHighlights: [
      "Segundo maior PIB do Brasil",
      "Principal polo turístico do país",
      "Centro da indústria de óleo e gás",
      "Sede de importantes empresas de mídia como a Rede Globo"
    ],
    importantLandmarks: [
      "Cristo Redentor",
      "Pão de Açúcar",
      "Maracanã",
      "Arcos da Lapa"
    ],
    imageUrl: "https://images.unsplash.com/photo-1483729558449-99ef09a8c325"
  },
  
  "Ribeirão Preto": {
    cityName: "Ribeirão Preto",
    foundationYear: 1856,
    nicknames: ["Califórnia Brasileira", "Capital do Agronegócio", "Cidade do Chope"],
    famousFor: [
      "Produção de cana-de-açúcar",
      "Festival Tanabata (Festa das Estrelas)",
      "Choperia Pinguim",
      "Pesquisa em saúde e biotecnologia"
    ],
    funFacts: [
      "A região tem o maior complexo cervejeiro da América Latina, sendo chamada de 'Califórnia Brasileira'",
      "Possui o mais antigo e tradicional festival de cultura japonesa fora do Japão",
      "O Campus da USP de Ribeirão Preto é um dos mais importantes centros de pesquisa médica do país",
      "A cidade já foi conhecida como 'Capital Mundial do Café' no início do século XX"
    ],
    economyHighlights: [
      "Um dos principais polos do agronegócio brasileiro",
      "Centro açucareiro e de produção de etanol",
      "Polo universitário e de pesquisa em saúde",
      "Sede de importantes usinas de açúcar e álcool"
    ],
    importantLandmarks: [
      "Teatro Pedro II",
      "Quarteirão Paulista",
      "Museu do Café",
      "Parque Maurílio Biagi"
    ],
    imageUrl: "https://deolhonosagronegócios.com.br/wp-content/uploads/2020/09/ribeirao-preto.jpg"
  },
  
  "Campinas": {
    cityName: "Campinas",
    foundationYear: 1774,
    nicknames: ["Princesa D'Oeste", "Cidade das Andorinhas", "Capital do Conhecimento"],
    famousFor: [
      "Polo tecnológico",
      "Universidades (UNICAMP)",
      "Aeroporto de Viracopos",
      "Festival Internacional de Teatro"
    ],
    funFacts: [
      "Carlos Gomes, um dos maiores compositores brasileiros, nasceu em Campinas",
      "O milho pipoca teria sido criado em Campinas por cientistas do IAC",
      "A cidade tem uma das maiores concentrações de PhDs por habitante do Brasil",
      "O Café Cultura foi o primeiro café a servir café expresso no Brasil"
    ],
    economyHighlights: [
      "Segundo maior PIB do estado de São Paulo",
      "Principal polo de alta tecnologia do país (a 'Vale do Silício brasileira')",
      "Centro de pesquisa científica com vários institutos e universidades",
      "Importante centro logístico com o aeroporto internacional de Viracopos"
    ],
    importantLandmarks: [
      "Catedral Metropolitana",
      "Parque Portugal (Lagoa do Taquaral)",
      "Observatório Municipal Jean Nicolini",
      "Estação Cultura (antiga estação ferroviária)"
    ],
    imageUrl: "https://blog.portaleducacao.com.br/wp-content/uploads/2022/11/cursos-tecnicos-gratuitos-campinas.jpg"
  },
  
  "Belo Horizonte": {
    cityName: "Belo Horizonte",
    foundationYear: 1897,
    nicknames: ["BH", "Cidade Jardim", "Capital Mundial dos Botecos"],
    famousFor: [
      "Arquitetura modernista",
      "Conjunto da Pampulha",
      "Culinária mineira",
      "Quantidade de bares por habitante"
    ],
    funFacts: [
      "Foi a primeira cidade planejada do Brasil no período republicano",
      "Tem mais bares per capita que qualquer outra cidade do Brasil",
      "O Mercado Central oferece mais de 400 tipos de queijos mineiros",
      "É cercada pela Serra do Curral, que é o símbolo natural da cidade"
    ],
    economyHighlights: [
      "Centro da indústria mineradora brasileira",
      "Polo de biotecnologia e tecnologia da informação",
      "Importante centro médico e de saúde",
      "Sede de grandes empresas como a Vale"
    ],
    importantLandmarks: [
      "Igreja São Francisco de Assis (Pampulha)",
      "Praça da Liberdade",
      "Mercado Central",
      "Mineirão"
    ],
    imageUrl: "https://images.unsplash.com/photo-1575106544027-2c24d069af3d"
  },
  
  "São Carlos": {
    cityName: "São Carlos",
    foundationYear: 1857,
    nicknames: ["Capital da Tecnologia", "Cidade do Clima", "Atenas Paulista"],
    famousFor: [
      "Centro universitário (USP e UFSCar)",
      "Pesquisa científica e tecnológica",
      "Empresas de tecnologia avançada",
      "Clima ameno"
    ],
    funFacts: [
      "Tem a maior concentração de cientistas e doutores por habitante do Brasil",
      "É um dos principais polos de desenvolvimento de tecnologia aeronáutica do país",
      "A cidade tem um dos maiores números de patentes per capita do Brasil",
      "Abriga o Centro de Divulgação Científica e Cultural da USP"
    ],
    economyHighlights: [
      "Polo de desenvolvimento tecnológico com diversas empresas de base tecnológica",
      "Centro de educação com duas universidades públicas de referência",
      "Sede da Embrapa Instrumentação Agropecuária",
      "Importante produtor de laranja e cana-de-açúcar"
    ],
    importantLandmarks: [
      "Catedral de São Carlos",
      "Campus da USP",
      "Campus da UFSCar",
      "Parque Ecológico"
    ],
    imageUrl: "https://www.saocarlos.sp.gov.br/wp-content/uploads/2020/11/catedral-scaled.jpg"
  },
  
  "Dois Córregos": {
    cityName: "Dois Córregos",
    foundationYear: 1856,
    nicknames: ["Terra das Palmeiras", "Cidade dos Rios", "Capital da Amizade"],
    famousFor: [
      "Cultivo de cana-de-açúcar",
      "Café e produção agrícola",
      "Ferrovias históricas",
      "Festas tradicionais"
    ],
    funFacts: [
      "O nome da cidade vem de dois córregos que se encontram na região central: o córrego do Lageado e o Fundo",
      "Foi um importante entroncamento ferroviário no auge da produção cafeeira",
      "A cidade já foi conhecida como 'Capital da Cerâmica' por suas olarias",
      "Preserva várias construções da época áurea do café"
    ],
    economyHighlights: [
      "Produção agropecuária com destaque para cana-de-açúcar e café",
      "Comércio local forte voltado para atender produtores rurais",
      "Turismo rural em crescimento",
      "Usinas de açúcar e álcool"
    ],
    importantLandmarks: [
      "Estação Ferroviária",
      "Igreja Matriz de Santana",
      "Parque Ecológico",
      "Museu Histórico"
    ],
    imageUrl: "https://doiscorregos.sp.gov.br/wp-content/uploads/2021/03/DSC_0042-1536x1024.jpg"
  },
  
  "Jaú": {
    cityName: "Jaú",
    foundationYear: 1853,
    nicknames: ["Capital Nacional do Calçado Feminino", "Atenas Paulista", "Terra do Sapato"],
    famousFor: [
      "Indústria de calçados femininos",
      "Arquitetura histórica",
      "Antigas fazendas de café",
      "Rio Jaú"
    ],
    funFacts: [
      "Produz aproximadamente 130 mil pares de calçados por dia",
      "Possui o Museu do Calçado com mais de 800 peças em exposição",
      "Foi palco de uma das maiores revoltas contra a escravidão no Brasil",
      "É a terra natal do piloto Ayrton Senna"
    ],
    economyHighlights: [
      "Maior polo calçadista do estado de São Paulo",
      "Importante produtor de cana-de-açúcar",
      "Comércio forte voltado para o setor calçadista",
      "Indústria têxtil"
    ],
    importantLandmarks: [
      "Museu Municipal",
      "Igreja Matriz Nossa Senhora do Patrocínio",
      "Teatro Municipal Flávio Razuk",
      "Parque do Rio Jaú"
    ],
    imageUrl: "https://s2.glbimg.com/2Y1kHPh3g3HnY3e-RJAg9ahJzoc=/620x430/e.glbimg.com/og/ed/f/original/2013/11/21/jau_9.jpg"
  },
  
  "Bauru": {
    cityName: "Bauru",
    foundationYear: 1896,
    nicknames: ["Cidade sem Limites", "Terra do Sanduíche Bauru", "Capital da Terra Branca"],
    famousFor: [
      "Sanduíche Bauru (presunto, queijo, tomate e picles)",
      "Universidades (USC, UNESP)",
      "Entroncamento ferroviário histórico",
      "IPMET - radar meteorológico"
    ],
    funFacts: [
      "O famoso sanduíche Bauru foi criado em 1937 por Casimiro Pinto Neto na cidade de São Paulo",
      "Abriga o Museu Ferroviário mais completo do interior paulista",
      "O Jardim Botânico tem mais de 300 espécies de plantas nativas do cerrado",
      "É sede do primeiro Jardim Zoológico do interior do estado de São Paulo"
    ],
    economyHighlights: [
      "Importante centro comercial regional",
      "Polo universitário e de pesquisa",
      "Centro de logística e transportes no centro-oeste paulista",
      "Indústrias de transformação e alimentícias"
    ],
    importantLandmarks: [
      "Estação Ferroviária",
      "Jardim Botânico Municipal",
      "Zoológico Municipal",
      "Bosque da Comunidade"
    ],
    imageUrl: "https://www.melhoresdestinos.com.br/wp-content/uploads/2019/06/bauru-capa-01.jpg"
  },
  
  "Araraquara": {
    cityName: "Araraquara",
    foundationYear: 1817,
    nicknames: ["Morada do Sol", "Cidade dos Laranjais", "Atenas Paulista"],
    famousFor: [
      "Laranjais e citricultura",
      "Festa das Nações",
      "Centro universitário (UNESP)",
      "Ferrovia histórica"
    ],
    funFacts: [
      "O nome Araraquara vem do tupi e significa 'morada das araras'",
      "Possui um dos mais antigos e tradicionais sistemas de carnaval de rua do interior",
      "A primeira biblioteca pública municipal do estado de São Paulo foi fundada na cidade",
      "Fornece suco de laranja para mais de 60 países"
    ],
    economyHighlights: [
      "Um dos maiores produtores de laranja e suco cítrico do país",
      "Polo da indústria sucroalcooleira",
      "Importante centro ferroviário histórico",
      "Setor de serviços desenvolvido"
    ],
    importantLandmarks: [
      "Teatro Municipal",
      "Palacete das Rosas",
      "Parque do Basalto",
      "Estação Ferroviária"
    ],
    imageUrl: "https://www.guiadoturismobrasil.com/up/img/1427385387.jpg"
  }
};

/**
 * Obtém curiosidades sobre uma cidade específica
 * @param cityName Nome da cidade (com ou sem UF)
 * @returns Objeto com curiosidades ou undefined se não encontrado
 */
export function getCityTrivia(cityName: string): CityTrivia | undefined {
  // Remover UF se presente (ex: "São Paulo-SP" -> "São Paulo")
  const cleanCityName = cityName.split('-')[0].trim();
  
  return cityTriviaDatabase[cleanCityName];
}

/**
 * Obtém fatos aleatórios sobre uma cidade
 * @param cityName Nome da cidade
 * @param count Número de fatos a retornar (padrão: 3)
 * @returns Array com fatos aleatórios ou array vazio se cidade não encontrada
 */
export function getRandomCityFacts(cityName: string, count: number = 3): string[] {
  const trivia = getCityTrivia(cityName);
  if (!trivia) return [];
  
  // Combinar todos os fatos disponíveis
  const allFacts = [
    ...trivia.funFacts,
    ...trivia.famousFor,
    ...trivia.economyHighlights
  ];
  
  // Embaralhar e pegar 'count' fatos
  return shuffleArray(allFacts).slice(0, count);
}

/**
 * Embaralha um array usando o algoritmo Fisher-Yates
 * @param array Array a ser embaralhado
 * @returns Nova cópia do array embaralhado
 */
function shuffleArray<T>(array: T[]): T[] {
  const newArray = [...array];
  for (let i = newArray.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [newArray[i], newArray[j]] = [newArray[j], newArray[i]];
  }
  return newArray;
}