import { QueryClient, QueryFunction } from "@tanstack/react-query";

async function throwIfResNotOk(res: Response) {
  if (!res.ok) {
    const text = (await res.text()) || res.statusText;
    throw new Error(`${res.status}: ${text}`);
  }
}

export async function apiRequest(
  methodOrUrl: string,
  urlOrData?: string | unknown,
  data?: unknown,
): Promise<any> {
  // Verificar se o primeiro parâmetro é uma URL completa ou um método HTTP
  const isFirstParamUrl = methodOrUrl.startsWith('/') || methodOrUrl.startsWith('http');
  
  // Configurar os parâmetros com base no padrão de chamada
  const method = isFirstParamUrl ? 'GET' : methodOrUrl;
  const url = isFirstParamUrl ? methodOrUrl : urlOrData as string;
  const bodyData = isFirstParamUrl ? urlOrData : data;
  
  // Ajuste para tratar opções
  let options = null;
  
  // Se for chamada GET direta e tiver objeto de opções OU
  // Se for chamada com método e tiver dados
  if ((isFirstParamUrl && typeof urlOrData === 'object') || 
      (!isFirstParamUrl && typeof data === 'object')) {
    options = isFirstParamUrl ? urlOrData as any : data as any;
  }
  
  console.log(`API Request: ${method} ${url}`, bodyData);
  
  // Para requisições GET, não podemos incluir body
  const fetchOptions: RequestInit = {
    method,
    headers: (method !== 'GET' && bodyData) ? { "Content-Type": "application/json" } : {},
    credentials: "include",
  };
  
  // Adicionar corpo apenas se não for GET
  if (method !== 'GET' && bodyData) {
    fetchOptions.body = JSON.stringify(bodyData);
  }
  
  const res = await fetch(url, fetchOptions);
  
  // Tratamento especial para autenticação baseado nas opções
  if (options && options.on401 === "returnNull" && res.status === 401) {
    return null;
  }

  await throwIfResNotOk(res);
  
  // Verificar se o corpo da resposta está vazio
  const contentType = res.headers.get("content-type");
  const contentLength = res.headers.get("content-length");
  
  // Se o corpo estiver vazio ou resposta for 204 No Content, retorna null
  if (res.status === 204 || contentLength === "0" || !contentLength) {
    return null;
  }
  
  // Verificar se a resposta é JSON e parsear
  if (contentType && contentType.includes("application/json")) {
    try {
      return await res.json();
    } catch (e) {
      console.error("Erro ao parsear JSON:", e);
      return null;
    }
  }
  
  // Caso contrário, retornar como texto
  try {
    return await res.text();
  } catch (e) {
    console.error("Erro ao ler corpo da resposta:", e);
    return null;
  }
}

type UnauthorizedBehavior = "returnNull" | "throw";
export const getQueryFn: <T>(options: {
  on401: UnauthorizedBehavior;
}) => QueryFunction<T> =
  ({ on401: unauthorizedBehavior }) =>
  async ({ queryKey }) => {
    const res = await fetch(queryKey[0] as string, {
      credentials: "include",
    });

    if (unauthorizedBehavior === "returnNull" && res.status === 401) {
      return null;
    }

    await throwIfResNotOk(res);
    
    // Verificar se o corpo da resposta está vazio
    const contentType = res.headers.get("content-type");
    const contentLength = res.headers.get("content-length");
    
    // Se o corpo estiver vazio ou resposta for 204 No Content, retorna null
    if (res.status === 204 || contentLength === "0" || !contentLength) {
      return null;
    }
    
    // Verificar se a resposta é JSON e parsear
    if (contentType && contentType.includes("application/json")) {
      try {
        return await res.json();
      } catch (e) {
        console.error("Erro ao parsear JSON:", e);
        return null;
      }
    }
    
    // Caso contrário, retornar como texto
    try {
      return await res.text();
    } catch (e) {
      console.error("Erro ao ler corpo da resposta:", e);
      return null;
    }
  };

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      queryFn: getQueryFn({ on401: "throw" }),
      refetchInterval: false,
      refetchOnWindowFocus: false,
      staleTime: Infinity,
      retry: false,
    },
    mutations: {
      retry: false,
    },
  },
});
