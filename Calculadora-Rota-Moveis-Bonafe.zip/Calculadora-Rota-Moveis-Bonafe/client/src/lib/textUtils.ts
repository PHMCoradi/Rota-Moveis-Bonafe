/**
 * Utilitários para manipulação e comparação de texto
 */

/**
 * Normaliza uma string removendo acentos, convertendo para minúsculas
 * e removendo caracteres especiais.
 * @param str String a ser normalizada
 */
export function normalizeString(str: string): string {
  if (!str) return '';
  
  // Remover acentos, converter para minúsculas e remover caracteres especiais
  return str
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '') // Remove diacríticos (acentos)
    .toLowerCase()
    .replace(/[^\w\s]/g, '') // Remove caracteres especiais
    .replace(/\s+/g, ' ') // Substitui sequências de espaços por um único espaço
    .trim();
}

/**
 * Calcula a distância de Levenshtein entre duas strings.
 * Esta métrica mede o número mínimo de operações de edição de caractere 
 * único (inserções, exclusões ou substituições) necessárias para transformar
 * uma string em outra.
 * @param a Primeira string
 * @param b Segunda string
 */
export function levenshteinDistance(a: string, b: string): number {
  // Se uma string estiver vazia, a distância é o comprimento da outra string
  if (a.length === 0) return b.length;
  if (b.length === 0) return a.length;

  // Criar matriz para armazenar os valores de distância
  const matrix: number[][] = [];

  // Inicializar a primeira linha
  for (let i = 0; i <= b.length; i++) {
    matrix[0] = matrix[0] || [];
    matrix[0][i] = i;
  }

  // Inicializar a primeira coluna
  for (let i = 0; i <= a.length; i++) {
    matrix[i] = matrix[i] || [];
    matrix[i][0] = i;
  }

  // Calcular o restante da matriz
  for (let i = 1; i <= a.length; i++) {
    for (let j = 1; j <= b.length; j++) {
      const cost = a[i - 1] === b[j - 1] ? 0 : 1;
      matrix[i][j] = Math.min(
        matrix[i - 1][j] + 1,      // deleção
        matrix[i][j - 1] + 1,      // inserção
        matrix[i - 1][j - 1] + cost // substituição
      );
    }
  }

  // Retornar o valor na posição inferior direita da matriz
  return matrix[a.length][b.length];
}

/**
 * Calcula uma pontuação de similaridade entre duas strings.
 * 
 * 1.0 = exatamente igual, 0.0 = completamente diferente.
 * 
 * Usa a distância Levenshtein normalizada pelo comprimento das strings.
 * 
 * @param a Primeira string
 * @param b Segunda string
 */
export function stringSimilarity(a: string, b: string): number {
  // Normalizar as strings para comparação justa
  const normA = normalizeString(a);
  const normB = normalizeString(b);
  
  // Se ambas forem iguais após normalização
  if (normA === normB) return 1.0;
  
  // Se uma das strings estiver vazia após normalização
  if (normA.length === 0 || normB.length === 0) return 0.0;
  
  // Calcular distância Levenshtein entre strings normalizadas
  const distance = levenshteinDistance(normA, normB);
  
  // Normalizar pelo comprimento máximo das strings
  const maxLength = Math.max(normA.length, normB.length);
  
  // Calcular similaridade (1 - distância normalizada)
  return 1 - (distance / maxLength);
}

/**
 * Verifica se uma string contém aproximadamente outra string, mesmo com erros.
 * 
 * @param text Texto a ser verificado
 * @param query Query a ser encontrada
 * @param threshold Limite de similaridade (0.0 a 1.0, padrão 0.7)
 */
export function fuzzyContains(text: string, query: string, threshold = 0.7): boolean {
  // Normalizar ambas as strings
  const normText = normalizeString(text);
  const normQuery = normalizeString(query);
  
  // Se a query é muito curta, usar um limiar mais alto
  const adjustedThreshold = normQuery.length <= 2 ? 0.85 : threshold;
  
  // Para consultas curtas, verificar se o texto as contém diretamente
  if (normQuery.length <= 3 && normText.includes(normQuery)) {
    return true;
  }
  
  // Para consultas maiores, usar janela deslizante para encontrar a melhor correspondência
  const windowSize = normQuery.length + 2; // Adiciona margem para possíveis erros
  let maxSimilarity = 0;
  
  // Se o texto é mais curto que a janela, apenas compare diretamente
  if (normText.length <= windowSize) {
    return stringSimilarity(normText, normQuery) >= adjustedThreshold;
  }
  
  // Para cada posição possível da janela
  for (let i = 0; i <= normText.length - normQuery.length; i++) {
    const window = normText.substring(i, i + windowSize);
    const similarity = stringSimilarity(window, normQuery);
    maxSimilarity = Math.max(maxSimilarity, similarity);
    
    // Se encontrarmos uma correspondência suficientemente boa, retorna imediatamente
    if (similarity >= adjustedThreshold) {
      return true;
    }
  }
  
  return maxSimilarity >= adjustedThreshold;
}

/**
 * Verifica se duas strings são aproximadamente iguais, ignorando
 * acentuação, capitalização e pequenos erros de digitação.
 * 
 * @param a Primeira string
 * @param b Segunda string
 * @param threshold Limite de similaridade (0.0 a 1.0, padrão 0.8)
 */
export function fuzzyEquals(a: string, b: string, threshold = 0.8): boolean {
  return stringSimilarity(a, b) >= threshold;
}

/**
 * Determina o formato mais adequado para um nome com base no contexto
 * 
 * @param nome Nome a ser analisado
 * @returns Formato de formatação recomendado
 */
export enum NomeFormat {
  TITLE_CASE, // Primeira letra de cada palavra em maiúsculo (Ex: "João Silva")
  UPPERCASE,  // Tudo em maiúsculo (Ex: "JOÃO SILVA")
  LOWERCASE,  // Tudo em minúsculo (Ex: "joão silva")
  PRESERVE    // Preservar o formato original
}

export function detectarFormatoNome(nome: string): NomeFormat {
  if (!nome || nome.trim() === '') return NomeFormat.PRESERVE;
  
  // Verificar se o nome já está todo em maiúsculo
  if (nome === nome.toUpperCase()) {
    return NomeFormat.UPPERCASE;
  }
  
  // Verificar se o nome já está todo em minúsculo
  if (nome === nome.toLowerCase()) {
    return NomeFormat.LOWERCASE;
  }
  
  // Verificar se o nome segue o padrão Title Case (primeira letra de cada palavra em maiúsculo)
  const words = nome.split(' ');
  const isTitleCase = words.every(word => {
    if (word.length === 0) return true;
    
    // Verificar se a primeira letra é maiúscula e o resto é minúscula
    const firstChar = word.charAt(0);
    const restOfWord = word.slice(1);
    
    return firstChar === firstChar.toUpperCase() && 
           (restOfWord === restOfWord.toLowerCase() || restOfWord.length === 0);
  });
  
  if (isTitleCase) {
    return NomeFormat.TITLE_CASE;
  }
  
  // Se não se encaixar em nenhum padrão específico, usar Title Case como padrão
  return NomeFormat.TITLE_CASE;
}

/**
 * Formata um nome de acordo com o formato especificado
 * 
 * @param nome Nome a ser formatado
 * @param formato Formato desejado (padrão: Title Case)
 * @returns Nome formatado
 */
export function formatarNomeComFormato(nome: string, formato: NomeFormat = NomeFormat.TITLE_CASE): string {
  if (!nome || nome.trim() === '') return nome;
  
  switch (formato) {
    case NomeFormat.UPPERCASE:
      return nome.toUpperCase();
      
    case NomeFormat.LOWERCASE:
      return nome.toLowerCase();
      
    case NomeFormat.TITLE_CASE:
      return nome
        .split(' ')
        .map(palavra => {
          if (palavra.length === 0) return palavra;
          return palavra.charAt(0).toUpperCase() + palavra.slice(1).toLowerCase();
        })
        .join(' ');
        
    case NomeFormat.PRESERVE:
    default:
      return nome;
  }
}

/**
 * Formata um nome para ter a primeira letra de cada palavra em maiúsculo e as demais em minúsculo.
 * 
 * Exemplos:
 * - "PEDRO" -> "Pedro"
 * - "joao" -> "Joao"
 * - "MARIA SILVA" -> "Maria Silva"
 * - "JOSÉ DA SILVA" -> "José Da Silva"
 * 
 * @param nome Nome a ser formatado
 * @returns Nome formatado ou o valor original se não for uma string válida
 */
export function formatarNome(nome: string | null | undefined): string | null | undefined {
  if (!nome) return nome;
  
  // Se for uma string vazia, retorna como está
  if (nome.trim() === '') return nome;
  
  // Divide o nome em palavras, formata cada uma e junta novamente
  return nome
    .split(' ')
    .map(palavra => {
      if (palavra.length === 0) return palavra;
      return palavra.charAt(0).toUpperCase() + palavra.slice(1).toLowerCase();
    })
    .join(' ');
}