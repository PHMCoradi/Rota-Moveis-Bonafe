/**
 * Base de dados de feriados nacionais, estaduais e municipais no Brasil
 * Também inclui aniversários de cidades importantes
 */

export interface Holiday {
  date: string;     // Formato DD/MM
  name: string;     // Nome do feriado ou evento
  type: 'nacional' | 'estadual' | 'municipal' | 'aniversario';  // Tipo de feriado
  location?: string; // Localização relevante (UF para estadual, Cidade-UF para municipal)
  description?: string; // Descrição adicional
  year?: number;    // Se for um evento de ano específico
}

/**
 * Lista de feriados nacionais fixos
 */
export const nationalHolidays: Holiday[] = [
  { date: "01/01", name: "Confraternização Universal", type: "nacional" },
  { date: "21/04", name: "Tiradentes", type: "nacional" },
  { date: "01/05", name: "Dia do Trabalho", type: "nacional" },
  { date: "07/09", name: "Independência do Brasil", type: "nacional" },
  { date: "12/10", name: "Nossa Senhora Aparecida", type: "nacional" },
  { date: "02/11", name: "Finados", type: "nacional" },
  { date: "15/11", name: "Proclamação da República", type: "nacional" },
  { date: "25/12", name: "Natal", type: "nacional" }
];

/**
 * Lista de feriados estaduais fixos
 */
export const stateHolidays: Holiday[] = [
  { date: "09/07", name: "Revolução Constitucionalista", type: "estadual", location: "SP" },
  { date: "20/11", name: "Dia da Consciência Negra", type: "estadual", location: "RJ" },
  { date: "21/09", name: "Dia da Revolução Farroupilha", type: "estadual", location: "RS" },
  { date: "08/12", name: "Nossa Senhora da Conceição", type: "estadual", location: "PE" },
  { date: "16/07", name: "Fundação da Cidade de São Paulo", type: "estadual", location: "SP" }
];

/**
 * Lista de aniversários de cidades brasileiras importantes
 */
export const cityAnniversaries: Holiday[] = [
  // São Paulo - Capital e principais cidades
  { date: "25/01", name: "Aniversário de São Paulo", type: "aniversario", location: "São Paulo-SP", description: "468 anos de fundação em 2022" },
  { date: "19/06", name: "Aniversário de Ribeirão Preto", type: "aniversario", location: "Ribeirão Preto-SP", description: "Conhecida como a capital do agronegócio" },
  { date: "13/06", name: "Aniversário de Campinas", type: "aniversario", location: "Campinas-SP", description: "Polo tecnológico e universitário" },
  { date: "26/01", name: "Aniversário de São Carlos", type: "aniversario", location: "São Carlos-SP", description: "Capital da tecnologia" },
  { date: "10/07", name: "Aniversário de Dois Córregos", type: "aniversario", location: "Dois Córregos-SP", description: "Conhecida como a Terra da Madeira" },
  { date: "24/06", name: "Aniversário de Jaú", type: "aniversario", location: "Jaú-SP", description: "Capital do calçado feminino" },
  { date: "24/08", name: "Aniversário de Bauru", type: "aniversario", location: "Bauru-SP", description: "Cidade do sanduíche Bauru" },
  { date: "04/04", name: "Aniversário de Araraquara", type: "aniversario", location: "Araraquara-SP", description: "Conhecida como Morada do Sol" },
  { date: "18/04", name: "Aniversário de Lençóis Paulista", type: "aniversario", location: "Lençóis Paulista-SP", description: "Cidade do Papel e da Hospitalidade" },
  { date: "15/04", name: "Aniversário de Botucatu", type: "aniversario", location: "Botucatu-SP", description: "Cidade dos bons ares e das boas escolas" },
  { date: "20/07", name: "Aniversário de Piracicaba", type: "aniversario", location: "Piracicaba-SP", description: "Lar do Rio Piracicaba" },
  { date: "10/04", name: "Aniversário de Sorocaba", type: "aniversario", location: "Sorocaba-SP", description: "Manchester Paulista" },
  { date: "27/10", name: "Aniversário de Jundiaí", type: "aniversario", location: "Jundiaí-SP", description: "Terra da uva" },
  
  // Rio de Janeiro
  { date: "01/03", name: "Aniversário do Rio de Janeiro", type: "aniversario", location: "Rio de Janeiro-RJ", description: "Cidade Maravilhosa" },
  { date: "09/06", name: "Aniversário de Niterói", type: "aniversario", location: "Niterói-RJ", description: "Cidade Sorriso" },
  
  // Minas Gerais
  { date: "12/08", name: "Aniversário de Belo Horizonte", type: "aniversario", location: "Belo Horizonte-MG", description: "Cidade dos bares e da hospitalidade mineira" },
  { date: "08/12", name: "Aniversário de Juiz de Fora", type: "aniversario", location: "Juiz de Fora-MG", description: "Manchester Mineira" },
  { date: "24/05", name: "Aniversário de Uberlândia", type: "aniversario", location: "Uberlândia-MG", description: "Capital do Triângulo Mineiro" },
  
  // Demais estados
  { date: "29/03", name: "Aniversário de Curitiba", type: "aniversario", location: "Curitiba-PR", description: "Cidade modelo de planejamento urbano" },
  { date: "05/08", name: "Aniversário de Goiânia", type: "aniversario", location: "Goiânia-GO", description: "Capital do Cerrado" },
  { date: "21/04", name: "Aniversário de Brasília", type: "aniversario", location: "Brasília-DF", description: "Capital planejada do Brasil" },
  { date: "29/03", name: "Aniversário de Salvador", type: "aniversario", location: "Salvador-BA", description: "Primeira capital do Brasil" },
  { date: "13/12", name: "Aniversário de Recife", type: "aniversario", location: "Recife-PE", description: "Veneza Brasileira" },
  { date: "05/09", name: "Aniversário de Porto Alegre", type: "aniversario", location: "Porto Alegre-RS", description: "Capital dos gaúchos" },
  { date: "17/08", name: "Aniversário de Fortaleza", type: "aniversario", location: "Fortaleza-CE", description: "Terra da luz" },
  { date: "18/08", name: "Aniversário de Londrina", type: "aniversario", location: "Londrina-PR", description: "Pequena Londres" }
];

/**
 * Lista de feriados municipais importantes
 */
export const municipalHolidays: Holiday[] = [
  { date: "25/01", name: "Dia de São Paulo", type: "municipal", location: "São Paulo-SP" },
  { date: "20/01", name: "Dia de São Sebastião", type: "municipal", location: "Rio de Janeiro-RJ" },
  { date: "15/08", name: "Dia de N. S. da Assunção (Padroeira)", type: "municipal", location: "Ribeirão Preto-SP" },
  { date: "08/12", name: "Dia de N. S. da Conceição (Padroeira)", type: "municipal", location: "Campinas-SP" },
  { date: "11/02", name: "Dia de São Pio X", type: "municipal", location: "Dois Córregos-SP" },
  { date: "16/08", name: "Dia de São Roque", type: "municipal", location: "Bauru-SP" },
  { date: "26/05", name: "Corpus Christi", type: "municipal", location: "Ribeirão Preto-SP" },
  { date: "28/10", name: "Dia do Servidor Público", type: "municipal", location: "Ribeirão Preto-SP" },
  { date: "30/05", name: "Dia do Evangélico", type: "municipal", location: "Campinas-SP" },
  { date: "24/06", name: "Dia de São João", type: "municipal", location: "Campina Grande-PB" },
  { date: "12/10", name: "Dia de Nossa Senhora Aparecida", type: "municipal", location: "Aparecida-SP" },
  { date: "19/11", name: "Dia da Bandeira", type: "municipal", location: "Brasília-DF" },
  { date: "04/08", name: "Festa da Achiropita", type: "municipal", location: "São Paulo-SP", description: "Festa tradicional do Bixiga" },
  { date: "12/07", name: "Emancipação política", type: "municipal", location: "Dois Córregos-SP" }
];

// Combinar todos os feriados
export const allHolidays: Holiday[] = [
  ...nationalHolidays,
  ...stateHolidays,
  ...cityAnniversaries,
  ...municipalHolidays
];

/**
 * Verifica se uma data (DD/MM) está no intervalo entre duas datas completas (DD/MM/YYYY)
 * @param dateToCheck Data no formato DD/MM para verificar
 * @param startDate Data inicial no formato DD/MM/YYYY
 * @param endDate Data final no formato DD/MM/YYYY
 * @returns true se a data está no intervalo
 */
export function isDateInRange(dateToCheck: string, startDate: string, endDate: string): boolean {
  if (!startDate || !endDate) return false;
  
  const [checkDay, checkMonth] = dateToCheck.split('/').map(Number);
  
  // Adaptar para o formato de Data do JavaScript (MM/DD/YYYY)
  const start = new Date(startDate.split('/').reverse().join('/'));
  const end = new Date(endDate.split('/').reverse().join('/'));
  
  // Criar ano atual para comparação
  const currentYear = start.getFullYear();
  
  // Criar data para o feriado no ano corrente
  const holidayDate = new Date(currentYear, checkMonth - 1, checkDay);
  
  // Se o feriado estiver antes da data de início no ano atual, verificar também para o próximo ano
  if (holidayDate < start) {
    const nextYearHolidayDate = new Date(currentYear + 1, checkMonth - 1, checkDay);
    return nextYearHolidayDate >= start && nextYearHolidayDate <= end;
  }
  
  return holidayDate >= start && holidayDate <= end;
}

/**
 * Encontra feriados e aniversários de cidades no intervalo de datas especificado
 * @param startDate Data inicial no formato DD/MM/YYYY
 * @param endDate Data final no formato DD/MM/YYYY
 * @param locations Lista de localizações (Cidade-UF ou UF) para filtrar
 * @returns Lista de feriados no intervalo
 */
export function findHolidaysInRange(
  startDate: string, 
  endDate: string, 
  locations: string[] = []
): Holiday[] {
  if (!startDate || !endDate) return [];
  
  const normalizedLocations = locations.map(loc => loc.toLowerCase());
  
  return allHolidays.filter(holiday => {
    // Verificar se a data está no intervalo
    const isInRange = isDateInRange(holiday.date, startDate, endDate);
    if (!isInRange) return false;
    
    // Se não há localizações especificadas, incluir todos os feriados
    if (normalizedLocations.length === 0) {
      return true; // Incluir todos os feriados quando não há filtro de localização
    }
    
    // Para feriados nacionais, sempre incluir
    if (holiday.type === 'nacional') return true;
    
    // Para outros tipos, verificar se a localização está na lista
    if (holiday.location) {
      // Para feriados estaduais, verificar se o estado está na lista diretamente ou em alguma cidade-UF
      if (holiday.type === 'estadual') {
        const state = holiday.location; // Ex: "SP"
        return normalizedLocations.some(loc => 
          loc === state.toLowerCase() || loc.endsWith(`-${state.toLowerCase()}`)
        );
      }
      
      // Para feriados municipais e aniversários, verificar a cidade completa
      const locationLower = holiday.location.toLowerCase();
      return normalizedLocations.some(loc => 
        loc === locationLower || locationLower.includes(loc)
      );
    }
    
    return false;
  });
}

/**
 * Formatar uma data no formato DD/MM/YYYY considerando o ano atual para exibição
 * @param dateStr Data no formato DD/MM
 * @param year Ano opcional para a data
 * @returns Data formatada como DD/MM/YYYY
 */
export function formatHolidayDate(dateStr: string, year: number = new Date().getFullYear()): string {
  const [day, month] = dateStr.split('/');
  return `${day}/${month}/${year}`;
}

/**
 * Extrai dia e mês de uma data no formato DD/MM
 * @param dateStr Data no formato DD/MM
 * @returns Objeto com dia e mês como números
 */
export function extractDayAndMonth(dateStr: string): { day: number, month: number } {
  const [day, month] = dateStr.split('/').map(Number);
  return { day, month };
}

/**
 * Formata uma lista de feriados para exibição
 * @param holidays Lista de feriados
 * @returns String formatada com a lista de feriados
 */
export function formatHolidayList(holidays: Holiday[]): string {
  if (!holidays || holidays.length === 0) {
    return "Nenhum feriado no período";
  }

  return holidays.map(holiday => {
    const location = holiday.type === 'nacional' 
      ? '(Nacional)' 
      : holiday.location ? `(${holiday.location})` : '';
    
    return `${holiday.name} - ${holiday.date} ${location}`;
  }).join(', ');
}

/**
 * Formata uma lista de feriados com destaque para os aniversários
 * @param holidays Lista de feriados
 * @param detailLevel Nível de detalhes (1 = resumido, 2 = completo)
 * @returns Objeto com listas formatadas por tipo de evento
 */
export function formatDetailedHolidayList(holidays: Holiday[], detailLevel: 1 | 2 = 1): { 
  aniversarios: string;
  feriados: string;
  eventos: string;
  todos: string;
} {
  if (!holidays || holidays.length === 0) {
    return {
      aniversarios: "",
      feriados: "",
      eventos: "",
      todos: "Nenhum evento no período da rota"
    };
  }

  // Separar por categorias
  const aniversarios = holidays.filter(h => h.type === 'aniversario');
  const feriadosNacionais = holidays.filter(h => h.type === 'nacional');
  const feriadosEstaduais = holidays.filter(h => h.type === 'estadual');
  const feriadosMunicipais = holidays.filter(h => h.type === 'municipal');
  
  // Formatar aniversários
  const aniversariosStr = aniversarios.length > 0 
    ? aniversarios.map(a => {
        const cidade = a.location ? a.location.split('-')[0].trim() : "";
        if (detailLevel === 1) {
          return `${cidade} (${a.date})`;
        } else {
          return `${cidade} comemora ${a.name} em ${a.date}`;
        }
      }).join(', ')
    : "";
  
  // Formatar feriados nacionais
  const nacionalStr = feriadosNacionais.length > 0
    ? feriadosNacionais.map(h => {
        if (detailLevel === 1) {
          return `${h.name} (${h.date})`;
        } else {
          return `${h.name} - feriado nacional em ${h.date}`;
        }
      }).join(', ')
    : "";
    
  // Formatar feriados estaduais
  const estadualStr = feriadosEstaduais.length > 0
    ? feriadosEstaduais.map(h => {
        if (detailLevel === 1) {
          return `${h.name} - ${h.date} (${h.location})`;
        } else {
          return `${h.name} - feriado estadual em ${h.location || ""} (${h.date})`;
        }
      }).join(', ')
    : "";
    
  // Formatar feriados municipais
  const municipalStr = feriadosMunicipais.length > 0
    ? feriadosMunicipais.map(h => {
        if (detailLevel === 1) {
          return `${h.name} - ${h.date} (${h.location})`;
        } else {
          return `${h.name} - feriado municipal em ${h.location || ""} (${h.date})`;
        }
      }).join(', ')
    : "";
    
  // Combinar feriados não aniversários
  const feriadosStr = [nacionalStr, estadualStr, municipalStr]
    .filter(Boolean)
    .join(', ');
    
  // Todos os eventos combinados
  const todosStr = [aniversariosStr, feriadosStr]
    .filter(Boolean)
    .join(', ');
    
  return {
    aniversarios: aniversariosStr,
    feriados: feriadosStr,
    eventos: "", // Reservado para outros tipos de eventos
    todos: todosStr
  };
}

/**
 * Extrai a cidade e UF de um endereço para verificar feriados
 * Lógica similar à função no arquivo truckRestrictions.ts
 */
export function extractCityAndStateFromAddress(address: string): { cidade: string, uf?: string } {
  // Verificar formato cidade-UF
  const cidadeUfMatch = address.match(/([A-Za-zÀ-ÖØ-öø-ÿ\s]+)-(SP|MG|PR|RS|SC|MS|MT|GO|DF|RJ|ES|BA|SE|AL|PE|PB|RN|CE|PI|MA|TO|PA|AP|RR|AM|AC|RO)/i);
  if (cidadeUfMatch) {
    return { 
      cidade: cidadeUfMatch[1].trim(),
      uf: cidadeUfMatch[2].toUpperCase()
    };
  }
  
  // Tentar extrair da vírgula - formato comum "Rua X, Bairro, Cidade - UF"
  const parts = address.split(',');
  if (parts.length >= 3) {
    // A cidade geralmente é o penúltimo antes do UF
    let cidadeParte = parts[parts.length - 2].trim();
    
    // Verificar se tem traço com UF
    const cidadeUfTraco = cidadeParte.match(/(.+)\s*-\s*(SP|MG|PR|RS|SC|MS|MT|GO|DF|RJ|ES|BA|SE|AL|PE|PB|RN|CE|PI|MA|TO|PA|AP|RR|AM|AC|RO)/i);
    if (cidadeUfTraco) {
      return { 
        cidade: cidadeUfTraco[1].trim(),
        uf: cidadeUfTraco[2].toUpperCase()
      };
    }
    
    return { cidade: cidadeParte };
  }
  
  // Se não conseguiu extrair de maneiras comuns, tenta outras abordagens
  // Procura por um padrão de UF no final
  const ufMatch = address.match(/.*?(SP|MG|PR|RS|SC|MS|MT|GO|DF|RJ|ES|BA|SE|AL|PE|PB|RN|CE|PI|MA|TO|PA|AP|RR|AM|AC|RO)$/i);
  if (ufMatch) {
    // Pega o texto antes da UF como possível cidade
    const possibleCity = address.replace(new RegExp(`\\s*-?\\s*${ufMatch[1]}$`, 'i'), '').trim();
    // Tenta extrair a última palavra ou conjunto de palavras que parece ser um nome de cidade
    const cityMatch = possibleCity.match(/([A-Za-zÀ-ÖØ-öø-ÿ\s]+)$/);
    if (cityMatch) {
      return { 
        cidade: cityMatch[1].trim(),
        uf: ufMatch[1].toUpperCase()
      };
    }
  }
  
  // Último recurso - tenta extrair o que parece ser um nome de cidade
  const cityMatch = address.match(/([A-Za-zÀ-ÖØ-öø-ÿ]{2,})/g);
  if (cityMatch && cityMatch.length > 0) {
    // Pega a palavra mais longa como possível cidade
    const possibleCity = cityMatch.reduce((a, b) => a.length > b.length ? a : b);
    return { cidade: possibleCity };
  }
  
  // Se nada funcionar, retorna o endereço inteiro
  return { cidade: address };
}