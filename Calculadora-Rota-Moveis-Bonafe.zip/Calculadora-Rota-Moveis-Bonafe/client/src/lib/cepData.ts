/**
 * Utilitário para interagir com o serviço de CEPs
 */

/**
 * Interface para informações de CEP
 */
export interface CepInfo {
  cep: string;
  logradouro: string;
  bairro?: string;
  cidade: string;
  estado: string;
  latitude?: string;
  longitude?: string;
}

/**
 * Resposta do serviço para uma busca de CEP
 */
interface CepResponse {
  success: boolean;
  cep?: CepInfo;
  message?: string;
}

/**
 * Resposta para busca de múltiplos CEPs
 */
interface CepsResponse {
  success: boolean;
  ceps: CepInfo[];
  resultados: number;
  message?: string;
}

/**
 * Busca um CEP específico
 * @param cep CEP a ser buscado (XXXXX-XXX ou XXXXXXXX)
 * @returns Informações do CEP ou undefined se não encontrado
 */
export async function buscarCep(cep: string): Promise<CepInfo | undefined> {
  try {
    // Normalizar CEP removendo caracteres não numéricos
    const cepNormalizado = cep.replace(/\D/g, '');
    
    // Formatar em XXXXX-XXX
    const cepFormatado = `${cepNormalizado.substring(0, 5)}-${cepNormalizado.substring(5)}`;
    
    console.log(`Buscando CEP: ${cepFormatado}`);
    
    const response = await fetch(`/api/cep/${cepFormatado}`);
    const data: CepResponse = await response.json();
    
    if (data.success && data.cep) {
      console.log(`CEP encontrado: ${cepFormatado} - ${data.cep.logradouro}, ${data.cep.cidade}`);
      return data.cep;
    }
    
    console.log(`CEP não encontrado: ${cepFormatado}`);
    return undefined;
  } catch (error) {
    console.error('Erro ao buscar CEP:', error);
    return undefined;
  }
}

/**
 * Busca CEPs por cidade e estado
 * @param cidade Nome da cidade
 * @param estado Sigla do estado (SP, MG, etc)
 * @returns Lista de CEPs encontrados
 */
export async function buscarCepsPorCidade(cidade: string, estado: string): Promise<CepInfo[]> {
  try {
    const response = await fetch(`/api/ceps?cidade=${encodeURIComponent(cidade)}&estado=${encodeURIComponent(estado)}`);
    const data: CepsResponse = await response.json();
    
    if (data.success && data.ceps) {
      console.log(`Encontrados ${data.resultados} CEPs para ${cidade}-${estado}`);
      return data.ceps;
    }
    
    console.log(`Nenhum CEP encontrado para ${cidade}-${estado}`);
    return [];
  } catch (error) {
    console.error('Erro ao buscar CEPs por cidade:', error);
    return [];
  }
}

/**
 * Pesquisa CEPs por texto livre
 * @param query Texto de busca (logradouro, bairro, cidade, etc)
 * @returns Lista de CEPs encontrados
 */
export async function pesquisarCeps(query: string): Promise<CepInfo[]> {
  try {
    if (query.length < 2) {
      console.log('Consulta muito curta para pesquisa de CEPs');
      return [];
    }
    
    const response = await fetch(`/api/ceps?q=${encodeURIComponent(query)}`);
    const data: CepsResponse = await response.json();
    
    if (data.success && data.ceps) {
      console.log(`Encontrados ${data.resultados} CEPs para a consulta "${query}"`);
      return data.ceps;
    }
    
    console.log(`Nenhum CEP encontrado para a consulta "${query}"`);
    return [];
  } catch (error) {
    console.error('Erro ao pesquisar CEPs:', error);
    return [];
  }
}

/**
 * Verifica se um texto é um CEP válido (formato brasileiro)
 * @param text Texto a ser verificado
 * @returns true se for um CEP válido
 */
export function isCepFormat(text: string): boolean {
  // Remover qualquer caractere não numérico
  const digitsOnly = text.replace(/\D/g, '');
  
  // Verificar se temos exatamente 8 dígitos
  return digitsOnly.length === 8;
}

/**
 * Formata um CEP no padrão XXXXX-XXX
 * @param cep CEP a ser formatado
 * @returns CEP formatado
 */
export function formatarCep(cep: string): string {
  // Remover qualquer caractere não numérico
  const digitsOnly = cep.replace(/\D/g, '');
  
  // Se não tiver 8 dígitos, retornar o original
  if (digitsOnly.length !== 8) {
    return cep;
  }
  
  // Formatar como XXXXX-XXX
  return `${digitsOnly.substring(0, 5)}-${digitsOnly.substring(5)}`;
}

/**
 * Extrai um CEP de uma string
 * @param text Texto contendo um CEP
 * @returns CEP extraído, se encontrado
 */
export function extrairCep(text: string): string | undefined {
  const cepPattern = /\d{5}[-.\s]?\d{3}/g;
  const match = text.match(cepPattern);
  
  if (match && match.length > 0) {
    return formatarCep(match[0]);
  }
  
  return undefined;
}

/**
 * Gera um endereço formatado a partir de um CEP
 * @param cepInfo Informações do CEP
 * @returns Endereço formatado
 */
export function gerarEnderecoFormatado(cepInfo: CepInfo): string {
  const partes = [];
  
  if (cepInfo.logradouro) {
    partes.push(cepInfo.logradouro);
  }
  
  if (cepInfo.bairro) {
    partes.push(cepInfo.bairro);
  }
  
  partes.push(`${cepInfo.cidade}-${cepInfo.estado}`);
  partes.push(`CEP ${cepInfo.cep}`);
  
  return partes.join(', ');
}