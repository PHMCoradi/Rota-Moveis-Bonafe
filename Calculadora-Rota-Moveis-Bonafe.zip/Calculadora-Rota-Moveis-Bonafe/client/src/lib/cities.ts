// Base de dados de cidades brasileiras por estado, usando array de objetos
// para melhor organização e permitir filtragem por estado
interface CityData {
  city: string;
  state: string;
  fullName: string; // Formato "Cidade-UF"
}

// Lista expandida com mais cidades brasileiras organizadas por estado
const cidadesBrasileiras: CityData[] = [
  // São Paulo
  { city: "São Paulo", state: "SP", fullName: "São Paulo-SP" },
  { city: "Campinas", state: "SP", fullName: "Campinas-SP" },
  { city: "Guarulhos", state: "SP", fullName: "Guarulhos-SP" },
  { city: "São Bernardo do Campo", state: "SP", fullName: "São Bernardo do Campo-SP" },
  { city: "Santo André", state: "SP", fullName: "Santo André-SP" },
  { city: "Osasco", state: "SP", fullName: "Osasco-SP" },
  { city: "Ribeirão Preto", state: "SP", fullName: "Ribeirão Preto-SP" },
  { city: "Sorocaba", state: "SP", fullName: "Sorocaba-SP" },
  { city: "Santos", state: "SP", fullName: "Santos-SP" },
  { city: "São José dos Campos", state: "SP", fullName: "São José dos Campos-SP" },
  { city: "São José do Rio Preto", state: "SP", fullName: "São José do Rio Preto-SP" },
  { city: "Piracicaba", state: "SP", fullName: "Piracicaba-SP" },
  { city: "Bauru", state: "SP", fullName: "Bauru-SP" },
  { city: "Jundiaí", state: "SP", fullName: "Jundiaí-SP" },
  { city: "Franca", state: "SP", fullName: "Franca-SP" },
  { city: "Limeira", state: "SP", fullName: "Limeira-SP" },
  { city: "Taubaté", state: "SP", fullName: "Taubaté-SP" },
  { city: "Marília", state: "SP", fullName: "Marília-SP" },
  { city: "Araraquara", state: "SP", fullName: "Araraquara-SP" },
  { city: "Presidente Prudente", state: "SP", fullName: "Presidente Prudente-SP" },
  { city: "São Carlos", state: "SP", fullName: "São Carlos-SP" },
  { city: "Jaú", state: "SP", fullName: "Jaú-SP" },
  { city: "Dois Córregos", state: "SP", fullName: "Dois Córregos-SP" },
  { city: "Botucatu", state: "SP", fullName: "Botucatu-SP" },
  { city: "Bariri", state: "SP", fullName: "Bariri-SP" },
  { city: "Barra Bonita", state: "SP", fullName: "Barra Bonita-SP" },
  { city: "Itapuí", state: "SP", fullName: "Itapuí-SP" },
  { city: "Brotas", state: "SP", fullName: "Brotas-SP" },
  { city: "Ibitinga", state: "SP", fullName: "Ibitinga-SP" },
  { city: "Igaraçu do Tietê", state: "SP", fullName: "Igaraçu do Tietê-SP" },
  { city: "Lençóis Paulista", state: "SP", fullName: "Lençóis Paulista-SP" },
  { city: "Pederneiras", state: "SP", fullName: "Pederneiras-SP" },
  { city: "Agudos", state: "SP", fullName: "Agudos-SP" },
  { city: "Mineiros do Tietê", state: "SP", fullName: "Mineiros do Tietê-SP" },
  
  // Rio de Janeiro
  { city: "Rio de Janeiro", state: "RJ", fullName: "Rio de Janeiro-RJ" },
  { city: "São Gonçalo", state: "RJ", fullName: "São Gonçalo-RJ" },
  { city: "Duque de Caxias", state: "RJ", fullName: "Duque de Caxias-RJ" },
  { city: "Nova Iguaçu", state: "RJ", fullName: "Nova Iguaçu-RJ" },
  { city: "Niterói", state: "RJ", fullName: "Niterói-RJ" },
  { city: "Belford Roxo", state: "RJ", fullName: "Belford Roxo-RJ" },
  { city: "Campos dos Goytacazes", state: "RJ", fullName: "Campos dos Goytacazes-RJ" },
  { city: "São João de Meriti", state: "RJ", fullName: "São João de Meriti-RJ" },
  { city: "Petrópolis", state: "RJ", fullName: "Petrópolis-RJ" },
  { city: "Volta Redonda", state: "RJ", fullName: "Volta Redonda-RJ" },
  { city: "Macaé", state: "RJ", fullName: "Macaé-RJ" },
  
  // Minas Gerais
  { city: "Belo Horizonte", state: "MG", fullName: "Belo Horizonte-MG" },
  { city: "Uberlândia", state: "MG", fullName: "Uberlândia-MG" },
  { city: "Contagem", state: "MG", fullName: "Contagem-MG" },
  { city: "Juiz de Fora", state: "MG", fullName: "Juiz de Fora-MG" },
  { city: "Betim", state: "MG", fullName: "Betim-MG" },
  { city: "Montes Claros", state: "MG", fullName: "Montes Claros-MG" },
  { city: "Ribeirão das Neves", state: "MG", fullName: "Ribeirão das Neves-MG" },
  { city: "Uberaba", state: "MG", fullName: "Uberaba-MG" },
  { city: "Governador Valadares", state: "MG", fullName: "Governador Valadares-MG" },
  { city: "Ipatinga", state: "MG", fullName: "Ipatinga-MG" },
  { city: "Sete Lagoas", state: "MG", fullName: "Sete Lagoas-MG" },
  { city: "Divinópolis", state: "MG", fullName: "Divinópolis-MG" },
  { city: "Poços de Caldas", state: "MG", fullName: "Poços de Caldas-MG" },
  
  // Rio Grande do Sul
  { city: "Porto Alegre", state: "RS", fullName: "Porto Alegre-RS" },
  { city: "Caxias do Sul", state: "RS", fullName: "Caxias do Sul-RS" },
  { city: "Pelotas", state: "RS", fullName: "Pelotas-RS" },
  { city: "Canoas", state: "RS", fullName: "Canoas-RS" },
  { city: "Santa Maria", state: "RS", fullName: "Santa Maria-RS" },
  { city: "Gravataí", state: "RS", fullName: "Gravataí-RS" },
  { city: "Viamão", state: "RS", fullName: "Viamão-RS" },
  { city: "Passo Fundo", state: "RS", fullName: "Passo Fundo-RS" },
  { city: "Novo Hamburgo", state: "RS", fullName: "Novo Hamburgo-RS" },
  { city: "São Leopoldo", state: "RS", fullName: "São Leopoldo-RS" },
  { city: "Rio Grande", state: "RS", fullName: "Rio Grande-RS" },
  
  // Paraná
  { city: "Curitiba", state: "PR", fullName: "Curitiba-PR" },
  { city: "Londrina", state: "PR", fullName: "Londrina-PR" },
  { city: "Maringá", state: "PR", fullName: "Maringá-PR" },
  { city: "Ponta Grossa", state: "PR", fullName: "Ponta Grossa-PR" },
  { city: "Cascavel", state: "PR", fullName: "Cascavel-PR" },
  { city: "São José dos Pinhais", state: "PR", fullName: "São José dos Pinhais-PR" },
  { city: "Foz do Iguaçu", state: "PR", fullName: "Foz do Iguaçu-PR" },
  { city: "Colombo", state: "PR", fullName: "Colombo-PR" },
  { city: "Guarapuava", state: "PR", fullName: "Guarapuava-PR" },
  { city: "Paranaguá", state: "PR", fullName: "Paranaguá-PR" },
  
  // Santa Catarina
  { city: "Florianópolis", state: "SC", fullName: "Florianópolis-SC" },
  { city: "Joinville", state: "SC", fullName: "Joinville-SC" },
  { city: "Blumenau", state: "SC", fullName: "Blumenau-SC" },
  { city: "São José", state: "SC", fullName: "São José-SC" },
  { city: "Chapecó", state: "SC", fullName: "Chapecó-SC" },
  { city: "Criciúma", state: "SC", fullName: "Criciúma-SC" },
  { city: "Itajaí", state: "SC", fullName: "Itajaí-SC" },
  { city: "Balneário Camboriú", state: "SC", fullName: "Balneário Camboriú-SC" },
  { city: "Jaraguá do Sul", state: "SC", fullName: "Jaraguá do Sul-SC" },
  
  // Bahia
  { city: "Salvador", state: "BA", fullName: "Salvador-BA" },
  { city: "Feira de Santana", state: "BA", fullName: "Feira de Santana-BA" },
  { city: "Vitória da Conquista", state: "BA", fullName: "Vitória da Conquista-BA" },
  { city: "Camaçari", state: "BA", fullName: "Camaçari-BA" },
  { city: "Itabuna", state: "BA", fullName: "Itabuna-BA" },
  { city: "Juazeiro", state: "BA", fullName: "Juazeiro-BA" },
  { city: "Ilhéus", state: "BA", fullName: "Ilhéus-BA" },
  { city: "Lauro de Freitas", state: "BA", fullName: "Lauro de Freitas-BA" },
  { city: "Jequié", state: "BA", fullName: "Jequié-BA" },
  { city: "Barreiras", state: "BA", fullName: "Barreiras-BA" },
  
  // Pernambuco
  { city: "Recife", state: "PE", fullName: "Recife-PE" },
  { city: "Jaboatão dos Guararapes", state: "PE", fullName: "Jaboatão dos Guararapes-PE" },
  { city: "Olinda", state: "PE", fullName: "Olinda-PE" },
  { city: "Caruaru", state: "PE", fullName: "Caruaru-PE" },
  { city: "Petrolina", state: "PE", fullName: "Petrolina-PE" },
  { city: "Paulista", state: "PE", fullName: "Paulista-PE" },
  { city: "Cabo de Santo Agostinho", state: "PE", fullName: "Cabo de Santo Agostinho-PE" },
  { city: "Camaragibe", state: "PE", fullName: "Camaragibe-PE" },
  { city: "Garanhuns", state: "PE", fullName: "Garanhuns-PE" },
  
  // Ceará
  { city: "Fortaleza", state: "CE", fullName: "Fortaleza-CE" },
  { city: "Caucaia", state: "CE", fullName: "Caucaia-CE" },
  { city: "Juazeiro do Norte", state: "CE", fullName: "Juazeiro do Norte-CE" },
  { city: "Maracanaú", state: "CE", fullName: "Maracanaú-CE" },
  { city: "Sobral", state: "CE", fullName: "Sobral-CE" },
  { city: "Crato", state: "CE", fullName: "Crato-CE" },
  { city: "Itapipoca", state: "CE", fullName: "Itapipoca-CE" },
  
  // Distrito Federal
  { city: "Brasília", state: "DF", fullName: "Brasília-DF" },
  
  // Goiás
  { city: "Goiânia", state: "GO", fullName: "Goiânia-GO" },
  { city: "Aparecida de Goiânia", state: "GO", fullName: "Aparecida de Goiânia-GO" },
  { city: "Anápolis", state: "GO", fullName: "Anápolis-GO" },
  { city: "Rio Verde", state: "GO", fullName: "Rio Verde-GO" },
  { city: "Luziânia", state: "GO", fullName: "Luziânia-GO" },
  { city: "Águas Lindas de Goiás", state: "GO", fullName: "Águas Lindas de Goiás-GO" },
  
  // Espírito Santo
  { city: "Vitória", state: "ES", fullName: "Vitória-ES" },
  { city: "Vila Velha", state: "ES", fullName: "Vila Velha-ES" },
  { city: "Serra", state: "ES", fullName: "Serra-ES" },
  { city: "Cariacica", state: "ES", fullName: "Cariacica-ES" },
  { city: "Cachoeiro de Itapemirim", state: "ES", fullName: "Cachoeiro de Itapemirim-ES" },
  { city: "Linhares", state: "ES", fullName: "Linhares-ES" },
  
  // Pará
  { city: "Belém", state: "PA", fullName: "Belém-PA" },
  { city: "Ananindeua", state: "PA", fullName: "Ananindeua-PA" },
  { city: "Santarém", state: "PA", fullName: "Santarém-PA" },
  { city: "Marabá", state: "PA", fullName: "Marabá-PA" },
  { city: "Castanhal", state: "PA", fullName: "Castanhal-PA" },
  { city: "Parauapebas", state: "PA", fullName: "Parauapebas-PA" },
  
  // Outros estados
  { city: "Manaus", state: "AM", fullName: "Manaus-AM" },
  { city: "Natal", state: "RN", fullName: "Natal-RN" },
  { city: "Campo Grande", state: "MS", fullName: "Campo Grande-MS" },
  { city: "João Pessoa", state: "PB", fullName: "João Pessoa-PB" },
  { city: "Teresina", state: "PI", fullName: "Teresina-PI" },
  { city: "São Luís", state: "MA", fullName: "São Luís-MA" },
  { city: "Maceió", state: "AL", fullName: "Maceió-AL" },
  { city: "Cuiabá", state: "MT", fullName: "Cuiabá-MT" },
  { city: "Aracaju", state: "SE", fullName: "Aracaju-SE" },
  { city: "Porto Velho", state: "RO", fullName: "Porto Velho-RO" },
  { city: "Palmas", state: "TO", fullName: "Palmas-TO" },
  { city: "Rio Branco", state: "AC", fullName: "Rio Branco-AC" },
  { city: "Macapá", state: "AP", fullName: "Macapá-AP" },
  { city: "Boa Vista", state: "RR", fullName: "Boa Vista-RR" }
];

// Extrair lista completa para compatibilidade
export const brasileiroCities = cidadesBrasileiras.map(city => city.fullName);

// Função para encontrar a cidade mais próxima de uma coordenada geográfica
export function findNearestCity(lat: number, lng: number): string | null {
  // Mapa com as coordenadas aproximadas das principais cidades brasileiras
  // Formato: { "cidade-UF": [latitude, longitude] }
  const cidadesCoords: Record<string, [number, number]> = {
    "São Paulo-SP": [-23.5505, -46.6333],
    "Rio de Janeiro-RJ": [-22.9068, -43.1729],
    "Brasília-DF": [-15.7801, -47.9292],
    "Salvador-BA": [-12.9714, -38.5014],
    "Fortaleza-CE": [-3.7172, -38.5433],
    "Belo Horizonte-MG": [-19.9167, -43.9345],
    "Manaus-AM": [-3.1190, -60.0217],
    "Curitiba-PR": [-25.4195, -49.2646],
    "Recife-PE": [-8.0476, -34.8770],
    "Porto Alegre-RS": [-30.0328, -51.2300],
    "Belém-PA": [-1.4558, -48.4902],
    "Goiânia-GO": [-16.6789, -49.2539],
    "Dois Córregos-SP": [-22.3697, -48.3845],
    "Jaú-SP": [-22.2936, -48.5592],
    "Mineiros do Tietê-SP": [-22.4113, -48.4513],
    "São Carlos-SP": [-22.0113, -47.8911]
  };

  // Função para calcular a distância entre dois pontos usando a fórmula de Haversine
  const calcularDistancia = (lat1: number, lon1: number, lat2: number, lon2: number): number => {
    const R = 6371; // Raio da Terra em km
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a = 
      Math.sin(dLat/2) * Math.sin(dLat/2) +
      Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * 
      Math.sin(dLon/2) * Math.sin(dLon/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    const distancia = R * c; // Distância em km
    return distancia;
  };

  // Encontrar a cidade mais próxima
  let cidadeMaisProxima: string | null = null;
  let menorDistancia = Infinity;

  for (const [cidade, coords] of Object.entries(cidadesCoords)) {
    const distancia = calcularDistancia(lat, lng, coords[0], coords[1]);
    if (distancia < menorDistancia) {
      menorDistancia = distancia;
      cidadeMaisProxima = cidade;
    }
  }

  console.log(`Cidade mais próxima encontrada: ${cidadeMaisProxima} (distância: ${menorDistancia.toFixed(2)} km)`);
  return cidadeMaisProxima;
}

// Importar funções de utilidades de texto para busca fuzzy
import { normalizeString, fuzzyContains, stringSimilarity } from './textUtils';

// Função melhorada para filtrar sugestões com base no input do usuário
export function filterCitySuggestions(input: string): string[] {
  // Lista de cidades prioritárias que devem ser mostradas primeiro
  const priorityCities = [
    "São Paulo-SP", "Rio de Janeiro-RJ", "Brasília-DF", 
    "Salvador-BA", "Fortaleza-CE", "Belo Horizonte-MG",
    "Campinas-SP", "Ribeirão Preto-SP", "Araraquara-SP",
    "Bauru-SP", "São Carlos-SP", "Jaú-SP", "Dois Córregos-SP",
    "Mineiros do Tietê-SP"
  ];
  
  // Se não tiver input, retornar lista de cidades prioritárias
  if (!input || input.length === 0) {
    return priorityCities;
  }
  
  // Normalizar a entrada para comparação
  const normalizedInput = normalizeString(input);
  
  // Tratar casos especiais de erros comuns
  const commonMistakes: {[key: string]: string[]} = {
    "ribeirao prato": ["ribeirao preto", "ribeirão preto"],
    "ribeirao pret": ["ribeirao preto", "ribeirão preto"],
    "rib preto": ["ribeirao preto", "ribeirão preto"],
    "sp": ["são paulo-sp"],
    "sao paulo": ["são paulo-sp"],
    "sampa": ["são paulo-sp"],
    "rio": ["rio de janeiro-rj"]
  };
  
  // Se a entrada corresponde a um erro comum, garantir que a cidade correta seja incluída
  let forcedMatches: string[] = [];
  for (const [mistake, corrections] of Object.entries(commonMistakes)) {
    if (normalizedInput.includes(normalizeString(mistake))) {
      forcedMatches = [...forcedMatches, ...corrections.map(c => {
        // Encontrar a cidade completa correspondente
        const matchedCity = cidadesBrasileiras.find(city => 
          normalizeString(city.city).includes(normalizeString(c)) || 
          normalizeString(city.fullName).includes(normalizeString(c))
        );
        return matchedCity ? matchedCity.fullName : "";
      })].filter(Boolean);
    }
  }
  
  // Definir limiares de similaridade com base no comprimento do input
  const exactMatchThreshold = 0.9;  // Para correspondências quase exatas
  const partialMatchThreshold = normalizedInput.length <= 3 ? 0.8 : 0.6;  // Para correspondências parciais
  
  // Encontrar todas as cidades com correspondência aproximada
  const matches = cidadesBrasileiras.map(city => {
    const cityNormalized = normalizeString(city.city);
    const fullNameNormalized = normalizeString(city.fullName);
    
    // Verificar similaridade
    const citySimilarity = stringSimilarity(cityNormalized, normalizedInput);
    const fullNameSimilarity = stringSimilarity(fullNameNormalized, normalizedInput);
    const fuzzyMatch = fuzzyContains(fullNameNormalized, normalizedInput, partialMatchThreshold);
    
    // Palavras da busca
    const words = normalizedInput.split(/\s+/);
    const cityWords = cityNormalized.split(/\s+/);
    
    // Verificar se as iniciais das palavras correspondem
    // Exemplo: "RP" deve corresponder a "Ribeirão Preto"
    const initialMatch = words.length === 1 && words[0].length <= 3 && 
      cityWords.length > 1 && 
      cityWords.map(w => w[0] || '').join('') === words[0];
    
    // Verificar se é uma correspondência de palavras iniciais
    // Exemplo: "rib p" deve corresponder a "Ribeirão Preto"
    const wordInitialsMatch = words.length >= 2 && 
      cityWords.length >= words.length &&
      words.every((word, i) => 
        i < cityWords.length && 
        cityWords[i].startsWith(word.substring(0, Math.min(word.length, 3)))
      );
    
    // Pontuação de prioridade baseada na qualidade da correspondência
    let score = 0;
    
    // Forçar correspondências para erros conhecidos
    if (forcedMatches.includes(city.fullName)) {
      score = 120; // Prioridade máxima para correspondências forçadas
    }
    // Verificações exatas têm prioridade alta
    else if (citySimilarity >= exactMatchThreshold || fullNameSimilarity >= exactMatchThreshold) {
      score = 100 + Math.max(citySimilarity, fullNameSimilarity);
    } 
    // Correspondências de iniciais têm prioridade alta
    else if (initialMatch || wordInitialsMatch) {
      score = 90;
    }
    // Correspondências que começam com o texto têm segunda prioridade mais alta
    else if (cityNormalized.startsWith(normalizedInput) || fullNameNormalized.startsWith(normalizedInput)) {
      score = 80 + Math.max(citySimilarity, fullNameSimilarity);
    }
    // Correspondências fuzzy têm terceira prioridade
    else if (fuzzyMatch) {
      score = 60 + Math.max(citySimilarity, fullNameSimilarity);
    }
    // Outras correspondências parciais têm prioridade mais baixa
    else if (cityNormalized.includes(normalizedInput) || fullNameNormalized.includes(normalizedInput)) {
      score = 40 + Math.max(citySimilarity, fullNameSimilarity);
    }
    
    return {
      city: city.fullName,
      score: score,
      hasMatch: score > 0
    };
  }).filter(item => item.hasMatch);
  
  // Para entrada curta (1-2 caracteres), dar prioridade às cidades principais
  if (normalizedInput.length <= 2) {
    // Aplicar a mesma lógica de correspondência às cidades prioritárias
    const priorityMatches = priorityCities.map(city => {
      const normalizedCity = normalizeString(city);
      const similarity = stringSimilarity(normalizedCity, normalizedInput);
      const fuzzyMatch = fuzzyContains(normalizedCity, normalizedInput, partialMatchThreshold);
      
      let score = 0;
      if (similarity >= exactMatchThreshold) {
        score = 200 + similarity; // Prioridade extra para cidades principais
      } else if (normalizedCity.startsWith(normalizedInput)) {
        score = 180 + similarity;
      } else if (fuzzyMatch) {
        score = 160 + similarity;
      } else if (normalizedCity.includes(normalizedInput)) {
        score = 140 + similarity;
      }
      
      return {
        city,
        score,
        hasMatch: score > 0
      };
    }).filter(item => item.hasMatch);
    
    // Combinar e ordenar por pontuação
    const combinedResults = [...priorityMatches, ...matches]
      .sort((a, b) => b.score - a.score)
      .map(item => item.city);
    
    // Remover duplicatas mantendo a ordem
    const uniqueResults = Array.from(new Set(combinedResults));
    
    return uniqueResults.slice(0, 50);
  }
  
  // Para entradas maiores, ordenar por pontuação
  const sortedResults = matches
    .sort((a, b) => b.score - a.score)
    .map(item => item.city);
  
  // Remover duplicatas mantendo a ordem
  const uniqueResults = Array.from(new Set(sortedResults));
  
  // Aumentando o limite para mostrar até 50 resultados
  return uniqueResults.slice(0, 50);
}