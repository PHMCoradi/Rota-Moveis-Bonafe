import React, { useState, useEffect } from 'react';
import { X } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from './ui/card';
import { getCityTrivia, getRandomCityFacts } from '@/lib/cityTrivia';
import { extractDayAndMonth } from '@/lib/holidays';
import confetti from 'canvas-confetti';

interface CityAnniversaryPopupProps {
  city: string;
  date: string;
  onClose: () => void;
}

export function CityAnniversaryPopup({ city, date, onClose }: CityAnniversaryPopupProps) {
  const [isAnimating, setIsAnimating] = useState(true);
  const [facts, setFacts] = useState<string[]>([]);
  const cityTrivia = getCityTrivia(city);
  const { day, month } = extractDayAndMonth(date);
  
  useEffect(() => {
    // Iniciar com confete ao montar
    launchConfetti();
    
    // Buscar fatos aleatórios sobre a cidade
    if (cityTrivia) {
      setFacts(getRandomCityFacts(city, 3));
    }
    
    // Finalizar a animação após 500ms
    const timer = setTimeout(() => setIsAnimating(false), 500);
    
    return () => {
      clearTimeout(timer);
    };
  }, [city, cityTrivia]);
  
  const launchConfetti = () => {
    try {
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 }
      });
    } catch (error) {
      console.error('Erro ao lançar confete:', error);
    }
  };
  
  if (!cityTrivia) return null;
  
  const formattedDate = `${day.toString().padStart(2, '0')}/${month.toString().padStart(2, '0')}`;
  const age = new Date().getFullYear() - cityTrivia.foundationYear;
  
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
      <Card className={`w-full max-w-md overflow-hidden shadow-lg ${isAnimating ? 'animate-bounce-in' : ''}`}>
        <CardHeader className="relative bg-gradient-to-r from-blue-600 to-cyan-500 text-white">
          <Button 
            variant="ghost" 
            size="icon" 
            className="absolute right-2 top-2 text-white hover:bg-white/20"
            onClick={onClose}
          >
            <X className="h-4 w-4" />
          </Button>
          
          <div className="flex flex-col items-center text-center">
            <div className="text-xl font-festive mb-1">🎉 Comemoração Especial 🎉</div>
            <CardTitle className="text-xl sm:text-2xl">
              Aniversário de {cityTrivia.cityName}
            </CardTitle>
            <CardDescription className="text-white/80 mt-1">
              {formattedDate} • {age} anos desde sua fundação em {cityTrivia.foundationYear}
            </CardDescription>
          </div>
        </CardHeader>
        
        <CardContent className="pt-6 pb-2 px-6">
          <div className="space-y-4">
            {cityTrivia.nicknames.length > 0 && (
              <div>
                <h4 className="font-medium text-sm text-muted-foreground mb-1">Conhecida como:</h4>
                <p className="italic">{cityTrivia.nicknames.join(' • ')}</p>
              </div>
            )}
            
            {facts.length > 0 && (
              <div>
                <h4 className="font-medium text-sm text-muted-foreground mb-1">Você sabia?</h4>
                <ul className="space-y-2">
                  {facts.map((fact, index) => (
                    <li key={index} className="flex items-start">
                      <span className="text-amber-500 mr-2">★</span>
                      <span>{fact}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}
            
            {cityTrivia.importantLandmarks.length > 0 && (
              <div>
                <h4 className="font-medium text-sm text-muted-foreground mb-1">Lugares para visitar:</h4>
                <p>{cityTrivia.importantLandmarks.slice(0, 3).join(' • ')}</p>
              </div>
            )}
          </div>
        </CardContent>
        
        <CardFooter className="flex justify-between border-t px-6 py-4">
          <Button variant="outline" size="sm" onClick={onClose}>
            Fechar
          </Button>
          <Button 
            variant="default" 
            size="sm"
            onClick={() => {
              launchConfetti();
              // Trocar para novos fatos
              setFacts(getRandomCityFacts(city, 3));
            }}
          >
            🎉 Mais curiosidades
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
}