import { useEffect, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Separator } from "@/components/ui/separator";
import { Trash2, Plus, MapPin, Navigation, Flag, Truck, EyeIcon, CheckIcon, BarChart, ArrowDownUp, CalendarRange, CalendarDays, Search, Car, Bus, Bike } from "lucide-react";
import { routeRequestSchema, vehicleTypes } from "@shared/schema";
import { filterCitySuggestions } from "@/lib/cities";
import { cn } from "@/lib/utils";
import { Switch } from "@/components/ui/switch";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { apiRequest } from "@/lib/queryClient";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { buscarCep, formatarCep, isCepFormat, gerarEnderecoFormatado } from "@/lib/cepData";
import { useCustomNames, forceUpdateCustomNames } from "@/lib/nameContext";


// Interface para sugestões de endereços
interface AddressSuggestion {
  displayName: string;
  value: string;
  isCity?: boolean; // Para diferenciar cidades de endereços completos
  secondaryText?: string; // Texto secundário para exibir detalhes adicionais (como cidade/estado)
}

interface RouteFormProps {
  onSubmit: (data: { 
    origem: string; 
    paradas?: string[];
    nome?: string;
    otimizar?: boolean;
    dataInicioEntrega?: string;
    dataFimEntrega?: string;
    tipoVeiculo?: string;
  }) => void;
  // Adicionando callback para pré-visualização de rota
  onPreviewRoute?: (data: {
    origem: string;
    paradas?: string[];
    otimizar?: boolean;
    dataInicioEntrega?: string;
    dataFimEntrega?: string;
    tipoVeiculo?: string;
  }) => void;
  isLoading: boolean;
}

export function RouteForm({ onSubmit, onPreviewRoute, isLoading }: RouteFormProps) {
  const [paradas, setParadas] = useState<string[]>([]);
  const [sugestoes, setSugestoes] = useState<AddressSuggestion[][]>([]);
  const [origemSugestoes, setOrigemSugestoes] = useState<AddressSuggestion[]>([]);
  const [campoPesquisando, setCampoPesquisando] = useState<string | null>(null);
  const [isLocalizando, setIsLocalizando] = useState(false);
  const [dataInicioAberta, setDataInicioAberta] = useState(false);
  const [dataFimAberta, setDataFimAberta] = useState(false);
  const { customNames, updateName, removeName, clearAll } = useCustomNames(); // Usar o contexto global
  const origemRef = useRef<HTMLInputElement>(null);
  const paradaRefs = useRef<(HTMLInputElement | null)[]>([]);

  // Extended schema with name field and otimizar option
  const extendedSchema = routeRequestSchema.extend({
    nome: z.string().optional(),
    otimizar: z.boolean().default(true), // Por padrão, a otimização está ativada
    dataInicioEntrega: z.string().optional(), // Data inicial de entrega (opcional)
    dataFimEntrega: z.string().optional(),    // Data final de entrega (opcional)
    tipoVeiculo: z.enum(vehicleTypes).default("caminhao_2_eixos"), // Tipo de veículo para cálculo de pedágio
  });

  const form = useForm<z.infer<typeof extendedSchema>>({
    resolver: zodResolver(extendedSchema),
    defaultValues: {
      origem: "",
      paradas: [],
      nome: "",
      otimizar: true, // Por padrão, a otimização está ativada
      dataInicioEntrega: "",
      dataFimEntrega: "",
      tipoVeiculo: "caminhao_2_eixos", // Por padrão, caminhão de 2 eixos
    },
  });
  
  // Estado para controlar a opção de otimização e uma referência para rastrear o último valor
  const [otimizarRota, setOtimizarRota] = useState(true);
  const valorOtimizacaoRef = useRef(true);
  
  // Quando o componente é montado, definir o valor padrão de otimização
  useEffect(() => {
    console.log("Definindo valor padrão de otimização: true");
    form.setValue("otimizar", true);
    valorOtimizacaoRef.current = true;
  }, []);

  // Os nomes personalizados agora são carregados via contexto global
  
  // Função para usar geolocalização para definir a origem
  const usarLocalizacaoAtual = () => {
    if (navigator.geolocation) {
      setIsLocalizando(true);
      // API de geolocalização do navegador
      navigator.geolocation.getCurrentPosition(
        (position) => {
          // Obtém as coordenadas
          const lat = position.coords.latitude;
          const lng = position.coords.longitude;
          
          console.log(`Coordenadas atuais: ${lat}, ${lng}`);
          
          // Verificar se a localização está próxima de Bauru (provavelmente mock do Replit)
          const isBauruMockLocation = 
            Math.abs(lat - (-22.3346)) < 0.01 && 
            Math.abs(lng - (-49.0612)) < 0.01;
          
          if (isBauruMockLocation) {
            console.log('Detectada localização mockada de Bauru, usando endereço em Dois Córregos como origem');
            // Usar Dois Córregos como localização padrão
            form.setValue('origem', 'Dois Córregos-SP');
            setOrigemSugestoes([]);
            setTimeout(() => attemptPreviewRoute(), 500);
            setIsLocalizando(false);
          } else {
            // Coordenadas reais, usar a cidade mais próxima
            import('@/lib/cities').then(({ findNearestCity }) => {
              const cidade = findNearestCity(lat, lng);
              if (cidade) {
                // Preenche o campo de origem com a cidade encontrada
                form.setValue('origem', cidade);
                // Limpa as sugestões
                setOrigemSugestoes([]);
                // Tentar preview da rota se já tivermos paradas
                setTimeout(() => attemptPreviewRoute(), 500);
              } else {
                console.log('Não foi possível encontrar uma cidade próxima.');
                // Usar Dois Córregos como fallback
                form.setValue('origem', 'Dois Córregos-SP');
              }
              setIsLocalizando(false);
            });
          }
        },
        (error) => {
          console.error('Erro ao obter localização:', error.message);
          alert('Não foi possível obter sua localização. Verifique se você permitiu o acesso à localização no navegador.');
          setIsLocalizando(false);
        },
        { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
      );
    } else {
      alert('Seu navegador não suporta geolocalização.');
    }
  };
  
  // Função para converter do formato Date para o formato DD/MM
  const formatarDataDDMM = (data: Date): string => {
    const dia = String(data.getDate()).padStart(2, '0');
    const mes = String(data.getMonth() + 1).padStart(2, '0'); // +1 porque mês começa em 0
    return `${dia}/${mes}`;
  };
  
  // Função para converter do formato DD/MM para Date
  const converterParaDate = (dataDDMM: string | undefined): Date | null => {
    if (!dataDDMM || dataDDMM.length !== 5) return null;
    
    const [dia, mes] = dataDDMM.split('/').map(Number);
    if (isNaN(dia) || isNaN(mes)) return null;
    
    const data = new Date();
    data.setDate(dia);
    data.setMonth(mes - 1); // -1 porque mês começa em 0
    return data;
  };
  
  // Handler para quando selecionar data no calendário de início
  const handleDataInicioSelecionada = (data: Date | undefined) => {
    if (data) {
      const dataFormatada = formatarDataDDMM(data);
      form.setValue('dataInicioEntrega', dataFormatada);
      setDataInicioAberta(false);
      
      // Tentar recalcular a rota após selecionar a data
      setTimeout(() => attemptPreviewRoute(), 300);
    }
  };
  
  // Handler para quando selecionar data no calendário de fim
  const handleDataFimSelecionada = (data: Date | undefined) => {
    if (data) {
      const dataFormatada = formatarDataDDMM(data);
      form.setValue('dataFimEntrega', dataFormatada);
      setDataFimAberta(false);
      
      // Tentar recalcular a rota após selecionar a data
      setTimeout(() => attemptPreviewRoute(), 300);
    }
  };
  
  // Função para obter a data de segunda e sexta da semana atual
  const obterDatasSemanais = () => {
    const hoje = new Date();
    const diaSemana = hoje.getDay(); // 0 = Domingo, 1 = Segunda, ..., 6 = Sábado
    
    // Calcular a data da segunda-feira desta semana
    const segunda = new Date(hoje);
    const diasAteSegunda = diaSemana === 0 ? -6 : 1 - diaSemana; // Se for domingo, volta 6 dias
    segunda.setDate(hoje.getDate() + diasAteSegunda);
    
    // Calcular a data da sexta-feira desta semana
    const sexta = new Date(segunda);
    sexta.setDate(segunda.getDate() + 4); // 4 dias após a segunda é sexta
    
    return {
      dataInicioEntrega: formatarDataDDMM(segunda),
      dataFimEntrega: formatarDataDDMM(sexta)
    };
  };

  // Ao montar o componente, preenche a origem com valor padrão e as datas
  useEffect(() => {
    // Definir origem padrão em vez de usar localização atual
    form.setValue('origem', 'Dois Córregos-SP');
    
    // Preencher as datas com segunda e sexta da semana atual
    const { dataInicioEntrega, dataFimEntrega } = obterDatasSemanais();
    form.setValue('dataInicioEntrega', dataInicioEntrega);
    form.setValue('dataFimEntrega', dataFimEntrega);
    
    // Os nomes personalizados agora são carregados pelo contexto global
    console.log('Nomes personalizados carregados do localStorage:', customNames);
  }, []);

  // Substituindo Google Maps Autocomplete por nossas próprias sugestões de endereços
  useEffect(() => {
    // Mantem o array de referências atualizado com o número de paradas
    paradaRefs.current = paradaRefs.current.slice(0, paradas.length);
    
    // Inicializa as referências para cada parada se elas não existirem
    while (paradaRefs.current.length < paradas.length) {
      paradaRefs.current.push(null);
    }
  }, [paradas.length]);
  
  // Efeito para detectar mudanças nos nomes personalizados
  useEffect(() => {
    console.log('Estado de nomes personalizados mudou:', Object.keys(customNames).length);
    console.log('Conteúdo atual dos nomes personalizados:', customNames);
    
    // Para forçar renderização quando os nomes forem carregados
    if (Object.keys(customNames).length > 0) {
      console.log('Nomes personalizados disponíveis, forçando atualização da UI');
      // Esta chamada força um re-render
      const newParadas = [...paradas];
      setParadas(newParadas);
    }
  }, [customNames]);
  
  // Cache de resultados de busca para melhorar performance
  const searchCache = useRef<Record<string, { timestamp: number, results: AddressSuggestion[] }>>({});
  
  // Controlar solicitação atual para evitar resultados ultrapassados
  const searchCurrentRequestId = useRef<number>(0);
  
  // Função para buscar endereços usando a API do servidor - com cache
  const buscarEnderecos = async (query: string): Promise<AddressSuggestion[]> => {
    if (!query || query.length < 2) {
      return [];
    }
    
    // Normalizar query para fins de cache (remover espaços em excesso)
    const normalizedQuery = query.trim().toLowerCase();
    
    // Verificar cache primeiro (válido por 5 minutos = 300000 ms)
    const cacheEntry = searchCache.current[normalizedQuery];
    const now = Date.now();
    if (cacheEntry && (now - cacheEntry.timestamp < 300000)) {
      console.log(`Usando cache para "${normalizedQuery}"`);
      return cacheEntry.results;
    }
    
    try {
      // Primeiro, verificar se há sugestões de cidades brasileiras (filtro local rápido)
      const citySuggestions = filterCitySuggestions(query);
      const cityResults = citySuggestions.map(city => ({ 
        displayName: city, 
        value: city,
        isCity: true, // Marca como cidade para exibir ícone diferente
        secondaryText: "Brasil" // Texto secundário para contexto
      }));
      
      // Retornar resultados locais imediatamente para uma melhor experiência do usuário
      if (cityResults.length > 0) {
        // Armazenar em cache temporário enquanto busca mais resultados
        const tempResults = cityResults.slice(0, 10);
        searchCache.current[normalizedQuery] = { timestamp: now, results: tempResults };
        
        // Se tivermos muitas sugestões de cidades e o texto for curto, não precisamos consultar a API
        if (cityResults.length > 3 && query.length < 4) {
          console.log(`Usando apenas resultados locais para "${query}" (${cityResults.length} cidades)`);
          return tempResults;
        }
      }
      
      // Verificar se a busca é especificamente o CEP de Vila Coradi
      const cepBotafogo = /^17302[-\s]?122$|^17302122$/i.test(query);
      
      // Verificar casos especiais: Rua Botafogo / Vila Coradi
      const botafogoPattern = /(^|\s)(botafogo|r\.?\s+botafogo|rua\s+botafogo)/i;
      const botafogoMention = botafogoPattern.test(query) || cepBotafogo;
      
      // Verificar se há números na query (para endereços com número)
      const botafogoNumeroPattern = /botafogo\s*[,\s.-]*\s*(\d+)/i;
      const botafogoNumero = botafogoNumeroPattern.exec(query);
      
      // Padrão genérico para rua com número
      const ruaNumeroPattern = /(?:rua|r\.?)\s+([a-zÀ-ÿ\s]+)\s*[,\s.-]*\s*(\d+)/i;
      const ruaNumeroMatch = ruaNumeroPattern.exec(query);
      
      let directResults: AddressSuggestion[] = [];
      
      // CASOS ESPECIAIS
      // Verificar se é especificamente o CEP da Vila Coradi ou uma menção à Rua Botafogo
      const isCepBotafogo = /^17302[-\s]?122$|^17302122$/i.test(query);
      
      if (isCepBotafogo) {
        console.log("Detectado CEP específico da Rua Botafogo em Vila Coradi");
        
        // Para o CEP específico, mostrar apenas UMA sugestão com o endereço correto
        const botafogoResult = {
          displayName: "Rua Botafogo 135",
          value: "Rua Botafogo 135, Vila Coradi - Dois Córregos-SP",
          isCity: false,
          secondaryText: "Vila Coradi, Dois Córregos-SP (CEP 17302-122)"
        };
        
        // Guardar no cache
        searchCache.current[normalizedQuery] = { timestamp: now, results: [botafogoResult] };
        
        // Retornar apenas o resultado para o CEP específico, ignorando todos os outros
        return [botafogoResult];
      }
      // Caso seja menção à Rua Botafogo, mas não o CEP específico
      else if (botafogoMention) {
        console.log("Detectada busca relacionada a Rua Botafogo!");
        
        // Determinar o número (135 como padrão)
        let numero = "135";
        
        if (botafogoNumero) {
          numero = botafogoNumero[1];
          console.log(`Detectado número específico para Botafogo: ${numero}`);
        } else if (ruaNumeroMatch && ruaNumeroMatch[1].toLowerCase().includes('botafogo')) {
          numero = ruaNumeroMatch[2];
          console.log(`Detectado número no padrão rua+número: ${numero}`);
        } else if (query.match(/\d+/)) {
          numero = query.match(/\d+/)![0];
          console.log(`Detectado número genérico na query: ${numero}`);
        }
        
        // Adicionar apenas uma versão (a mais simples e clara)
        directResults.push({
          displayName: `Rua Botafogo ${numero}`,
          value: `Rua Botafogo ${numero}, Vila Coradi - Dois Córregos-SP`,
          isCity: false,
          secondaryText: "Vila Coradi, Dois Córregos-SP"
        });
      }
      
      // Verificar se é um CEP usando a função específica
      const possibleCep = query.replace(/\D/g, '');
      const isCep = isCepFormat(query) || (possibleCep.length === 8);
      
      // Se parecer ser um CEP, tentar encontrar no banco de dados
      if (isCep) {
        // Formatar o CEP para exibição
        const formattedCep = formatarCep(query);
        
        // Buscar no banco de dados via API
        const cepInfo = await buscarCep(query);
        
        if (cepInfo) {
          console.log(`CEP encontrado no banco local: ${formattedCep}`);
          
          // Adicionar endereço encontrado localmente como primeira sugestão
          directResults.push({
            displayName: cepInfo.logradouro,
            value: `${cepInfo.logradouro}, ${cepInfo.bairro} - ${cepInfo.cidade}-${cepInfo.estado}`,
            isCity: false,
            secondaryText: `${cepInfo.bairro}, ${cepInfo.cidade}-${cepInfo.estado} (CEP ${formattedCep})`
          });
          
          // Se temos um resultado local, podemos retornar imediatamente para melhor performance
          if (directResults.length > 0) {
            searchCache.current[normalizedQuery] = { timestamp: now, results: directResults };
            return directResults;
          }
        } else {
          console.log(`CEP não encontrado no banco local: ${formattedCep}. Será consultado via API.`);
        }
      }
      
      // Adicionar imediatamente ao cache temporário se temos resultados diretos
      if (directResults.length > 0) {
        const combinedTemp = [...directResults, ...(cityResults.slice(0, 5))];
        searchCache.current[normalizedQuery] = { timestamp: now, results: combinedTemp };
      }
      
      // Armazenar uma variável para identificar o request atual
      const requestId = Date.now();
      searchCurrentRequestId.current = requestId;
      
      // Em paralelo, fazer request para a API de busca (para casos normais)
      try {
        // Iniciar busca na API para casos normais
        const fetchPromise = apiRequest(`/api/search/addresses?query=${encodeURIComponent(query)}`);
        
        // Definir um timeout para a busca na API (5 segundos)
        const timeoutPromise = new Promise<null>((resolve) => {
          setTimeout(() => resolve(null), 5000);
        });
        
        // Usar a primeira resposta: ou a API ou o timeout
        const response = await Promise.race([fetchPromise, timeoutPromise]);
        
        // Verificar se este ainda é o request mais recente
        if (searchCurrentRequestId.current !== requestId) {
          console.log(`Request ${requestId} cancelado, há um request mais recente`);
          return []; // Retornar vazio para não sobrescrever resultados mais novos
        }
        
        if (response && Array.isArray(response)) {
          // Se estamos buscando um CEP e a API encontrou resultados, 
          // usamos APENAS os resultados da API
          const isCepQuery = isCepFormat(query);
          
          // Converter resposta para nosso formato AddressSuggestion
          const addressResults = response.map(addr => ({
            displayName: addr.displayName || addr.value,
            value: addr.value,
            isCity: Boolean(addr.isCity),
            secondaryText: addr.secondaryText || undefined
          }));
          
          // Se é uma busca de CEP e temos resultados da API, usamos apenas eles
          if (isCepQuery && addressResults.length > 0) {
            // Para CEPs, preferimos apenas os resultados da API (que já contém os endereços reais)
            const finalResults = addressResults;
            
            // Guardar no cache
            searchCache.current[normalizedQuery] = { timestamp: now, results: finalResults };
            console.log(`Encontrados ${finalResults.length} resultados de CEP para "${query}"`);
            return finalResults;
          }
          
          // Para outros casos (não CEP ou CEP sem resultados na API)
          // Combinar resultados de cidades, endereços diretos e da API
          const combinedResults = [...cityResults, ...directResults];
          
          // Adicionar resultados de endereços que não sejam duplicados
          addressResults.forEach(addr => {
            if (!combinedResults.some(item => item.value === addr.value)) {
              combinedResults.push(addr);
            }
          });
          
          // Guardar no cache
          const finalResults = combinedResults.slice(0, 10);
          searchCache.current[normalizedQuery] = { timestamp: now, results: finalResults };
          
          console.log(`Encontrados ${finalResults.length} resultados combinados para "${query}"`);
          return finalResults;
        }
      } catch (apiError) {
        console.error("Erro ao consultar API de endereços:", apiError);
      }
      
      // Se API falhou ou timeout, usar apenas resultados locais
      const fallbackResults = [...cityResults, ...directResults].slice(0, 10);
      searchCache.current[normalizedQuery] = { timestamp: now, results: fallbackResults };
      console.log(`Usando ${fallbackResults.length} resultados locais para "${query}" (API indisponível)`);
      return fallbackResults;
    } catch (error) {
      console.error("Erro ao buscar endereços:", error);
      
      // Verificar pelo caso especial de Botafogo ou CEP específico mesmo em caso de erro
      const botafogoMention = /botafogo/i.test(query);
      const cepBotafogo = /^17302[-\s]?122$|^17302122$/i.test(query);
      
      if (botafogoMention || cepBotafogo) {
        console.log("Detectada busca relacionada a Rua Botafogo (no bloco de erro)!");
        // Determinar o número a ser usado (135 como padrão)
        let numero = "135";
        const numMatch = query.match(/\d+/);
        if (numMatch) numero = numMatch[0];
        
        const botafogoResults = [
          {
            displayName: `Rua Botafogo ${numero}`,
            value: `Rua Botafogo ${numero}, Vila Coradi - Dois Córregos-SP`,
            isCity: false,
            secondaryText: "Vila Coradi, Dois Córregos-SP"
          }
        ];
        
        // Guardar no cache
        searchCache.current[normalizedQuery] = { timestamp: now, results: botafogoResults };
        return botafogoResults;
      }
      
      // Para os demais casos de erro, retorna apenas as sugestões de cidades
      const citySuggestions = filterCitySuggestions(query);
      const errorResults = citySuggestions.map(city => ({ 
        displayName: city, 
        value: city,
        isCity: true
      })).slice(0, 10);
      
      // Guardar no cache mesmo em caso de erro
      searchCache.current[normalizedQuery] = { timestamp: now, results: errorResults };
      return errorResults;
    }
  };

  const handleSubmit = (data: z.infer<typeof extendedSchema>) => {
    data.paradas = paradas;
    data.otimizar = otimizarRota; // Usar o estado atual de otimização
    form.setValue('otimizar', otimizarRota); // Atualizar o formulário também
    
    // Adicionar as datas de início e fim se estiverem preenchidas
    const dataInicioEntrega = form.getValues('dataInicioEntrega');
    const dataFimEntrega = form.getValues('dataFimEntrega');
    
    if (dataInicioEntrega) data.dataInicioEntrega = dataInicioEntrega;
    if (dataFimEntrega) data.dataFimEntrega = dataFimEntrega;
    
    // Garantir que o tipo de veículo está definido
    const tipoVeiculo = form.getValues('tipoVeiculo');
    data.tipoVeiculo = tipoVeiculo || 'caminhao_2_eixos';
    
    console.log('Calculando rota com dados:', data);
    onSubmit(data);
  };

  const addParada = () => {
    setParadas([...paradas, ""]);
    // Podemos tentar calcular preview depois de adicionar a nova parada
    // mas deixamos para quando o usuário preencher a parada
  };
  
  // Função para importar múltiplas paradas de um arquivo de texto
  const importarParadasDeArquivo = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    
    const reader = new FileReader();
    reader.onload = (e) => {
      const content = e.target?.result as string;
      if (!content) return;
      
      // Separar por linhas e filtrar linhas vazias
      const linhas = content.split(/\r?\n/).filter(linha => linha.trim().length > 0);
      
      if (linhas.length === 0) {
        alert('O arquivo não contém paradas válidas.');
        return;
      }
      
      // SOLUÇÃO CORRIGIDA: Limpar completamente os nomes personalizados antes de importar
      console.log("Processando importação de arquivo - redefinindo nomes personalizados");
      
      try {
        // Limpar os nomes primeiro no localStorage
        localStorage.removeItem('paradaNomes');
        localStorage.setItem('paradaNomes', JSON.stringify({}));
        
        // Usar a função clearAll do contexto que limpa o estado React
        clearAll();
        
        console.log("Nomes personalizados limpos no início da importação");
      } catch (error) {
        console.error("Erro ao limpar nomes personalizados:", error);
      }
      
      // Criar um novo objeto vazio para os nomes personalizados
      const novosNomesPersonalizados: Record<string, string> = {};
      
      // Processar cada linha como uma parada
      // Trabalhamos com um array completamente novo, em vez de modificar o existente
      const novasParadas: string[] = [];
      
      // Limitar a 50 paradas para não sobrecarregar
      const paradasParaAdicionar = linhas.slice(0, 50);
      let paradasAdicionadas = 0;
      
      paradasParaAdicionar.forEach(linha => {
        // Verificar se a linha está no formato "CEP,NOME"
        const partesLinha = linha.split(',');
        
        // Se a linha tem mais de uma parte separada por vírgula
        if (partesLinha.length >= 2) {
          // A primeira parte deve ser o CEP
          const cepParte = partesLinha[0].trim();
          // O resto é o nome (juntar caso tenha mais vírgulas)
          const nomeParte = partesLinha.slice(1).join(',').trim();
          
          // Verificar se o CEP é válido
          const cepMatch = cepParte.match(/\b\d{8}\b|\b\d{5}-\d{3}\b/);
          const cep = cepMatch ? cepMatch[0].replace(/\D/g, '') : null;
          
          if (cep && cep.length === 8) {
            // Formatar o CEP com hífen para melhor visualização
            const cepFormatado = `${cep.substring(0, 5)}-${cep.substring(5)}`;
            
            // Verificar se já temos este CEP nas paradas
            if (!novasParadas.some(p => p.includes(cep))) {
              // Usar o nome personalizado para este CEP, preservando o formato original
              if (nomeParte) {
                // Preservar exatamente o nome como está no arquivo, sem nenhuma formatação
                const nomeFinal = nomeParte;
                
                // Registrar o nome exato importado para debug
                console.log(`Nome importado para CEP ${cepFormatado}: "${nomeFinal}" (formato preservado, sem alterações)`);
                
                // Armazenar no objeto temporário
                novosNomesPersonalizados[cepFormatado] = nomeFinal;
                
                // IMPORTANTE: Atualizar no contexto global imediatamente, forçando a atualização
                console.log(`Aplicando nome personalizado para ${cepFormatado}: "${nomeFinal}"`);
                
                // Aplicar diretamente no localStorage para garantir persistência imediata
                try {
                  const storedNames = localStorage.getItem('paradaNomes');
                  const namesObj = storedNames ? JSON.parse(storedNames) : {};
                  namesObj[cepFormatado] = nomeFinal;
                  localStorage.setItem('paradaNomes', JSON.stringify(namesObj));
                } catch (e) {
                  console.error("Erro ao salvar nome no localStorage:", e);
                }
                
                // Também atualizar no contexto global do React
                updateName(cepFormatado, nomeFinal);
              }
              
              novasParadas.push(cepFormatado);
              paradasAdicionadas++;
            }
          } else if (nomeParte) {
            // Se o CEP não for válido mas temos um nome, usar o texto completo
            if (!novasParadas.some(p => p === linha.trim())) {
              novasParadas.push(linha.trim());
              paradasAdicionadas++;
            }
          }
        } else {
          // Formato antigo: verificar se é um CEP válido (8 dígitos)
          const cepMatch = linha.match(/\b\d{8}\b|\b\d{5}-\d{3}\b/);
          const cep = cepMatch ? cepMatch[0].replace(/\D/g, '') : null;
          
          if (cep && cep.length === 8) {
            // Formatar o CEP com hífen para melhor visualização
            const cepFormatado = `${cep.substring(0, 5)}-${cep.substring(5)}`;
            
            // Verificar se já temos este CEP nas paradas
            if (!novasParadas.some(p => p.includes(cep))) {
              novasParadas.push(cepFormatado);
              paradasAdicionadas++;
            }
          } else {
            // Se não for CEP, adicionar o texto como está
            // Adicionar apenas se ainda não tiver esta parada
            if (!novasParadas.some(p => p === linha.trim())) {
              novasParadas.push(linha.trim());
              paradasAdicionadas++;
            }
          }
        }
      });
      
      setParadas(novasParadas);
      form.setValue('paradas', novasParadas);
      
      // Armazenar nomes personalizados para uso posterior
      // Agora usando a função forceUpdateCustomNames para garantir sincronização completa
      if (Object.keys(novosNomesPersonalizados).length > 0) {
        console.log('Nomes personalizados importados:', novosNomesPersonalizados);
        
        // USAR A NOVA FUNÇÃO DE FORÇA PARA GARANTIR QUE OS NOMES SEJAM APLICADOS CORRETAMENTE
        try {
          // Esta função garante que tanto o localStorage quanto o contexto React serão atualizados
          const updatedNames = forceUpdateCustomNames(novosNomesPersonalizados);
          console.log('Estado atualizado força dos nomes personalizados:', updatedNames);
          
          // Forçar uma atualização dupla para garantir que a UI seja atualizada
          setTimeout(() => {
            // Aplicar cada nome diretamente no contexto para garantir que o estado React seja atualizado
            Object.entries(novosNomesPersonalizados).forEach(([chave, nome]) => {
              updateName(chave, nome);
              console.log(`Nome personalizado forçado para atualização: ${chave} => "${nome}"`);
            });
            
            // Esta é uma verificação final para confirmar que os nomes foram atualizados
            const storedNames = localStorage.getItem('paradaNomes');
            console.log('Estado final do localStorage após importação forçada:', storedNames);
          }, 100);
        } catch (error) {
          console.error('Erro ao forçar atualização dos nomes personalizados:', error);
        }
      }
      
      // Limpar o input de arquivo
      event.target.value = '';
      
      // Mostrar mensagem de sucesso
      alert(`${paradasAdicionadas} paradas importadas com sucesso! ${linhas.length > 50 ? '\n(Limitado às primeiras 50 linhas do arquivo)' : ''}`);
      
      // Se importou CEPs, tentar buscar e calcular a rota completa automaticamente
      if (paradasAdicionadas > 0) {
        // Função para verificar se uma parada contém um CEP
        const temCEP = (parada: string) => {
          return /\d{5}[-]?\d{3}/.test(parada);
        };
        
        // Verificar se as paradas incluem CEPs
        const temCEPs = novasParadas.some(temCEP);
        
        if (temCEPs) {
          console.log("CEPs detectados nas paradas importadas, calculando rota completa automaticamente");
          
          // Verificar se temos uma origem definida
          const origem = form.getValues('origem');
          
          if (!origem || origem.trim().length < 5) {
            alert('Por favor, defina um endereço de origem antes de importar paradas com CEPs.');
            return;
          }
          
          // Esperar um pouco para garantir que o contexto foi atualizado
          setTimeout(() => {
            console.log("Aguardando atualização do contexto de nomes personalizados...");
            
            // IMPORTANTE: Dar tempo para que o contexto de nomes personalizados seja atualizado
            setTimeout(() => {
              // Tentar obter preview da rota
              attemptPreviewRoute();
              
              // E depois calcular a rota completa
              setTimeout(() => {
                // Obter os valores atualizados do formulário
                const origemAtualizada = form.getValues('origem');
                const dataInicioEntrega = form.getValues('dataInicioEntrega');
                const dataFimEntrega = form.getValues('dataFimEntrega');
                const tipoVeiculo = form.getValues('tipoVeiculo') || 'caminhao_2_eixos';
                
                // Filtrar paradas vazias - Usar o array novasParadas para garantir consistência
                const validParadas = novasParadas.filter(p => p.trim().length > 0);
                
                console.log("Calculando rota completa com:", origemAtualizada, validParadas);
                console.log("Nomes personalizados no momento do cálculo:", Object.keys(customNames).length);
                
                // Verificar se temos uma origem válida
                if (origemAtualizada && origemAtualizada.trim().length >= 5) {
                  // Preparar dados para submissão
                  const dadosSubmit = {
                    origem: origemAtualizada,
                    paradas: validParadas,
                    otimizar: otimizarRota,
                    dataInicioEntrega: dataInicioEntrega,
                    dataFimEntrega: dataFimEntrega,
                    tipoVeiculo
                  };
                  
                  console.log("Submetendo rota com paradas:", dadosSubmit);
                  
                  // Submeter o formulário com os dados corretos
                  onSubmit(dadosSubmit);
                } else {
                  console.error("Origem inválida para cálculo automático:", origemAtualizada);
                  alert('Não foi possível calcular a rota automaticamente. Verifique se o endereço de origem está preenchido corretamente.');
                }
              }, 1000);
            }, 500);
          }, 200);
        } else {
          // Se não tem CEPs, apenas fazer o preview
          setTimeout(() => attemptPreviewRoute(), 500);
        }
      }
    };
    
    reader.readAsText(file);
  };

  const removeParada = (index: number) => {
    const newParadas = [...paradas];
    newParadas.splice(index, 1);
    setParadas(newParadas);
    form.setValue('paradas', newParadas);
    
    // Tentar recalcular a rota depois de remover uma parada
    setTimeout(() => attemptPreviewRoute(), 300);
  };

  // Armazenar timeout de busca para poder cancelar buscas anteriores
  const searchTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  
  const updateParada = (index: number, value: string) => {
    const newParadas = [...paradas];
    newParadas[index] = value;
    setParadas(newParadas);
    form.setValue('paradas', newParadas);
    
    // Marcar o campo que está sendo pesquisado
    setCampoPesquisando(`parada-${index}`);
    
    // Cancelar busca anterior para evitar resultados desatualizados
    if (searchTimeoutRef.current) {
      clearTimeout(searchTimeoutRef.current);
      searchTimeoutRef.current = null;
    }
    
    // Buscar sugestões de endereços
    if (value.length >= 2) {
      // Verificar se é um CEP para responder mais rapidamente
      const isCep = isCepFormat(value) || value.replace(/\D/g, '').length === 8;
      
      // Definir delay menor para CEPs e maior para outros tipos de busca
      const searchDelay = isCep ? 50 : 200;
      
      // Função para buscar sugestões com pequeno delay para evitar muitas requisições
      const delayedSearch = async () => {
        try {
          // Gerar um ID único para esta busca
          const searchId = Date.now();
          searchCurrentRequestId.current = searchId;
          
          const addressSuggestions = await buscarEnderecos(value);
          
          // Verificar se esta ainda é a busca mais recente
          if (searchCurrentRequestId.current !== searchId) {
            console.log('Busca cancelada, há uma busca mais recente em andamento');
            return;
          }
          
          // Atualizar o estado das sugestões apenas se ainda estivermos pesquisando esse campo
          if (campoPesquisando === `parada-${index}`) {
            const newSugestoes = [...sugestoes];
            newSugestoes[index] = addressSuggestions;
            setSugestoes(newSugestoes);
          }
        } catch (error) {
          console.error("Erro ao buscar sugestões para parada:", error);
        }
      };
      
      // Executar a busca com o delay apropriado
      searchTimeoutRef.current = setTimeout(delayedSearch, searchDelay);
      
      // Também mostrar um carregando para melhorar a experiência do usuário
      const loadingSuggestion: AddressSuggestion = {
        displayName: "Buscando endereços...",
        value: "",
        isCity: false,
        secondaryText: "Aguarde um momento"
      };
      
      // Atualizar imediatamente com indicação de carregamento
      const newSugestoes = [...sugestoes];
      newSugestoes[index] = [loadingSuggestion];
      setSugestoes(newSugestoes);
    } else {
      // Limpar sugestões se o valor for muito curto
      const newSugestoes = [...sugestoes];
      newSugestoes[index] = [];
      setSugestoes(newSugestoes);
    }
    
    // Removido o cálculo automático durante a digitação para evitar
    // que a rota seja calculada antes da seleção explícita do endereço
  };
  
  // Função para selecionar uma sugestão de parada
  const selecionarSugestao = (index: number, sugestao: AddressSuggestion) => {
    // Formatar CEP se estiver presente no valor
    const formatarValorSugestao = (valor: string) => {
      // Verificar se contém um CEP e formatá-lo
      const cepRegex = /\b(\d{5})[-.\s]?(\d{3})\b/;
      const cepMatch = valor.match(cepRegex);
      
      if (cepMatch) {
        // Formatar CEP para o formato padrão com hífen
        const cepFormatado = `${cepMatch[1]}-${cepMatch[2]}`;
        // Substituir o CEP não formatado pelo formatado
        return valor.replace(cepRegex, cepFormatado);
      }
      
      return valor;
    };
    
    const valorFormatado = formatarValorSugestao(sugestao.value);
    console.log(`Selecionando parada ${index}: "${valorFormatado}"`);
    
    const newParadas = [...paradas];
    newParadas[index] = valorFormatado;
    setParadas(newParadas);
    form.setValue('paradas', newParadas);
    
    // Limpar as sugestões e o campo pesquisando
    const newSugestoes = [...sugestoes];
    newSugestoes[index] = [];
    setSugestoes(newSugestoes);
    setCampoPesquisando(null);
    
    // Tentar preview da rota após selecionar a sugestão com delay maior
    // para garantir que o estado foi atualizado
    setTimeout(() => attemptPreviewRoute(), 500);
  };
  
  // Função para verificar se podemos fazer um preview da rota
  const attemptPreviewRoute = () => {
    // Somente tentar calcular preview se a função callback foi fornecida
    if (!onPreviewRoute) return;
    
    const origem = form.getValues('origem');
    const dataInicioEntrega = form.getValues('dataInicioEntrega');
    const dataFimEntrega = form.getValues('dataFimEntrega');
    
    // Filtrar paradas vazias
    const validParadas = paradas.filter(p => p.trim().length > 0);
    
    // Verificar se temos origem e pelo menos uma parada
    if (origem && validParadas.length > 0) {
      // Verificar se a origem tem pelo menos 5 caracteres
      if (origem.length < 5) {
        console.log("Origem muito curta para preview:", origem);
        return;
      }
      
      // Verificar se cada parada tem pelo menos 5 caracteres
      for (const parada of validParadas) {
        if (parada.length < 5) {
          console.log("Parada muito curta para preview:", parada);
          return;
        }
      }
      
      // Verificar se origem ou paradas são válidas para cálculo (texto longo o suficiente)
      const verificarEnderecoValido = (texto: string) => {
        // Verificar se temos um endereço completo (mais de 5 caracteres)
        if (texto.length < 5) {
          console.log("Endereço muito curto para preview:", texto);
          return false;
        }
        
        // Se for endereço no formato de cidade brasileira com UF (ex: São Paulo-SP)
        // ou um endereço comum com vírgula (ex: Rua dos Exemplos, 123), é válido
        if (texto.includes("-") || texto.includes(",")) {
          return true;
        }
        
        // Se não tem separadores, mas é longo o suficiente, permitir também
        if (texto.length > 10) {
          return true;
        }
        
        console.log("Endereço sem formato válido para preview:", texto);
        return false;
      };
      
      // Se a origem não for um endereço válido, não fazer preview
      if (!verificarEnderecoValido(origem)) {
        return;
      }
      
      // Se alguma parada não for um endereço válido, não fazer preview
      for (const parada of validParadas) {
        if (!verificarEnderecoValido(parada)) {
          return;
        }
      }
      
      // Validar CEP que esteja no formato correto
      const validarCEP = (texto: string) => {
        const cepRegex = /\d{5}[-.\s]?\d{3}/;
        if (cepRegex.test(texto)) {
          // Formatar CEP para formato padrão se não estiver
          if (!texto.includes("-")) {
            return texto.replace(/(\d{5})(\d{3})/, "$1-$2");
          }
        }
        return texto;
      };
      
      // Validar e formatar os endereços
      const origemFormatada = validarCEP(origem);
      const paradasFormatadas = validParadas.map(p => validarCEP(p));
      
      // Garantir que estamos usando o valor de referência da otimização 
      // Este valor é mantido consistente através da ref quando o switch muda
      const otimizarValor = valorOtimizacaoRef.current;
      
      // Atualizar formulário explicitamente (garantir consistência)
      form.setValue("otimizar", otimizarValor);
      
      console.log("Calculando preview com:", origemFormatada, paradasFormatadas);
      console.log("Valor de otimização usando REF:", otimizarValor);
      console.log("Valor de otimização no form:", form.getValues('otimizar'));
      console.log("Estado local de otimização:", otimizarRota);
      
      // Chamar o callback com os dados atuais do formulário, mas FORÇANDO o valor da referência
      onPreviewRoute({
        origem: origemFormatada,
        paradas: paradasFormatadas,
        otimizar: otimizarValor, // Forçar o valor da referência
        dataInicioEntrega: dataInicioEntrega || undefined,
        dataFimEntrega: dataFimEntrega || undefined,
        tipoVeiculo: form.getValues('tipoVeiculo') || 'caminhao_2_eixos'
      });
    }
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
        <h2 className="text-xl font-semibold flex items-center">
          <Truck className="mr-2 h-5 w-5" /> Calculadora de Rotas
        </h2>
        
        {/* Campos de data de entrega */}
        <div className="grid grid-cols-2 gap-2">
          <FormField
            control={form.control}
            name="dataInicioEntrega"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="flex items-center">
                  <CalendarRange className="mr-1 h-4 w-4 text-blue-500" />
                  Data Início
                </FormLabel>
                <FormControl>
                  <Popover open={dataInicioAberta} onOpenChange={setDataInicioAberta}>
                    <PopoverTrigger asChild>
                      <div className="relative">
                        <Input 
                          type="text" 
                          placeholder="DD/MM" 
                          maxLength={5} 
                          {...field} 
                          className="pr-10" 
                          onClick={() => setDataInicioAberta(true)}
                        />
                        <CalendarDays 
                          className="absolute right-3 top-2.5 h-5 w-5 text-gray-400 cursor-pointer"
                          onClick={() => setDataInicioAberta(true)}
                        />
                      </div>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0 z-[9999]" align="start">
                      <Calendar
                        mode="single"
                        locale={ptBR}
                        selected={converterParaDate(field.value) || undefined}
                        onSelect={handleDataInicioSelecionada}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="dataFimEntrega"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="flex items-center">
                  <CalendarRange className="mr-1 h-4 w-4 text-blue-500" />
                  Data Final
                </FormLabel>
                <FormControl>
                  <Popover open={dataFimAberta} onOpenChange={setDataFimAberta}>
                    <PopoverTrigger asChild>
                      <div className="relative">
                        <Input 
                          type="text" 
                          placeholder="DD/MM" 
                          maxLength={5} 
                          {...field} 
                          className="pr-10" 
                          onClick={() => setDataFimAberta(true)}
                        />
                        <CalendarDays 
                          className="absolute right-3 top-2.5 h-5 w-5 text-gray-400 cursor-pointer"
                          onClick={() => setDataFimAberta(true)}
                        />
                      </div>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0 z-[9999]" align="start">
                      <Calendar
                        mode="single"
                        locale={ptBR}
                        selected={converterParaDate(field.value) || undefined}
                        onSelect={handleDataFimSelecionada}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>
        
        <FormField
          control={form.control}
          name="nome"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Nome da Rota (opcional)</FormLabel>
              <FormControl>
                <Input placeholder="Ex: Entrega Semanal" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <FormField
          control={form.control}
          name="origem"
          render={({ field }) => (
            <FormItem>
              <FormLabel className="flex items-center">
                <MapPin className="mr-1 h-4 w-4 text-green-600" /> Origem
              </FormLabel>
              <FormControl>
                <div className="relative">
                  <div className="flex items-center gap-2">
                    <div className="relative flex-1">
                      <Input 
                        {...field}
                        placeholder={isLocalizando ? "Obtendo localização atual..." : "Digite o endereço de origem"} 
                        className="autocomplete-input"
                        ref={origemRef}
                        onChange={async (e) => {
                          field.onChange(e);
                          
                          // Marcar que estamos pesquisando a origem
                          setCampoPesquisando('origem');
                          
                          // Buscar sugestões de endereços para a origem
                          const value = e.target.value;
                          if (value.length >= 2) {
                            // Verificar se parece um CEP completo para resposta imediata
                            const possibleCep = value.replace(/\D/g, '');
                            if (possibleCep.length === 8) {
                              const cepInfo = await buscarCep(possibleCep);
                              if (cepInfo) {
                                // CEP encontrado no banco - resposta imediata
                                const formattedCep = formatarCep(possibleCep);
                                const suggestion: AddressSuggestion = {
                                  displayName: cepInfo.logradouro,
                                  value: `${cepInfo.logradouro}, ${cepInfo.bairro} - ${cepInfo.cidade}-${cepInfo.estado}`,
                                  isCity: false,
                                  secondaryText: `${cepInfo.bairro}, ${cepInfo.cidade}-${cepInfo.estado} (CEP ${formattedCep})`
                                };
                                setOrigemSugestoes([suggestion]);
                                console.log("CEP respondido localmente:", possibleCep);
                                return; // Não precisamos consultar a API
                              }
                            }
                            
                            // Função para buscar sugestões com delay para evitar requisições excessivas
                            const delayedSearch = async () => {
                              try {
                                const addressSuggestions = await buscarEnderecos(value);
                                
                                // Atualizar o estado das sugestões apenas se ainda estivermos pesquisando a origem
                                if (campoPesquisando === 'origem') {
                                  setOrigemSugestoes(addressSuggestions);
                                }
                              } catch (error) {
                                console.error("Erro ao buscar sugestões para origem:", error);
                              }
                            };
                            
                            // Executar a busca com delay reduzido para melhor responsividade
                            setTimeout(delayedSearch, 150);
                            
                            // Mostrar indicação de carregamento imediatamente
                            const loadingSuggestion: AddressSuggestion = {
                              displayName: "Buscando endereços...",
                              value: "",
                              isCity: false,
                              secondaryText: "Aguarde um momento"
                            };
                            setOrigemSugestoes([loadingSuggestion]);
                          } else {
                            // Para entradas curtas, mostrar apenas cidades prioritárias
                            const citySuggestions = filterCitySuggestions(value);
                            const cityResults = citySuggestions.map(city => ({ 
                              displayName: city, 
                              value: city,
                              isCity: true,
                              secondaryText: "Brasil" // Indicar que é uma cidade brasileira
                            }));
                            setOrigemSugestoes(cityResults);
                          }
                          
                          // Tentar calcular a rota automaticamente se tiver mais de 3 caracteres
                          if (e.target.value.length > 3) {
                            // Delay reduzido para melhor resposta
                            setTimeout(() => attemptPreviewRoute(), 800);
                          }
                        }}
                        onFocus={(e) => {
                          // Mostrar sugestões iniciais mesmo sem digitar
                          const citySuggestions = filterCitySuggestions("");
                          const cityResults = citySuggestions.map(city => ({ 
                            displayName: city, 
                            value: city,
                            isCity: true,
                            secondaryText: "Brasil" // Indicar que é uma cidade brasileira
                          }));
                          setOrigemSugestoes(cityResults);
                          setCampoPesquisando('origem');
                        }}
                        onBlur={() => {
                          // Esconder sugestões ao perder foco, com delay para permitir clique
                          setTimeout(() => {
                            setCampoPesquisando(null);
                          }, 200);
                        }}
                        disabled={isLocalizando}
                      />
                    </div>
                    <Button
                      type="button"
                      variant="outline"
                      size="icon"
                      onClick={usarLocalizacaoAtual}
                      disabled={isLocalizando}
                      title="Usar minha localização atual"
                      className="min-w-8 h-8"
                    >
                      {isLocalizando ? (
                        <div className="h-4 w-4 animate-spin rounded-full border-2 border-primary border-t-transparent" />
                      ) : (
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                          <circle cx="12" cy="12" r="4" />
                          <path d="M12 2v2" />
                          <path d="M12 20v2" />
                          <path d="M4.93 4.93l1.41 1.41" />
                          <path d="M17.66 17.66l1.41 1.41" />
                          <path d="M2 12h2" />
                          <path d="M20 12h2" />
                          <path d="M6.34 17.66l-1.41 1.41" />
                          <path d="M19.07 4.93l-1.41 1.41" />
                        </svg>
                      )}
                    </Button>
                  </div>
                  
                  {/* Lista de sugestões de origem */}
                  {campoPesquisando === 'origem' && (
                    <div className="absolute z-50 mt-1 w-full max-h-60 overflow-auto rounded-md bg-white py-1 shadow-lg border border-gray-200 text-sm">
                      {origemSugestoes.length === 0 ? (
                        <div className="px-3 py-2 text-gray-500 text-center">Nenhuma sugestão encontrada</div>
                      ) : origemSugestoes.map((sugestao, idx) => (
                        <div
                          key={idx}
                          className="px-3 py-2 flex flex-col hover:bg-blue-50 cursor-pointer gap-0.5"
                          onClick={() => {
                            // Formatar CEP se estiver presente no valor
                            const formatarValorSugestao = (valor: string) => {
                              // Verificar se contém um CEP e formatá-lo
                              const cepRegex = /\b(\d{5})[-.\s]?(\d{3})\b/;
                              const cepMatch = valor.match(cepRegex);
                              
                              if (cepMatch) {
                                // Formatar CEP para o formato padrão com hífen
                                const cepFormatado = `${cepMatch[1]}-${cepMatch[2]}`;
                                // Substituir o CEP não formatado pelo formatado
                                return valor.replace(cepRegex, cepFormatado);
                              }
                              
                              return valor;
                            };
                            
                            const valorFormatado = formatarValorSugestao(sugestao.value);
                            console.log(`Selecionando origem: "${valorFormatado}"`);
                            
                            form.setValue('origem', valorFormatado);
                            setOrigemSugestoes([]);
                            setCampoPesquisando(null);
                            // Tentar preview da rota após selecionar a sugestão com delay maior
                            setTimeout(() => attemptPreviewRoute(), 500);
                          }}
                        >
                          <div className="flex items-center">
                            {sugestao.isCity ? (
                              <Flag className="mr-2 h-4 w-4 text-amber-500 flex-shrink-0" />
                            ) : (
                              <MapPin className="mr-2 h-4 w-4 text-green-600 flex-shrink-0" />
                            )}
                            <span className="font-medium">{sugestao.displayName || sugestao.value}</span>
                          </div>
                          
                          {/* Texto secundário para contexto/detalhes */}
                          {sugestao.secondaryText && (
                            <div className="pl-6 text-xs text-gray-500">
                              {sugestao.secondaryText}
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        {paradas.length > 0 && (
          <div className="space-y-3">
            <div className="flex items-center">
              <Flag className="mr-1 h-4 w-4 text-amber-500" />
              <p className="text-sm font-medium">Paradas</p>
            </div>
            
            {paradas.map((parada, index) => {
              // Formatar o CEP para garantir correspondência consistente
              const cepRegex = /\b(\d{5})[-.\s]?(\d{3})\b/;
              const cepMatch = parada.match(cepRegex);
              
              // Se contiver um CEP, usamos o formato padronizado como chave
              let chaveBusca = parada;
              if (cepMatch) {
                chaveBusca = `${cepMatch[1]}-${cepMatch[2]}`;
              }
              
              // Verificar se temos um nome personalizado para esta parada usando a chave formatada
              const temNomePersonalizado = customNames[chaveBusca] !== undefined;
              const nomeExibicao = temNomePersonalizado ? customNames[chaveBusca] : undefined;
              
              // Debug: exibir no console para cada parada com informações detalhadas
              console.log(`Parada ${index}: "${parada}" (chave: "${chaveBusca}") - Tem nome personalizado: ${temNomePersonalizado}`, 
                temNomePersonalizado ? `Nome: "${nomeExibicao}"` : '');
              
              return (
                <div key={index} className="relative">
                  <div className="flex items-center gap-2">
                    <div className="relative flex-1">
                      <Input
                        value={parada}
                        onChange={(e) => updateParada(index, e.target.value)}
                        placeholder={`Parada ${index + 1} - Digite o endereço ou cidade`}
                        className="autocomplete-input"
                        ref={(el) => {
                          paradaRefs.current[index] = el;
                        }}
                        onFocus={(e) => {
                          // Mostrar sugestões iniciais mesmo sem digitar
                          const citySuggestions = filterCitySuggestions("");
                          const cityResults = citySuggestions.map(city => ({ 
                            displayName: city, 
                            value: city,
                            isCity: true,
                            secondaryText: "Brasil" // Indicar que é uma cidade brasileira
                          }));
                          const newSugestoes = [...sugestoes];
                          newSugestoes[index] = cityResults;
                          setSugestoes(newSugestoes);
                          setCampoPesquisando(`parada-${index}`);
                        }}
                        onBlur={() => {
                          // Esconder sugestões ao perder foco, com delay para permitir clique na sugestão
                          setTimeout(() => setCampoPesquisando(null), 200);
                        }}
                      />
                      
                      {/* Mostrar nome personalizado embaixo do input */}
                      {temNomePersonalizado && (
                        <div className="absolute -bottom-6 left-2 text-xs bg-amber-100 px-2 py-0.5 rounded-md border border-amber-200 text-amber-700 font-medium shadow-sm z-10">
                          {nomeExibicao}
                        </div>
                      )}
                    </div>
                    
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      onClick={() => removeParada(index)}
                    >
                      <Trash2 className="h-4 w-4 text-red-500" />
                    </Button>
                  </div>
                  
                  {/* Lista de sugestões */}
                  {campoPesquisando === `parada-${index}` && (
                    <div className="absolute z-50 mt-1 w-full max-h-60 overflow-auto rounded-md bg-white py-1 shadow-lg border border-gray-200 text-sm">
                      {!sugestoes[index] || sugestoes[index].length === 0 ? (
                        <div className="px-3 py-2 text-gray-500 text-center">Nenhuma sugestão encontrada</div>
                      ) : sugestoes[index].map((sugestao, idx) => (
                        <div
                          key={idx}
                          className={cn(
                            "px-3 py-2 flex flex-col hover:bg-blue-50 cursor-pointer",
                            "text-sm gap-0.5"
                          )}
                          onClick={() => selecionarSugestao(index, sugestao)}
                        >
                          <div className="flex items-center">
                            {sugestao.isCity ? (
                              <Flag className="mr-2 h-4 w-4 text-amber-500 flex-shrink-0" />
                            ) : (
                              <MapPin className="mr-2 h-4 w-4 text-blue-600 flex-shrink-0" />
                            )}
                            <span className="font-medium">{sugestao.displayName || sugestao.value}</span>
                          </div>
                          
                          {/* Texto secundário para contexto/detalhes */}
                          {sugestao.secondaryText && (
                            <div className="pl-6 text-xs text-gray-500">
                              {sugestao.secondaryText}
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}

        <div className="space-y-3 mb-4">
          <div className="flex flex-col space-y-3">
            <Button
              type="button"
              variant="outline"
              size="default"
              onClick={addParada}
              className="h-10 rounded-md border border-slate-200 shadow-sm hover:bg-slate-50 w-full"
            >
              <Plus className="mr-2 h-4 w-4 text-slate-500" /> 
              <span className="text-slate-700">Adicionar Parada</span>
            </Button>
            
            {/* Botão para importar paradas de arquivo */}
            <div className="relative">
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    type="button"
                    variant="outline"
                    size="default"
                    className="h-10 rounded-md border border-slate-200 shadow-sm hover:bg-slate-50 w-full"
                    onClick={() => document.getElementById('importar-paradas')?.click()}
                  >
                    <svg 
                      xmlns="http://www.w3.org/2000/svg" 
                      width="16" 
                      height="16" 
                      viewBox="0 0 24 24" 
                      fill="none" 
                      stroke="currentColor" 
                      strokeWidth="2" 
                      strokeLinecap="round" 
                      strokeLinejoin="round" 
                      className="mr-2 text-slate-500"
                    >
                      <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                      <polyline points="7 10 12 15 17 10"></polyline>
                      <line x1="12" y1="15" x2="12" y2="3"></line>
                    </svg>
                    <span className="text-slate-700">Importar Paradas</span>
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-80">
                  <div className="space-y-2">
                    <h4 className="font-medium">Importar CEPs por arquivo</h4>
                    <p className="text-sm text-muted-foreground">
                      Selecione um arquivo de texto com uma parada por linha. Pode ser um CEP (14091530) ou endereço completo.
                    </p>
                    <p className="text-xs text-muted-foreground">
                      <strong>Novo formato:</strong> Também suporta "CEP,NOME" para adicionar nomes personalizados às paradas.
                    </p>
                    <p className="text-xs text-muted-foreground italic">
                      Exemplos:
                      <br />
                      14091-530
                      <br />
                      17302-122,Vila Coradi
                      <br />
                      14430-000,Sede da Empresa
                      <br />
                      Rua Botafogo 135, Vila Coradi - Dois Córregos-SP
                    </p>
                  </div>
                </PopoverContent>
              </Popover>
              <input
                id="importar-paradas"
                type="file"
                accept=".txt,.csv"
                className="hidden"
                onChange={importarParadasDeArquivo}
              />
            </div>
          </div>
        </div>

        {/* Configuração de otimização de rota */}
        {paradas.length > 1 && (
          <FormField
            control={form.control}
            name="otimizar"
            render={({ field }) => (
              <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3 shadow-sm">
                <div className="space-y-0.5">
                  <FormLabel className="flex items-center">
                    <ArrowDownUp className="mr-2 h-4 w-4 text-blue-600" />
                    Otimizar ordem das paradas
                  </FormLabel>
                  <FormDescription className="text-xs">
                    Reorganizar automaticamente as paradas para percorrer o caminho mais curto
                  </FormDescription>
                </div>
                <FormControl>
                  <div className="flex items-center">
                    <Switch
                      checked={field.value}
                      onCheckedChange={(checked) => {
                        // Usar um valor booleano primitivo, não um objeto
                        const boolValue = !!checked;
                        
                        // Atualizar estado local
                        setOtimizarRota(boolValue);
                        
                        // CRUCIAL: Atualizar a referência que controla o valor real usado
                        valorOtimizacaoRef.current = boolValue;
                        
                        // Atualizar formulário explicitamente com o valor booleano
                        field.onChange(boolValue);
                        form.setValue("otimizar", boolValue);
                        
                        // Log detalhado para depuração
                        console.log("Alterado valor de otimização para:", boolValue);
                        console.log("Atualizada referência valorOtimizacaoRef para:", valorOtimizacaoRef.current);
                        console.log("Tipo do valor após mudança:", typeof boolValue);
                        console.log("Valores atuais do formulário:", form.getValues());
                        
                        // Tentar recalcular a rota quando a opção mudar
                        setTimeout(() => {
                          // Verificar estado do formulário antes do envio
                          const formValues = form.getValues();
                          
                          // Forçar atualização do valor no formulário antes de enviar
                          formValues.otimizar = valorOtimizacaoRef.current;
                          form.setValue("otimizar", valorOtimizacaoRef.current);
                          
                          console.log("Recalculando rota com otimização ref:", valorOtimizacaoRef.current);
                          console.log("Valor final no formulário:", form.getValues().otimizar);
                          
                          // Chamar a função de preview com valores atualizados
                          if (typeof attemptPreviewRoute === 'function') {
                            console.log("Chamando attemptPreviewRoute com otimização =", valorOtimizacaoRef.current);
                            attemptPreviewRoute();
                          }
                        }, 300);
                      }}
                    />
                  </div>
                </FormControl>
              </FormItem>
            )}
          />
        )}

        {/* Seletor de tipo de veículo para cálculo de pedágio */}
        <FormField
          control={form.control}
          name="tipoVeiculo"
          render={({ field }) => (
            <FormItem className="flex flex-col">
              <FormLabel className="flex items-center">
                <Truck className="mr-2 h-4 w-4 text-blue-600" />
                Tipo de Veículo para Cálculo de Pedágio
              </FormLabel>
              <FormDescription className="text-xs">
                Selecione o tipo de veículo para calcular o valor correto dos pedágios
              </FormDescription>
              <Select 
                onValueChange={(value) => {
                  field.onChange(value);
                  setTimeout(() => attemptPreviewRoute(), 300);
                }}
                defaultValue={field.value}
              >
                <FormControl>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione o tipo de veículo" />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  <SelectItem value="carro">
                    <div className="flex items-center">
                      <Car className="mr-2 h-4 w-4" />
                      <span>Carro de Passeio</span>
                    </div>
                  </SelectItem>
                  <SelectItem value="moto">
                    <div className="flex items-center">
                      <Bike className="mr-2 h-4 w-4" />
                      <span>Motocicleta</span>
                    </div>
                  </SelectItem>
                  <SelectItem value="caminhao">
                    <div className="flex items-center">
                      <Truck className="mr-2 h-4 w-4" />
                      <span>Caminhão (genérico)</span>
                    </div>
                  </SelectItem>
                  <SelectItem value="caminhao_2_eixos">
                    <div className="flex items-center">
                      <Truck className="mr-2 h-4 w-4" />
                      <span>Caminhão 2 eixos</span>
                    </div>
                  </SelectItem>
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )}
        />

        <Separator />

        <div className="flex flex-col space-y-2">
          <Button 
            type="button" 
            variant="outline"
            className="w-full"
            onClick={attemptPreviewRoute}
            disabled={isLoading}
          >
            <EyeIcon className="mr-1 h-4 w-4" /> Pré-visualizar Rota
          </Button>
          
          <Button 
            type="submit" 
            className="w-full transportadora-primary"
            disabled={isLoading}
          >
            {isLoading ? "Calculando..." : "Calcular Rota Completa"}
          </Button>
        </div>
      </form>
    </Form>
  );
}
