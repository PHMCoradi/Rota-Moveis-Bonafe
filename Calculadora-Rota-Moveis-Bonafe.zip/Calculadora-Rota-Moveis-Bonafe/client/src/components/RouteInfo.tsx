import { CalendarClock, CalendarRange, Map, Route, Navigation, MapPin, Flag, AlertCircle, Banknote, Cake, PartyPopper } from "lucide-react";
import { RouteResponse } from "@shared/schema";
import { brazilianConfig, formatBR } from "@/lib/locale";
import { findHolidaysInRange, formatHolidayList, formatDetailedHolidayList } from "@/lib/holidays";
import { ShareRouteButton } from "./ShareRouteButton";
import { CityAnniversaryButton } from "./CityAnniversaryButton";
import { CityAnniversaryPopup } from "./CityAnniversaryPopup";
import { useState } from "react";

// Função utilitária para formatar o tipo de veículo para exibição
const formatarTipoVeiculo = (tipo: string): string => {
  switch(tipo) {
    case 'carro':
      return 'Carro de passeio';
    case 'moto':
      return 'Motocicleta';
    case 'caminhao':
      return 'Caminhão';
    case 'caminhao_2_eixos':
      return 'Caminhão 2 eixos';
    default:
      return tipo.replace('_', ' ');
  }
};

// Função para extrair CEP de um endereço
function extractCepFromAddress(address: string): string | null {
  const cepRegex = /\b(\d{5})[-.\s]?(\d{3})\b/;
  const match = address.match(cepRegex);
  if (match) {
    return `${match[1]}-${match[2]}`;
  }
  return null;
}

// Função para buscar nome personalizado de uma parada
function getNomePersonalizado(endereco: string): string | null {
  try {
    const cep = extractCepFromAddress(endereco);
    if (!cep) return null;
    
    const nomes = JSON.parse(localStorage.getItem('paradaNomes') || '{}');
    return nomes[cep] || null;
  } catch (error) {
    console.error('Erro ao buscar nome personalizado:', error);
    return null;
  }
}

// Função utilitária para extrair apenas o nome da cidade de um endereço completo
const extrairCidade = (endereco?: string | any): string => {
  // Se o endereço não foi fornecido ou não é uma string, retorna uma string vazia
  if (!endereco) return '';
  
  // Garantir que estamos trabalhando com uma string
  const enderecoStr = typeof endereco === 'string' ? endereco : 
                      endereco.toString ? endereco.toString() : 
                      JSON.stringify(endereco);
  
  // Verificar se o endereço já está no formato "Cidade-UF" (como "Dois Córregos-SP")
  if (enderecoStr.includes('-') && enderecoStr.split('-').length === 2) {
    return enderecoStr;
  }
  
  // Tenta extrair no formato "Cidade-UF" ou "Cidade, UF"
  const cidadeComEstado = enderecoStr.match(/([A-Za-zÀ-ÖØ-öø-ÿ\s]+)[-,]\s*([A-Z]{2})/);
  if (cidadeComEstado && cidadeComEstado[1] && cidadeComEstado[2]) {
    return cidadeComEstado[1].trim() + "-" + cidadeComEstado[2].trim();
  }
  
  // Tenta extrair somente a cidade
  const cidade = enderecoStr.split(",")[0];
  if (cidade) {
    return cidade.trim();
  }
  
  // Se não conseguir extrair, retorna o endereço original como string
  return enderecoStr;
};

interface RouteInfoProps {
  routeResult: RouteResponse;
}

export function RouteInfo({ routeResult }: RouteInfoProps) {
  const { distanciaTotal, tempoTotal, origem, destino, paradas, dataInicioEntrega: dataInicio, dataFimEntrega: dataFim, valorPedagios, tipoVeiculo } = routeResult;
  const [showCityAnniversaryPopup, setShowCityAnniversaryPopup] = useState(false);
  
  // Estado para controlar as informações do aniversário da cidade
  const [currentCity, setCurrentCity] = useState<string>('');
  const [anniversaryDate, setAnniversaryDate] = useState<string>('');
  
  // Cidades para verificar feriados (origem e todas as paradas)
  const cidadesParaVerificar = [origem].concat(
    routeResult.optimized && routeResult.optimizedWaypointsOrder 
    ? routeResult.optimizedWaypointsOrder 
    : paradas || []
  ).filter(Boolean).map(cidade => extrairCidade(cidade));
  
  // Verificar feriados nas cidades da rota
  const feriados = dataInicio && dataFim 
    ? findHolidaysInRange(dataInicio, dataFim, cidadesParaVerificar)
    : [];
    
  // Filtrar apenas aniversários
  const aniversarios = feriados.filter(feriado => feriado.type === 'aniversario');
  
  // Verificação manual para Ribeirão Preto (para garantir)
  const hasRibeiraoPreto = cidadesParaVerificar.some(cidade => 
    cidade.toLowerCase().includes('ribeirao') || cidade.toLowerCase().includes('ribeirão')
  );
  
  console.log(`Cidades na rota para verificar: ${JSON.stringify(cidadesParaVerificar)}`);
  console.log(`Rota passa por Ribeirão Preto: ${hasRibeiraoPreto}`);
  
  // Se a rota passa por Ribeirão Preto e o período inclui 19/06, adicionar manualmente
  if (dataInicio && dataFim) {
    // Converter datas para objetos Date para facilitar a comparação
    const [diaInicio, mesInicio] = dataInicio.split('/').map(Number);
    const [diaFim, mesFim] = dataFim.split('/').map(Number);
    
    // Data do aniversário de Ribeirão Preto (19 de junho)
    const anivDia = 19;
    const anivMes = 6; // junho é o mês 6
    
    // Verificar se o período inclui o dia 19/06
    // Comparação simples - se o mês inicial é anterior ou igual a junho e o mês final é posterior ou igual a junho
    const periodoIncluiJunho = (mesInicio <= anivMes && mesFim >= anivMes);
    
    // Se inclui junho, verificar se inclui o dia 19
    let incluiAniversarioRibeirao = false;
    if (periodoIncluiJunho) {
      // Se o mês inicial é junho, verificar se o dia inicial é antes ou igual a 19
      // Se o mês final é junho, verificar se o dia final é depois ou igual a 19
      if (mesInicio < anivMes || (mesInicio === anivMes && diaInicio <= anivDia)) {
        if (mesFim > anivMes || (mesFim === anivMes && diaFim >= anivDia)) {
          incluiAniversarioRibeirao = true;
        }
      }
    }
    
    console.log(`Período de entrega: ${dataInicio} a ${dataFim}`);
    console.log(`Período inclui aniversário de Ribeirão Preto (19/06): ${incluiAniversarioRibeirao}`);
    
    // Adicionar o aniversário de Ribeirão Preto se o período incluir 19/06, independente se a rota passa pela cidade
    if (incluiAniversarioRibeirao) {
      // Verificar se já não foi adicionado
      if (!aniversarios.some(a => a.date === '19/06' && 
          (a.location?.toLowerCase().includes('ribeirao') || a.location?.toLowerCase().includes('ribeirão')))) {
        
        // Adicionar manualmente o aniversário à lista
        aniversarios.push({
          date: '19/06',
          name: 'Aniversário da Cidade',
          type: 'aniversario',
          location: 'Ribeirão Preto-SP',
          description: 'Comemoração do aniversário de fundação de Ribeirão Preto'
        });
        
        console.log('Aniversário de Ribeirão Preto adicionado manualmente à lista');
      }
    }
    
    // Se a rota passa por Ribeirão Preto, adicionar uma flag para mostrar o botão mesmo que não seja no período
    if (hasRibeiraoPreto && !incluiAniversarioRibeirao) {
      console.log('Rota passa por Ribeirão Preto, mas fora do período de aniversário');
      // Adicionar aniversário à lista para futura referência, mesmo que o período não inclua
      if (!aniversarios.some(a => a.location?.toLowerCase().includes('ribeirao') || a.location?.toLowerCase().includes('ribeirão'))) {
        aniversarios.push({
          date: '19/06',
          name: 'Aniversário da Cidade (Fora do período)',
          type: 'aniversario',
          location: 'Ribeirão Preto-SP',
          description: 'Comemoração do aniversário de fundação de Ribeirão Preto (fora do período)'
        });
      }
    }
  }
  
  // Mostrar aniversário da cidade - Preferência para a primeira cidade com aniversário
  const handleShowCityAnniversary = () => {
    if (cidadesParaVerificar.some(cidade => cidade.toLowerCase().includes('ribeirao') || cidade.toLowerCase().includes('ribeirão'))) {
      // Caso especial para Ribeirão Preto
      setCurrentCity('Ribeirão Preto');
      setAnniversaryDate('19/06');
      setShowCityAnniversaryPopup(true);
      return;
    }
    
    // Verificar se há aniversários para exibir
    if (aniversarios.length > 0) {
      const aniversario = aniversarios[0];
      const cidade = aniversario.location ? aniversario.location.split('-')[0] : '';
      setCurrentCity(cidade);
      setAnniversaryDate(aniversario.date);
      setShowCityAnniversaryPopup(true);
    } else {
      // Fallback para a cidade de destino se não houver aniversários
      const cidadeDestino = destino ? extrairCidade(destino) : 
                           (paradas && paradas.length > 0) ? extrairCidade(paradas[paradas.length - 1]) : '';
      
      setCurrentCity(cidadeDestino);
      setAnniversaryDate('');
      setShowCityAnniversaryPopup(true);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold flex items-center">
          <Route className="mr-2 h-5 w-5" /> Informações da Rota
        </h3>
        <ShareRouteButton routeResult={routeResult} />
      </div>

      <div className="space-y-2">
        <div className="flex items-center gap-2 text-sm">
          <Map className="h-4 w-4 text-gray-500" />
          <span className="font-medium">Distância Total:</span>
          <span className="text-gray-700">{distanciaTotal}</span>
        </div>

        <div className="flex items-center gap-2 text-sm">
          <CalendarClock className="h-4 w-4 text-gray-500" />
          <span className="font-medium">Tempo Estimado:</span>
          <span className="text-gray-700">{tempoTotal}</span>
        </div>
        
        {/* Exibir valor total de pedágios, se disponível */}
        {valorPedagios && (
          <div className="flex items-center gap-2 text-sm">
            <Banknote className="h-4 w-4 text-gray-500" />
            <span className="font-medium">Valor Total de Pedágios:</span>
            <span className="text-gray-700">
              {valorPedagios}
              {tipoVeiculo && (
                <span className="text-xs text-gray-500 ml-1">
                  ({formatarTipoVeiculo(tipoVeiculo)})
                </span>
              )}
            </span>
          </div>
        )}
        
        {/* Exibir data de início e fim se estiverem disponíveis */}
        {dataInicio && dataFim && (
          <div className="flex items-center gap-2 text-sm">
            <CalendarRange className="h-4 w-4 text-gray-500" />
            <span className="font-medium">Período de Entrega:</span>
            <span className="text-gray-700">{dataInicio} a {dataFim}</span>
          </div>
        )}
        
        {/* Mostrar feriados no período, se houver */}
        {feriados.length > 0 && (
          <div className="flex items-start gap-2 text-sm mt-1">
            <AlertCircle className="h-4 w-4 text-amber-500 mt-0.5 flex-shrink-0" />
            <div>
              <span className="font-medium">Atenção - Feriados no período:</span>
              <p className="text-amber-700 text-xs mt-0.5">
                {formatHolidayList(feriados)}
              </p>
            </div>
          </div>
        )}
        
        {/* Mostrar aniversários de cidades no período em destaque */}
        {aniversarios.length > 0 && (
          <div className="flex items-start gap-2 text-sm mt-1 bg-amber-50 p-2 rounded-md">
            <PartyPopper className="h-4 w-4 text-amber-600 mt-0.5 flex-shrink-0" />
            <div>
              <span className="font-medium text-amber-800">Aniversários de Cidades:</span>
              <p className="text-amber-700 text-xs mt-0.5">
                {formatDetailedHolidayList(aniversarios, 2).aniversarios}
              </p>
              <div className="mt-1">
                <CityAnniversaryButton onShowCityAnniversary={handleShowCityAnniversary} />
              </div>
            </div>
          </div>
        )}

        <div className="flex items-center gap-2 text-sm">
          <CalendarRange className="h-4 w-4 text-gray-500" />
          <span className="font-medium">Data de Geração:</span>
          <span className="text-gray-700">
            {new Date().toLocaleDateString('pt-BR', {
              day: '2-digit',
              month: '2-digit',
              year: 'numeric',
            })}
          </span>
        </div>
      </div>

      <div className="p-3 bg-gray-50 rounded-md text-sm space-y-3">
        <div>
          <div className="flex items-center font-medium">
            <MapPin className="mr-1 h-4 w-4 text-green-600" /> 
            Origem
          </div>
          <p className="text-gray-800 font-semibold mt-1">{extrairCidade(origem)}</p>
          <p className="text-gray-600 text-xs truncate">{origem}</p>
        </div>

        {paradas && paradas.length > 0 && (
          <div>
            <div className="flex items-center font-medium">
              <Flag className="mr-1 h-4 w-4 text-amber-500" /> 
              Paradas ({paradas.length})
              {routeResult.optimized && (
                <span className="ml-2 text-xs text-green-600 font-normal rounded-full bg-green-50 px-2 py-0.5">
                  ✓ Ordem otimizada
                </span>
              )}
            </div>
            <ul className="mt-1 space-y-2">
              {/* Se a rota foi otimizada e temos a ordem otimizada, usamos essa ordem para mostrar as paradas */}
              {(routeResult.optimized && routeResult.optimizedWaypointsOrder 
                ? routeResult.optimizedWaypointsOrder 
                : paradas).map((parada, index) => {
                  // Verificar se existe um nome personalizado para esta parada
                  const nomePersonalizado = getNomePersonalizado(parada);
                  
                  return (
                    <li key={index} className="border-l-2 border-amber-300 pl-3">
                      {nomePersonalizado ? (
                        <>
                          <div className="text-gray-800 font-semibold flex items-center">
                            <span className="bg-amber-100 text-amber-800 px-2 py-0.5 rounded border border-amber-300 text-sm shadow-sm">
                              {nomePersonalizado}
                            </span>
                          </div>
                          <div className="text-gray-700 text-xs mt-0.5">{extrairCidade(parada)}</div>
                          <div className="text-gray-500 text-xs truncate">{parada}</div>
                        </>
                      ) : (
                        <>
                          <div className="text-gray-800 font-semibold">{extrairCidade(parada)}</div>
                          <div className="text-gray-600 text-xs truncate">{parada}</div>
                        </>
                      )}
                    </li>
                  );
                })}
            </ul>
          </div>
        )}

        {/* Mostrar o destino somente se ele existir */}
        {destino && (
          <div>
            <div className="flex items-center font-medium">
              <Navigation className="mr-1 h-4 w-4 text-red-600" /> 
              Destino
            </div>
            <p className="text-gray-800 font-semibold mt-1">{extrairCidade(destino)}</p>
            <p className="text-gray-600 text-xs truncate">{destino}</p>
          </div>
        )}
        
        {/* Se não tiver destino, usar a última parada como destino visual */}
        {!destino && paradas && paradas.length > 0 && (
          <div>
            <div className="flex items-center font-medium">
              <Navigation className="mr-1 h-4 w-4 text-red-600" /> 
              Destino (última parada)
            </div>
            {/* Se a rota foi otimizada, usar a última parada da ordem otimizada */}
            {routeResult.optimized && routeResult.optimizedWaypointsOrder ? (
              <>
                <p className="text-gray-800 font-semibold mt-1">
                  {extrairCidade(routeResult.optimizedWaypointsOrder[routeResult.optimizedWaypointsOrder.length - 1])}
                </p>
                <p className="text-gray-600 text-xs truncate">
                  {routeResult.optimizedWaypointsOrder[routeResult.optimizedWaypointsOrder.length - 1]}
                </p>
              </>
            ) : (
              <>
                <p className="text-gray-800 font-semibold mt-1">{extrairCidade(paradas[paradas.length - 1])}</p>
                <p className="text-gray-600 text-xs truncate">{paradas[paradas.length - 1]}</p>
              </>
            )}
          </div>
        )}
        
        {/* Sequência da rota */}
        {paradas && paradas.length > 0 && (
          <div className="border-t border-gray-200 pt-2 mt-3">
            <p className="font-medium mb-1">
              Sequência da Rota:
              {routeResult.optimized && (
                <span className="text-xs text-green-600 ml-2 font-normal">
                  ✓ Otimizada para menor tempo
                </span>
              )}
            </p>
            {/* Se a rota foi otimizada, mostrar a sequência otimizada */}
            <p className="text-xs text-gray-700">
              {extrairCidade(origem)} {' → '}
              {(routeResult.optimized && routeResult.optimizedWaypointsOrder 
                ? routeResult.optimizedWaypointsOrder 
                : paradas).map(p => extrairCidade(p)).join(' → ')}
            </p>
            
            {/* Se a rota foi otimizada e temos a ordem original diferente da ordem otimizada, 
                mostramos a ordem original para comparação */}
            {routeResult.optimized && routeResult.originalWaypointsOrder && 
             routeResult.optimizedWaypointsOrder &&
             routeResult.originalWaypointsOrder.join() !== routeResult.optimizedWaypointsOrder.join() && (
              <div className="mt-2">
                <p className="text-xs text-gray-500">Ordem original das paradas:</p>
                <p className="text-xs text-gray-500">
                  {extrairCidade(origem)} {' → '}
                  {routeResult.originalWaypointsOrder.map(p => extrairCidade(p)).join(' → ')}
                </p>
              </div>
            )}
          </div>
        )}
      </div>
      
      {/* Eliminando o botão duplicado, pois já está dentro do seção de aniversários */}
      
      {/* Popup de aniversário da cidade */}
      {showCityAnniversaryPopup && (
        <CityAnniversaryPopup 
          city={currentCity} 
          date={anniversaryDate} 
          onClose={() => setShowCityAnniversaryPopup(false)} 
        />
      )}
    </div>
  );
}
