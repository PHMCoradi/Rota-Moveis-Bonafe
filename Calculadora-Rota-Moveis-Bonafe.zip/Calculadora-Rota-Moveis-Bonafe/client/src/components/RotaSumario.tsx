import React from 'react';
import { 
  Route as RouteIcon, 
  Navigation, 
  MapPin, 
  Clock, 
  DollarSign, 
  Truck,
  CalendarRange,
  PartyPopper,
  AlertCircle,
  Gift,
  Flag,
  Info as InfoIcon,
  Pencil, // Ícone de lápis para edição
  Check,  // Ícone para confirmar edição
  X      // Ícone para cancelar edição
} from "lucide-react";
import { Separator } from "@/components/ui/separator";
import { Button } from "@/components/ui/button";
import { formatDistance, formatCurrency } from "@/lib/utils";
import { findHolidaysInRange, formatHolidayDate, extractCityAndStateFromAddress } from "@/lib/holidays";
import { useCustomNames } from "@/lib/nameContext";
// Imports de popup de aniversários removidos - agora no PeriodEvents
import { useState, useEffect } from 'react';

// Função para extrair CEP de um endereço
function extractCepFromAddress(address: string): string | null {
  const cepRegex = /\b(\d{5})[-.\s]?(\d{3})\b/;
  const match = address.match(cepRegex);
  if (match) {
    return `${match[1]}-${match[2]}`;
  }
  return null;
}

// Função para buscar nome personalizado de uma parada
function getNomePersonalizado(endereco: string): string | null {
  try {
    const cep = extractCepFromAddress(endereco);
    if (!cep) return null;
    
    const nomes = JSON.parse(localStorage.getItem('paradaNomes') || '{}');
    return nomes[cep] || null;
  } catch (error) {
    console.error('Erro ao buscar nome personalizado:', error);
    return null;
  }
}

// Define interface for Points of Interest
interface PointOfInterest {
  nome: string;
  tipo: string;
  posicao: [number, number];
  detalhe?: string;
  valor?: string;
  naRota?: boolean;
}

// Define interface for Route Alternatives
interface RouteAlternative {
  destaque?: boolean;
  distanciaNumerica: number;
  tempoNumerico: number;
}

// Define interface for Route Result
interface RouteResultData {
  distanciaTotal: string;
  tempoTotal: string;
  distanciaNumerica?: number;
  tempoNumerico?: number;
  origem: string;
  destino?: string;
  paradas?: string[];
  valorPedagios?: string;
  tipoVeiculo?: string;
  pontosInteresse?: PointOfInterest[];
  rotasAlternativas?: RouteAlternative[];
  optimized?: boolean;
  originalWaypointsOrder?: string[];
  optimizedWaypointsOrder?: string[];
  dataInicioEntrega?: string; // data início no formato DD/MM/YYYY
  dataFimEntrega?: string;    // data fim no formato DD/MM/YYYY
}

interface RotaSumarioProps {
  routeResult: RouteResultData | null;
}

// Função auxiliar para obter nomes personalizados de forma consistente
function obterNomesPersonalizados(): Record<string, string> {
  try {
    const rawData = localStorage.getItem('paradaNomes');
    // Logs para depuração
    console.log('Dados brutos do localStorage:', rawData);
    if (!rawData) return {};
    
    const nomes = JSON.parse(rawData);
    console.log('Nomes personalizados carregados:', nomes);
    
    // Verificar cada CEP conhecido e registro disponível
    if (nomes["14091-530"]) console.log('CEP 14091-530 (PEDRO) encontrado no localStorage');
    if (nomes["17302-122"]) console.log('CEP 17302-122 (LUIS) encontrado no localStorage');
    
    return nomes;
  } catch (error) {
    console.error('Erro ao recuperar nomes personalizados:', error);
    return {};
  }
}

export function RotaSumario({ routeResult }: RotaSumarioProps) {
  // Removido componente de popup de aniversário de cidades
  // Agora faz parte do componente PeriodEvents
  const [cidadesVerificadas, setCidadesVerificadas] = useState<string[]>([]);
  const [feriados, setFeriados] = useState<any[]>([]);
  const [aniversarios, setAniversarios] = useState<any[]>([]);
  
  // Estado para armazenar nomes personalizados
  const [nomesPersonalizados, setNomesPersonalizados] = useState<Record<string, string>>({});
  
  // Estados para controlar a edição de nomes
  const [editandoCEP, setEditandoCEP] = useState<string | null>(null);
  const [novoNome, setNovoNome] = useState<string>("");
  
  // Usar o hook de contexto para nomes personalizados
  const { customNames, updateName } = useCustomNames();
  
  // Atualizar o estado local com os nomes do contexto quando disponíveis
  useEffect(() => {
    if (Object.keys(customNames).length > 0) {
      setNomesPersonalizados(customNames);
      console.log("Nomes personalizados disponíveis, forçando atualização da UI");
      
      // Debug para verificar os CEPs conhecidos
      Object.keys(customNames).forEach(cep => {
        console.log(`CEP: ${cep} => Nome: ${customNames[cep]}`);
      });
    }
  }, [customNames, Object.keys(customNames).length]);
  
  // Função para iniciar a edição de um nome
  const iniciarEdicao = (cep: string | null, nomeAtual: string | null) => {
    if (!cep) return;
    setEditandoCEP(cep);
    setNovoNome(nomeAtual || "");
  };
  
  // Função para criar um nome personalizado quando não existe CEP
  // Isso permite adicionar nome para pontos sem CEP ou código postal reconhecível
  const criarNomePersonalizado = (endereco: string, nomeAtual: string | null) => {
    // Casos especiais mais comuns
    if (endereco.includes("Arnaldo Victaliano") || endereco.includes("Jardim Iguatemi") || 
        endereco.includes("Ribeirão Preto")) {
      console.log(`📍 Usando CEP conhecido para Ribeirão Preto: 14091-530`);
      iniciarEdicao("14091-530", nomeAtual || customNames["14091-530"]);
      return;
    }
    
    if (endereco.includes("Rua 13 de Maio") || endereco.includes("Dois Córregos")) {
      console.log(`📍 Usando CEP conhecido para Dois Córregos: 17302-122`);
      iniciarEdicao("17302-122", nomeAtual || customNames["17302-122"]);
      return;
    }
    
    // Para outros endereços, criar um identificador baseado no próprio endereço
    // Convertendo para um formato que pode ser usado como chave no localStorage
    const hashEndereco = endereco
      .replace(/[^a-zA-Z0-9]/g, '') // Manter apenas letras e números
      .substring(0, 20)             // Limitar tamanho
      .toLowerCase();               // Normalizar
    
    // Criar um pseudo-CEP como identificador único
    const pseudoCep = `addr_${hashEndereco}`;
    
    console.log(`📍 Criando identificador para endereço sem CEP: ${pseudoCep}`);
    
    // Verificar se já existe um nome salvo para este pseudo-CEP
    const nomeExistente = customNames[pseudoCep];
    
    // Iniciar edição usando o pseudo-CEP
    iniciarEdicao(pseudoCep, nomeExistente || nomeAtual);
  };
  
  // Função para salvar o novo nome usando o contexto
  const salvarNovoNome = () => {
    if (!editandoCEP || !novoNome.trim()) {
      cancelarEdicao();
      return;
    }
    
    try {
      // Atualizar através do contexto (isso já salva no localStorage)
      updateName(editandoCEP, novoNome.trim());
      
      // Atualizar o estado local também para refletir imediatamente
      setNomesPersonalizados(prev => ({
        ...prev,
        [editandoCEP]: novoNome.trim()
      }));
      
      console.log(`✅ Nome para o CEP ${editandoCEP} atualizado para "${novoNome}"`);
      
      // Limpar estado de edição
      cancelarEdicao();
    } catch (error) {
      console.error('Erro ao salvar novo nome:', error);
    }
  };
  
  // Função para cancelar a edição
  const cancelarEdicao = () => {
    setEditandoCEP(null);
    setNovoNome("");
  };

  // Extrair cidade do endereço
  const extrairCidade = (endereco: string): string => {
    // Tentar extrair a cidade do endereço
    const partes = endereco.split(',');
    if (partes.length > 1) {
      return partes[partes.length - 2].trim();
    }
    // Formato com traço (Cidade-UF)
    if (endereco.includes('-')) {
      return endereco.split('-')[0].trim();
    }
    return endereco;
  };

  useEffect(() => {
    if (!routeResult) return;

    // Construir lista de todos os pontos da rota
    const todosPontos = [
      routeResult.origem, 
      ...(routeResult.paradas || [])
    ].filter(Boolean);

    // Extrair nomes de cidades para verificação
    const cidades = todosPontos.map(endereco => {
      const cidadeInfo = extractCityAndStateFromAddress(endereco);
      // Usar as propriedades corretas com base na estrutura retornada
      const nomeCidade = cidadeInfo.cidade || '';
      const siglaUF = cidadeInfo.uf || '';
      return nomeCidade + (siglaUF ? `-${siglaUF}` : '');
    });

    // Remover duplicatas - convertendo para array
    const cidadesUnicas = Array.from(new Set(cidades));
    setCidadesVerificadas(cidadesUnicas);

    // Verificar eventos e feriados se houver datas de entrega
    if (routeResult.dataInicioEntrega && routeResult.dataFimEntrega) {
      console.log("Verificando feriados no período:", routeResult.dataInicioEntrega, "até", routeResult.dataFimEntrega);
      
      // Encontrar feriados no intervalo de datas
      const eventosEncontrados = findHolidaysInRange(
        routeResult.dataInicioEntrega,
        routeResult.dataFimEntrega,
        cidadesUnicas
      );
      
      setFeriados(eventosEncontrados);
      setAniversarios(eventosEncontrados.filter(feriado => feriado.type === 'aniversario'));

      // Verificação manual para Ribeirão Preto
      const hasRibeiraoPreto = cidadesUnicas.some(cidade => 
        cidade.toLowerCase().includes('ribeirao') || cidade.toLowerCase().includes('ribeirão')
      );
      
      console.log(`Cidades na rota para verificar: ${JSON.stringify(cidadesUnicas)}`);
      console.log(`Rota passa por Ribeirão Preto: ${hasRibeiraoPreto}`);
      
      if (routeResult.dataInicioEntrega && routeResult.dataFimEntrega) {
        // Converter datas para facilitar a comparação
        const [diaInicio, mesInicio] = routeResult.dataInicioEntrega.split('/').map(Number);
        const [diaFim, mesFim] = routeResult.dataFimEntrega.split('/').map(Number);
        
        // Data do aniversário de Ribeirão Preto (19 de junho)
        const anivDia = 19;
        const anivMes = 6; // junho é o mês 6
        
        // Verificar se o período inclui o dia 19/06
        // Comparação simples - se o mês inicial é anterior ou igual a junho e o mês final é posterior ou igual a junho
        const periodoIncluiJunho = (mesInicio <= anivMes && mesFim >= anivMes);
        
        // Se inclui junho, verificar se inclui o dia 19
        let incluiAniversarioRibeirao = false;
        if (periodoIncluiJunho) {
          // Se o mês inicial é junho, verificar se o dia inicial é antes ou igual a 19
          // Se o mês final é junho, verificar se o dia final é depois ou igual a 19
          if (mesInicio < anivMes || (mesInicio === anivMes && diaInicio <= anivDia)) {
            if (mesFim > anivMes || (mesFim === anivMes && diaFim >= anivDia)) {
              incluiAniversarioRibeirao = true;
            }
          }
        }
        
        console.log(`Período de entrega: ${routeResult.dataInicioEntrega} a ${routeResult.dataFimEntrega}`);
        console.log(`Período inclui aniversário de Ribeirão Preto (19/06): ${incluiAniversarioRibeirao}`);
        
        // Adicionar o aniversário de Ribeirão Preto se o período incluir 19/06, independente se a rota passa pela cidade
        if (incluiAniversarioRibeirao) {
          // Verificar se já não foi adicionado
          if (!aniversarios.some(a => a.date === '19/06' && 
              (a.location?.toLowerCase().includes('ribeirao') || a.location?.toLowerCase().includes('ribeirão')))) {
            
            // Adicionar manualmente o aniversário à lista
            const novoAniversario = {
              date: '19/06',
              name: 'Aniversário da Cidade',
              type: 'aniversario',
              location: 'Ribeirão Preto-SP',
              description: 'Comemoração do aniversário de fundação de Ribeirão Preto'
            };
            
            setAniversarios(prev => [...prev, novoAniversario]);
            console.log('Aniversário de Ribeirão Preto adicionado manualmente à lista');
          }
        }
        
        // Se a rota passa por Ribeirão Preto, adicionar uma flag para mostrar o botão mesmo que não seja no período
        if (hasRibeiraoPreto && !incluiAniversarioRibeirao) {
          console.log('Rota passa por Ribeirão Preto, mas fora do período de aniversário');
          // Adicionar aniversário à lista para futura referência, mesmo que o período não inclua
          if (!aniversarios.some(a => a.location?.toLowerCase().includes('ribeirao') || a.location?.toLowerCase().includes('ribeirão'))) {
            const novoAniversario = {
              date: '19/06',
              name: 'Aniversário da Cidade (Fora do período)',
              type: 'aniversario',
              location: 'Ribeirão Preto-SP',
              description: 'Comemoração do aniversário de fundação de Ribeirão Preto (fora do período)'
            };
            setAniversarios(prev => [...prev, novoAniversario]);
          }
        }
      }
    } else {
      console.log("Sem datas de início/fim definidas, não verificando feriados");
      setFeriados([]);
      setAniversarios([]);
    }
  }, [routeResult]);

  if (!routeResult) {
    return null;
  }

  // Formatar lista de feriados
  const formatHolidayList = (holidays: any[]): string => {
    return holidays.map(h => {
      const location = h.location ? ` em ${h.location}` : '';
      return `${h.date} - ${h.name}${location}`;
    }).join(' • ');
  };

  // Formatar lista detalhada de feriados por tipo
  const formatDetailedHolidayList = (holidays: any[], maxItems = 3) => {
    const nacionais = holidays.filter(h => h.type === 'nacional');
    const estaduais = holidays.filter(h => h.type === 'estadual');
    const municipais = holidays.filter(h => h.type === 'municipal');
    const aniversarios = holidays.filter(h => h.type === 'aniversario');
    
    const formatList = (list: any[], prefix: string) => {
      if (list.length === 0) return '';
      
      // Mostrar apenas os primeiros N itens
      const displayItems = list.slice(0, maxItems);
      const remaining = list.length > maxItems ? ` e mais ${list.length - maxItems}` : '';
      
      return `${prefix}: ${displayItems.map(h => {
        const location = h.location && (h.type === 'estadual' || h.type === 'municipal' || h.type === 'aniversario') 
          ? ` em ${h.location.split('-')[0]}` 
          : '';
        return `${h.date} - ${h.name}${location}`;
      }).join(', ')}${remaining}`;
    };
    
    return {
      nacionais: formatList(nacionais, 'Nacionais'),
      estaduais: formatList(estaduais, 'Estaduais'),
      municipais: formatList(municipais, 'Municipais'),
      aniversarios: formatList(aniversarios, 'Aniversários')
    };
  };

  // Função de aniversário de cidades foi removida e movida para PeriodEvents

  // Extract relevant information from route result
  const { 
    distanciaTotal, 
    tempoTotal, 
    origem, 
    paradas = [], 
    valorPedagios, 
    tipoVeiculo, 
    pontosInteresse = [],
    optimized = false,
    optimizedWaypointsOrder = [],
    originalWaypointsOrder = [],
    destino
  } = routeResult;
  
  // Use optimized waypoints order if available, otherwise use paradas
  const displayParadas = optimized && optimizedWaypointsOrder.length > 0 
    ? optimizedWaypointsOrder 
    : paradas;

  // Count tollbooths
  const numPedagios = pontosInteresse.filter((poi: PointOfInterest) => poi.tipo === 'tollbooth').length;
  
  // Count weighing stations
  const numBalancas = pontosInteresse.filter((poi: PointOfInterest) => poi.tipo === 'weighingstation').length;

  // Calculate estimated fuel cost (basic estimate)
  const distanceInKm = parseFloat(distanciaTotal.replace(/[^\d,]/g, '').replace(',', '.')) || 0;
  const consumoEstimado = tipoVeiculo?.includes('caminhao') ? 3.5 : 10; // km/L
  const precoCombustivel = tipoVeiculo?.includes('caminhao') ? 6.5 : 5.8; // R$/L
  const custoEstimadoCombustivel = (distanceInKm / consumoEstimado) * precoCombustivel;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-lg font-semibold flex items-center">
          <RouteIcon className="mr-2 h-5 w-5" /> Resumo da Rota
        </h3>
      </div>
      
      <Separator className="my-2" />
      
      <div className="space-y-4">
        {/* Origin and destination overview */}
        <div className="space-y-2">
          <div className="flex items-start gap-2">
            <MapPin size={16} className="min-w-4 mt-1 text-green-600" />
            <div>
              <span className="text-sm font-medium text-green-600">Origem</span>
              <p className="text-sm">{origem}</p>
            </div>
          </div>
          
          {displayParadas.length > 0 && displayParadas.map((parada: string, index: number) => {
            // Várias estratégias para identificar o ponto e seu possível nome personalizado
            let chaveIdentificacao = "";
            let nomePersonalizado = null;
            
            try {
              // Estratégia 1: Identificar pelo CEP (mais precisa)
              const extractedCep = extractCepFromAddress(parada);
              if (extractedCep) {
                chaveIdentificacao = extractedCep;
                if (customNames[extractedCep]) {
                  nomePersonalizado = customNames[extractedCep];
                  console.log(`Parada ${index + 1}: "${extractedCep}" (chave: "${chaveIdentificacao}") - Tem nome personalizado: ${!!nomePersonalizado}`, 
                    nomePersonalizado ? `Nome: "${nomePersonalizado}"` : "");
                }
              }
              
              // Estratégia 2: Identificar por casos especiais conhecidos
              if (!nomePersonalizado) {
                // Caso Ribeirão Preto
                if (parada.includes("Arnaldo Victaliano") || parada.includes("Jardim Iguatemi") || 
                    parada.toLowerCase().includes("ribeirao") || parada.toLowerCase().includes("ribeirão")) {
                  chaveIdentificacao = "14091-530";  // CEP de Ribeirão Preto - Jardim Iguatemi
                  if (customNames["14091-530"]) {
                    nomePersonalizado = customNames["14091-530"];
                  }
                }
                
                // Caso Dois Córregos
                else if (parada.includes("Rua 13 de Maio") || parada.includes("17302-122") || 
                        parada.includes("Dois Córregos")) {
                  chaveIdentificacao = "17302-122";  // CEP de Dois Córregos - Centro
                  if (customNames["17302-122"]) {
                    nomePersonalizado = customNames["17302-122"];
                  }
                }
              }
              
              // Estratégia 3: Gerar um identificador único para endereços sem CEP
              if (!chaveIdentificacao) {
                const hashEndereco = parada
                  .replace(/[^a-zA-Z0-9]/g, '')
                  .substring(0, 20)
                  .toLowerCase();
                
                chaveIdentificacao = `addr_${hashEndereco}`;
                
                // Verificar se há nome personalizado para este identificador
                if (customNames[chaveIdentificacao]) {
                  nomePersonalizado = customNames[chaveIdentificacao];
                }
              }
              
            } catch (error) {
              console.error('Erro ao processar nome personalizado:', error);
              // Garantir que temos sempre uma chave para o botão de editar, mesmo em caso de erro
              if (!chaveIdentificacao) {
                chaveIdentificacao = `parada_${index}`;
              }
            }
            
            return (
              <div key={index} className="flex items-start gap-2">
                <div className="min-w-4 mt-1 flex justify-center">
                  <div className="flex items-center justify-center rounded-full w-4 h-4 bg-amber-500 text-white text-[10px] font-bold">
                    {index + 1}
                  </div>
                </div>
                <div>
                  {editandoCEP === chaveIdentificacao ? (
                    // Modo de edição
                    <div className="flex flex-col space-y-1">
                      <div className="flex items-center gap-1">
                        <input
                          type="text"
                          value={novoNome}
                          onChange={(e) => setNovoNome(e.target.value)}
                          className="px-2 py-1 border border-amber-300 rounded text-sm focus:outline-none focus:ring-2 focus:ring-amber-400"
                          autoFocus
                          placeholder="Digite o nome personalizado..."
                        />
                        <button 
                          onClick={salvarNovoNome}
                          className="text-green-600 hover:text-green-800"
                          title="Salvar"
                        >
                          <Check size={16} />
                        </button>
                        <button 
                          onClick={cancelarEdicao}
                          className="text-red-600 hover:text-red-800"
                          title="Cancelar"
                        >
                          <X size={16} />
                        </button>
                      </div>
                      <p className="text-xs text-gray-500 italic">Endereço: {parada}</p>
                    </div>
                  ) : (
                    // Modo de visualização
                    <>
                      <div className="flex items-center gap-1">
                        {nomePersonalizado ? (
                          <span className="text-sm font-medium">
                            <span className="bg-amber-100 text-amber-800 px-2 py-0.5 rounded border border-amber-300 text-sm shadow-sm">
                              {nomePersonalizado}
                            </span>
                          </span>
                        ) : (
                          <span className="text-sm font-medium text-amber-600">Parada {index + 1}</span>
                        )}
                        <button 
                          onClick={() => iniciarEdicao(chaveIdentificacao, nomePersonalizado)}
                          className="ml-1 text-gray-400 hover:text-amber-600 transition-colors"
                          title="Editar nome"
                        >
                          <Pencil size={14} />
                        </button>
                      </div>
                      <p className="text-sm text-gray-700 mt-0.5">{parada}</p>
                    </>
                  )}
                </div>
              </div>
            );
          })}
          
          <div className="flex items-start gap-2">
            <Navigation size={16} className="min-w-4 mt-1 text-red-600" />
            <div>
              <span className="text-sm font-medium text-red-600">Destino</span>
              {displayParadas.length > 0 ? (
                (() => {
                  const destinoFinal = displayParadas[displayParadas.length - 1];
                  let chaveIdentificacao = "";
                  let nomePersonalizado = null;
                  
                  try {
                    // Estratégia 1: Identificar pelo CEP (mais precisa)
                    const extractedCep = extractCepFromAddress(destinoFinal);
                    if (extractedCep) {
                      chaveIdentificacao = extractedCep;
                      if (customNames[extractedCep]) {
                        nomePersonalizado = customNames[extractedCep];
                        console.log(`Destino: "${extractedCep}" (chave: "${chaveIdentificacao}") - Tem nome personalizado: ${!!nomePersonalizado}`, 
                          nomePersonalizado ? `Nome: "${nomePersonalizado}"` : "");
                      }
                    }
                    
                    // Estratégia 2: Identificar por casos especiais conhecidos
                    if (!nomePersonalizado) {
                      // Caso Ribeirão Preto
                      if (destinoFinal.includes("Arnaldo Victaliano") || destinoFinal.includes("Jardim Iguatemi") || 
                          destinoFinal.toLowerCase().includes("ribeirao") || destinoFinal.toLowerCase().includes("ribeirão")) {
                        chaveIdentificacao = "14091-530";  // CEP de Ribeirão Preto - Jardim Iguatemi
                        if (customNames["14091-530"]) {
                          nomePersonalizado = customNames["14091-530"];
                          console.log(`  🔍 Caso especial: Ribeirão Preto identificado no destino, usando chave 14091-530`);
                        }
                      }
                      
                      // Caso Dois Córregos
                      else if (destinoFinal.includes("Rua 13 de Maio") || destinoFinal.includes("17302-122") || 
                            destinoFinal.includes("Dois Córregos")) {
                        chaveIdentificacao = "17302-122";  // CEP de Dois Córregos - Centro
                        if (customNames["17302-122"]) {
                          nomePersonalizado = customNames["17302-122"];
                          console.log(`  🔍 Caso especial: Dois Córregos identificado no destino, usando chave 17302-122`);
                        }
                      }
                    }
                    
                    // Estratégia 3: Gerar um identificador único para endereços sem CEP
                    if (!chaveIdentificacao) {
                      const hashEndereco = destinoFinal
                        .replace(/[^a-zA-Z0-9]/g, '')
                        .substring(0, 20)
                        .toLowerCase();
                      
                      chaveIdentificacao = `addr_${hashEndereco}`;
                      
                      // Verificar se há nome personalizado para este identificador
                      if (customNames[chaveIdentificacao]) {
                        nomePersonalizado = customNames[chaveIdentificacao];
                      }
                    }
                  } catch (error) {
                    console.error('Erro ao processar nome personalizado para destino:', error);
                    // Garantir que temos sempre uma chave para o botão de editar, mesmo em caso de erro
                    if (!chaveIdentificacao) {
                      chaveIdentificacao = `destino_${Date.now()}`;
                    }
                  }
                  
                  return (
                    <>
                      {editandoCEP === chaveIdentificacao ? (
                        // Modo de edição do destino
                        <div className="flex flex-col space-y-1">
                          <div className="flex items-center gap-1">
                            <input
                              type="text"
                              value={novoNome}
                              onChange={(e) => setNovoNome(e.target.value)}
                              className="px-2 py-1 border border-amber-300 rounded text-sm focus:outline-none focus:ring-2 focus:ring-amber-400"
                              autoFocus
                              placeholder="Digite o nome personalizado..."
                            />
                            <button 
                              onClick={salvarNovoNome}
                              className="text-green-600 hover:text-green-800"
                              title="Salvar"
                            >
                              <Check size={16} />
                            </button>
                            <button 
                              onClick={cancelarEdicao}
                              className="text-red-600 hover:text-red-800"
                              title="Cancelar"
                            >
                              <X size={16} />
                            </button>
                          </div>
                          <p className="text-xs text-gray-500 italic">Endereço: {destinoFinal}</p>
                        </div>
                      ) : (
                        // Modo de visualização do destino
                        <>
                          <div className="flex items-center gap-1">
                            {nomePersonalizado ? (
                              <span className="text-sm font-medium">
                                <span className="bg-amber-100 text-amber-800 px-2 py-0.5 rounded border border-amber-300 text-sm shadow-sm">
                                  {nomePersonalizado}
                                </span>
                              </span>
                            ) : (
                              <span className="text-sm">Destino final</span>
                            )}
                            <button 
                              onClick={() => iniciarEdicao(chaveIdentificacao, nomePersonalizado)}
                              className="ml-1 text-gray-400 hover:text-amber-600 transition-colors"
                              title="Editar nome do destino"
                            >
                              <Pencil size={14} />
                            </button>
                          </div>
                          <p className="text-sm text-gray-700 mt-0.5">{destinoFinal}</p>
                        </>
                      )}
                    </>
                  );
                })()
              ) : (
                <p className="text-sm">{destino || "Não especificado"}</p>
              )}
            </div>
          </div>
          
          {optimized && originalWaypointsOrder.length > 0 && (
            <div className="mt-3 bg-green-50 p-2 rounded-md text-xs text-green-700">
              <p className="font-semibold flex items-center gap-1">
                <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M20 6 9 17l-5-5" />
                </svg>
                Rota otimizada para menor distância
              </p>
              <p>A ordem das paradas foi ajustada para economizar tempo e combustível.</p>
            </div>
          )}
        </div>
        
        <Separator className="my-2" />
        
        {/* Route statistics */}
        <div className="grid grid-cols-2 gap-y-2">
          <div className="col-span-2 font-medium flex items-center gap-2 text-blue-600">
            <span>Estatísticas da Viagem</span>
          </div>
          
          <div className="flex items-center gap-2">
            <RouteIcon size={14} className="text-gray-600" />
            <span className="text-sm">Distância:</span>
          </div>
          <div className="text-sm font-medium text-right">{distanciaTotal}</div>
          
          <div className="flex items-center gap-2">
            <Clock size={14} className="text-gray-600" />
            <span className="text-sm">Tempo:</span>
          </div>
          <div className="text-sm font-medium text-right">{tempoTotal}</div>
          
          <div className="flex items-center gap-2">
            <DollarSign size={14} className="text-gray-600" />
            <span className="text-sm">Pedágios:</span>
          </div>
          <div className="text-sm font-medium text-right">{valorPedagios || "N/A"}</div>
          
          <div className="flex items-center gap-2">
            <Truck size={14} className="text-gray-600" />
            <span className="text-sm">Veículo:</span>
          </div>
          <div className="text-sm font-medium text-right">
            {tipoVeiculo === "caminhao_2_eixos" ? "Caminhão 2 eixos" : 
              tipoVeiculo === "caminhao_3_eixos" ? "Caminhão 3 eixos" :
              tipoVeiculo === "caminhao_4_eixos" ? "Caminhão 4 eixos" :
              tipoVeiculo === "caminhao_5_eixos" ? "Caminhão 5 eixos" :
              tipoVeiculo === "caminhao_6_eixos" ? "Caminhão 6 eixos" :
              tipoVeiculo === "caminhao_7_eixos" ? "Caminhão 7 eixos" :
              tipoVeiculo === "caminhao_8_eixos" ? "Caminhão 8 eixos" :
              tipoVeiculo === "caminhao_9_eixos" ? "Caminhão 9 eixos" :
              tipoVeiculo}
          </div>
        </div>
        
        <Separator className="my-2" />
        
        {/* Cost estimates */}
        <div>
          <div className="font-medium flex items-center gap-2 text-blue-600 mb-2">
            <span>Estimativas de Custo</span>
          </div>
          
          <div className="bg-blue-50 p-3 rounded-md space-y-2">
            <div className="flex justify-between">
              <span className="text-sm">Combustível:</span>
              <span className="text-sm font-medium">
                {formatCurrency(custoEstimadoCombustivel)}
              </span>
            </div>
            
            <div className="flex justify-between">
              <span className="text-sm">Pedágios:</span>
              <span className="text-sm font-medium">
                {valorPedagios || "R$ 0,00"}
              </span>
            </div>
            
            <Separator className="my-1 bg-blue-200" />
            
            <div className="flex justify-between font-medium text-blue-800">
              <span className="text-sm">Total estimado:</span>
              <span className="text-sm">
                {formatCurrency(custoEstimadoCombustivel + 
                    (valorPedagios ? parseFloat(valorPedagios.replace(/[^\d,]/g, '').replace(',', '.')) : 0)
                  )}
              </span>
            </div>
          </div>
        </div>
        
        {/* POIs summary */}
        {(numPedagios > 0 || numBalancas > 0) && (
          <>
            <Separator className="my-2" />
            
            <div>
              <div className="font-medium flex items-center gap-2 text-blue-600 mb-2">
                <span>Pontos de Interesse</span>
              </div>
              
              <div className="space-y-1">
                {numPedagios > 0 && (
                  <div className="flex items-center justify-between">
                    <span className="text-sm flex items-center gap-1">
                      <DollarSign size={14} className="text-amber-600" />
                      Pedágios na rota:
                    </span>
                    <span className="text-sm font-medium">{numPedagios}</span>
                  </div>
                )}
                
                {numBalancas > 0 && (
                  <div className="flex items-center justify-between">
                    <span className="text-sm flex items-center gap-1">
                      <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-purple-600">
                        <circle cx="12" cy="12" r="10" />
                        <line x1="8" y1="3" x2="8" y2="21" />
                        <line x1="16" y1="3" x2="16" y2="21" />
                        <line x1="3" y1="8" x2="21" y2="8" />
                        <line x1="3" y1="16" x2="21" y2="16" />
                      </svg>
                      Balanças na rota:
                    </span>
                    <span className="text-sm font-medium">{numBalancas}</span>
                  </div>
                )}
              </div>
            </div>
          </>
        )}
        
        {/* Botão de aniversários da cidade removido - agora em PeriodEvents */}
        
        {/* Exibir data de início e fim se estiverem disponíveis */}
        {routeResult.dataInicioEntrega && routeResult.dataFimEntrega && (
          <div className="flex items-center gap-2 text-sm mt-2">
            <CalendarRange className="h-4 w-4 text-gray-500" />
            <span className="font-medium">Período de Entrega:</span>
            <span className="text-gray-700">{routeResult.dataInicioEntrega} a {routeResult.dataFimEntrega}</span>
          </div>
        )}
      </div>
      
      {/* Popup de aniversário da cidade removido - agora em PeriodEvents */}
    </div>
  );
}