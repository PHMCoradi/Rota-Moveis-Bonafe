import React from 'react';
import { Button } from './ui/button';
import { CakeIcon } from 'lucide-react';

interface CityAnniversaryButtonProps {
  onShowCityAnniversary: () => void;
}

export function CityAnniversaryButton({ onShowCityAnniversary }: CityAnniversaryButtonProps) {
  return (
    <Button 
      onClick={onShowCityAnniversary}
      variant="outline"
      className="flex items-center gap-2 bg-amber-50 border-amber-200 hover:bg-amber-100 text-amber-800"
    >
      <CakeIcon className="h-4 w-4" />
      <span>Ver aniversário da cidade</span>
    </Button>
  );
}