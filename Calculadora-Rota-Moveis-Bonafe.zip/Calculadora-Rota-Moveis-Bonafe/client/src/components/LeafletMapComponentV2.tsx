import React, { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import { 
  MapContainer, 
  TileLayer, 
  Marker, 
  Popup, 
  useMapEvents,
  ZoomControl,
  ScaleControl,
  Polyline,
  Circle,
  LayerGroup,
  LayersControl,
  Tooltip as LeafletTooltip,
  Rectangle,
  useMap
} from 'react-leaflet';
import L from 'leaflet';
import { 
  CalendarDays, 
  AlertCircle, 
  Sun, 
  Moon, 
  Utensils, 
  Building2, 
  Pill, 
  HeartPulse,
  Store,
  Coffee,
  Pizza,
  Beer,
  ShoppingBag,
  ShoppingCart,
  DollarSign,
  Scale
} from 'lucide-react';
import { findHolidaysInRange, extractDayAndMonth } from '../lib/holidays';
import { TrafficAlerts } from './TrafficAlerts';
import { PointsOfInterest } from './PointsOfInterest';
import { CityAnniversaryPopup } from './CityAnniversaryPopup';
import { findSpecialCepInAddress, getSpecialCoordinates } from '../lib/specialCeps';
import { useCustomNames } from '../lib/nameContext';
import { Button } from '@/components/ui/button';
import type { RoutePointOfInterest, RouteAlternative, RouteResponse } from '@shared/schema';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { formatarNome } from '../lib/textUtils';

/** Função para extrair CEP de um endereço */
function extractCepFromAddress(address: string): string | null {
  const cepRegex = /\b(\d{5})[-.\s]?(\d{3})\b/;
  const match = address.match(cepRegex);
  if (match) {
    return `${match[1]}-${match[2]}`;
  }
  return null;
}

/** 
 * Hook que retorna uma função para buscar nome personalizado de um endereço
 * utilizando o contexto global de nomes
 */
function useGetNomePersonalizado() {
  // Usar o hook de contexto para nomes personalizados - acesso direto
  const { customNames } = useCustomNames();
  
  // Retornar uma função que utiliza o contexto atual a cada chamada
  return (endereco: string): string | null => {
    try {
      // Verificar se o objeto customNames não está vazio
      if (!customNames || Object.keys(customNames).length === 0) {
        console.log(`Nenhum nome personalizado disponível no momento da busca para: ${endereco}`);
        return null;
      }
      
      console.log(`Buscando nome personalizado para "${endereco}" em`, Object.keys(customNames).length, 'nomes');
      
      let nomePersonalizado: string | null = null;
      
      // Se o endereço exato for uma chave no objeto customNames, usá-lo diretamente
      if (customNames[endereco]) {
        nomePersonalizado = customNames[endereco];
        console.log(`✅ Encontrado nome personalizado para endereço exato: "${endereco}" => "${nomePersonalizado}"`);
        return nomePersonalizado;
      }
      
      // Extrair qualquer CEP presente no endereço e usar como chave alternativa
      const cep = extractCepFromAddress(endereco);
      if (cep && customNames[cep]) {
        nomePersonalizado = customNames[cep];
        console.log(`✅ Encontrado nome personalizado para CEP: "${cep}" => "${nomePersonalizado}"`);
        return nomePersonalizado;
      }
      
      // CASO ESPECIAL: Rua Arnaldo Victaliano (verificar o CEP específico)
      if (!nomePersonalizado && (
          endereco.includes("Arnaldo Victaliano") || 
          endereco.includes("Jardim Iguatemi") || 
          endereco.toLowerCase().includes("ribeirao") || 
          endereco.toLowerCase().includes("ribeirão"))) {
        
        const cepEspecial = "14091-530";
        if (customNames[cepEspecial]) {
          nomePersonalizado = customNames[cepEspecial];
          console.log(`✅ Encontrado nome personalizado para CASO ESPECIAL Arnaldo Victaliano: "${cepEspecial}" => "${nomePersonalizado}"`);
          return nomePersonalizado;
        }
      }
      
      // CASO ESPECIAL: Dois Córregos (verificar o CEP específico)
      if (!nomePersonalizado && (
          endereco.includes("Rua 13 de Maio") || 
          endereco.includes("17302-122") || 
          endereco.includes("Dois Córregos"))) {
        
        const cepEspecial = "17302-122";
        if (customNames[cepEspecial]) {
          nomePersonalizado = customNames[cepEspecial];
          console.log(`✅ Encontrado nome personalizado para CASO ESPECIAL Dois Córregos: "${cepEspecial}" => "${nomePersonalizado}"`);
          return nomePersonalizado;
        }
      }
      
      // Retornar o nome personalizado no formato original (sem formatação automática)
      // para preservar o formato exato como foi importado do arquivo
      if (nomePersonalizado) {
        console.log(`📌 Nome personalizado encontrado e será usado sem formatação: "${nomePersonalizado}"`);
        // Retornar o nome sem formatação para preservar maiúsculas/minúsculas do arquivo
        return nomePersonalizado;
      }
      
      console.log(`❌ Nenhum nome personalizado encontrado para: "${endereco}"`);
      return null;
    } catch (error) {
      console.error('Erro ao buscar nome personalizado:', error);
      return null;
    }
  };
}

/**
 * Decodifica uma string no formato polyline do Google Maps para um array de coordenadas
 * @param encoded String codificada no formato polyline
 * @returns Array de coordenadas [latitude, longitude]
 */
function decodePolyline(encoded: string): [number, number][] {
  if (!encoded || encoded.length === 0) {
    console.warn('Polyline vazia recebida');
    return [];
  }

  try {
    console.log('Decodificando polyline com comprimento', encoded.length);
    
    let index = 0;
    const len = encoded.length;
    const points: [number, number][] = [];
    let lat = 0;
    let lng = 0;

    while (index < len) {
      let b;
      let shift = 0;
      let result = 0;

      do {
        if (index >= len) {
          console.warn('Polyline inválida: índice fora dos limites');
          return points;
        }
        b = encoded.charCodeAt(index++) - 63;
        result |= (b & 0x1f) << shift;
        shift += 5;
      } while (b >= 0x20);

      const dlat = ((result & 1) !== 0 ? ~(result >> 1) : (result >> 1));
      lat += dlat;

      shift = 0;
      result = 0;

      do {
        if (index >= len) {
          console.warn('Polyline inválida: índice fora dos limites para longitude');
          return points;
        }
        b = encoded.charCodeAt(index++) - 63;
        result |= (b & 0x1f) << shift;
        shift += 5;
      } while (b >= 0x20);

      const dlng = ((result & 1) !== 0 ? ~(result >> 1) : (result >> 1));
      lng += dlng;

      // Dividir por 1e5 para obter as coordenadas reais
      const p: [number, number] = [lat * 1e-5, lng * 1e-5];
      points.push(p);
    }

    // Verificar se temos coordenadas para processar
    if (points.length === 0) {
      console.warn('Nenhum ponto válido decodificado da polyline');
      return [];
    }

    // Verificar o primeiro ponto para diagnóstico
    console.log('Pontos decodificados:', points.length);
    console.log('Primeiros 5 pontos da rota:', points.slice(0, 5));
    console.log('Últimos 5 pontos da rota:', points.slice(-5));

    // Verificar Waypoints originais recebidos do OSRM
    if (points.length > 0) {
      // Os waypoints na resposta OSRM estão no formato [longitude, latitude]
      // O formato Leaflet espera [latitude, longitude]
      
      // Verificar o formato real dos pontos recebidos
      const waypointsFormat = points[0];
      console.log('Formato original dos waypoints:', [waypointsFormat]);
      
      // Diagnóstico: verificar se os pontos estão em um formato válido (dentro da faixa esperada)
      // Latitude: -90 a 90, Longitude: -180 a 180
      const isLatValidRange = (lat: number) => Math.abs(lat) <= 90;
      const isLngValidRange = (lng: number) => Math.abs(lng) <= 180;
      
      // Verificar se o primeiro ponto parece estar no formato correto
      const firstPoint = points[0];
      const [coord1, coord2] = firstPoint;
      
      // Verificar se o ponto parece estar no formato [lng, lat] vs [lat, lng]
      const formatoCorreto = isLatValidRange(coord1) && isLngValidRange(coord2);
      const formatoInvertido = isLatValidRange(coord2) && isLngValidRange(coord1);
      
      if (!formatoCorreto && formatoInvertido) {
        // Se o formato parece estar invertido, corrigir todos os pontos
        console.log('Detectado formato invertido [lng, lat], convertendo para [lat, lng]');
        return points.map(p => [p[1], p[0]]);
      }
      
      // Verificação específica para o caso do endereço Rua Botafogo, Vila Coradi
      if (Math.abs(coord1) < 3 && Math.abs(coord2) < 5) {
        console.log('ALERTA: Detectadas coordenadas muito próximas de zero, possivelmente incorretas:');
        console.log('Ponto detectado:', firstPoint);
        console.log('Corrigindo para a localização conhecida da Rua Botafogo, Vila Coradi');
        
        // Substituir por coordenadas conhecidas do endereço
        const correcaoRuaBotafogo: [number, number] = [-22.369643, -48.384349];
        return [correcaoRuaBotafogo];
      }
      
      // Se as coordenadas estão em faixas inválidas completamente
      if ((!isLatValidRange(coord1) && !isLngValidRange(coord1)) || 
          (!isLatValidRange(coord2) && !isLngValidRange(coord2))) {
        console.warn('AVISO: Coordenadas completamente inválidas detectadas');
        console.log('Usando uma localização padrão para Dois Córregos');
        const doisCorregosCoordenadas: [number, number] = [-22.369643, -48.384349];
        return [doisCorregosCoordenadas]; // Coordenadas de Dois Córregos
      }
    }
    
    // Se o formato parece estar correto ou não conseguimos determinar uma correção automática
    return points;
  } catch (error) {
    console.error('Erro ao decodificar polyline:', error);
    const doisCorregosCoordenadas: [number, number] = [-22.369643, -48.384349];
    return [doisCorregosCoordenadas]; // Em caso de erro, usar uma localização padrão
  }
}

/**
 * Calcula a distância entre dois pontos usando a fórmula de Haversine
 * @param point1 Coordenadas do primeiro ponto [lat, lng]
 * @param point2 Coordenadas do segundo ponto [lat, lng]
 * @returns Distância em metros
 */
function distancePointToPoint(point1: [number, number], point2: [number, number]): number {
  const R = 6371000; // raio da Terra em metros
  const lat1 = point1[0] * Math.PI / 180;
  const lat2 = point2[0] * Math.PI / 180;
  const dLat = (point2[0] - point1[0]) * Math.PI / 180;
  const dLng = (point2[1] - point1[1]) * Math.PI / 180;
  
  const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
           Math.cos(lat1) * Math.cos(lat2) *
           Math.sin(dLng/2) * Math.sin(dLng/2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  
  return R * c;
}

/**
 * Calcula a distância mínima de um ponto a uma rota (conjunto de segmentos)
 * @param point Coordenadas do ponto [lat, lng]
 * @param routePoints Coordenadas dos pontos que compõem a rota
 * @returns Distância mínima em metros
 */
function distanceToRoute(point: [number, number], routePoints: [number, number][]): number {
  if (!routePoints || routePoints.length < 2) {
    return routePoints.length === 1 
      ? distancePointToPoint(point, routePoints[0]) 
      : Infinity;
  }
  
  let minDistance = Infinity;
  
  // Verificar cada segmento da rota
  for (let i = 0; i < routePoints.length - 1; i++) {
    const segment = [routePoints[i], routePoints[i+1]];
    const d = distancePointToSegment(point, segment[0], segment[1]);
    minDistance = Math.min(minDistance, d);
  }
  
  return minDistance;
}

/**
 * Calcular a distância mínima de um ponto a um segmento de reta
 * @param point Coordenadas do ponto [lat, lng]
 * @param segmentStart Início do segmento [lat, lng]
 * @param segmentEnd Fim do segmento [lat, lng]
 * @returns Distância mínima em metros
 */
function distancePointToSegment(
  point: [number, number], 
  segmentStart: [number, number], 
  segmentEnd: [number, number]
): number {
  // Distância direta aos pontos extremos do segmento
  const d1 = distancePointToPoint(point, segmentStart);
  const d2 = distancePointToPoint(point, segmentEnd);
  
  // Comprimento do segmento
  const segLength = distancePointToPoint(segmentStart, segmentEnd);
  
  // Se o segmento é um ponto, retornar distância direta
  if (segLength === 0) return d1;
  
  // Cálculo usando produto escalar para encontrar projeção
  const t = ((point[0] - segmentStart[0]) * (segmentEnd[0] - segmentStart[0]) +
            (point[1] - segmentStart[1]) * (segmentEnd[1] - segmentStart[1])) / 
            (segLength * segLength);
  
  // Se a projeção cai fora do segmento
  if (t < 0) return d1;
  if (t > 1) return d2;
  
  // Cálculo do ponto mais próximo no segmento
  const projection: [number, number] = [
    segmentStart[0] + t * (segmentEnd[0] - segmentStart[0]),
    segmentStart[1] + t * (segmentEnd[1] - segmentStart[1])
  ];
  
  return distancePointToPoint(point, projection);
}

/**
 * Verifica se um ponto está próximo da rota
 * @param point Coordenadas do ponto [lat, lng]
 * @param routePoints Coordenadas dos pontos da rota
 * @param maxDistance Distância máxima em metros (default: 5000m = 5km)
 * @returns true se o ponto está próximo da rota
 */
function isPointNearRoute(
  point: [number, number], 
  routePoints: [number, number][], 
  maxDistance: number = 5000
): boolean {
  if (!routePoints || routePoints.length === 0) {
    return false;
  }
  
  console.log(`Verificando distância do ponto [${point[0]}, ${point[1]}] para a rota com ${routePoints.length} pontos`);
  const distance = distanceToRoute(point, routePoints);
  const isNear = distance <= maxDistance;
  console.log(`Distância do ponto para a rota: ${distance.toFixed(2)}m, máximo: ${maxDistance}m, próximo: ${isNear}`);
  return isNear;
}

import 'leaflet/dist/leaflet.css';

// Corrigir ícones do Leaflet
import icon from 'leaflet/dist/images/marker-icon.png';
import iconShadow from 'leaflet/dist/images/marker-shadow.png';

let DefaultIcon = L.Icon.Default.prototype;
DefaultIcon.options.iconUrl = icon;
DefaultIcon.options.shadowUrl = iconShadow;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: icon,
  iconUrl: icon,
  shadowUrl: iconShadow
});

// Tipos já importados de '@shared/schema'

interface MapComponentProps {
  routeResult: RouteResponse | null;
}

// Função para criar um ícone numerado
function createNumberedIcon(number: number, color: string = '#3b82f6', customName?: string | null): L.DivIcon {
  if (customName) {
    // Se tiver nome personalizado, criar ícone com tooltip
    // Usar o nome personalizado exatamente como está no arquivo (sem formatação)
    // para preservar maiúsculas/minúsculas como definido pelo usuário
    
    return L.divIcon({
      className: 'custom-div-icon-with-name',
      html: `
        <div class="marker-container">
          <div style="background-color: ${color}; width: 30px; height: 30px; display: flex; justify-content: center; align-items: center; color: white; font-weight: bold; font-size: 14px; border-radius: 50%; box-shadow: 0 2px 5px rgba(0,0,0,0.3); border: 2px solid white; transition: transform 0.2s ease, box-shadow 0.2s ease; position: relative;">
            ${number}
            <div class="marker-tooltip" style="position: absolute; top: -30px; left: 50%; transform: translateX(-50%); background-color: rgba(255,255,255,0.95); color: ${color}; padding: 4px 8px; border-radius: 4px; font-size: 12px; white-space: nowrap; box-shadow: 0 1px 3px rgba(0,0,0,0.2); border: 1px solid ${color}; opacity: 0; transition: opacity 0.2s ease; pointer-events: none;">
              ${customName}
            </div>
          </div>
        </div>
      `,
      iconSize: [30, 30],
      iconAnchor: [15, 15],
      popupAnchor: [0, -20]
    });
  } else {
    // Ícone padrão sem nome personalizado
    return L.divIcon({
      className: 'custom-div-icon',
      html: `
        <div style="background-color: ${color}; width: 30px; height: 30px; display: flex; justify-content: center; align-items: center; color: white; font-weight: bold; font-size: 14px; border-radius: 50%; box-shadow: 0 2px 5px rgba(0,0,0,0.3); border: 2px solid white; transition: transform 0.2s ease, box-shadow 0.2s ease;">
          ${number}
        </div>
      `,
      iconSize: [30, 30],
      iconAnchor: [15, 15],
      popupAnchor: [0, -20]
    });
  }
}

// Função para criar ícone de feriado
function createHolidayIcon(): L.DivIcon {
  return L.divIcon({
    className: 'holiday-div-icon',
    html: `
      <div style="display: flex; justify-content: center; align-items: center;">
        <div style="background-color: #f59e0b; width: 28px; height: 28px; display: flex; justify-content: center; align-items: center; border-radius: 50%; box-shadow: 0 2px 5px rgba(0,0,0,0.3);">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
            <line x1="16" y1="2" x2="16" y2="6"></line>
            <line x1="8" y1="2" x2="8" y2="6"></line>
            <line x1="3" y1="10" x2="21" y2="10"></line>
            <path d="M8 14h.01"></path>
            <path d="M12 14h.01"></path>
            <path d="M16 14h.01"></path>
            <path d="M8 18h.01"></path>
            <path d="M12 18h.01"></path>
            <path d="M16 18h.01"></path>
          </svg>
        </div>
      </div>
    `,
    iconSize: [28, 28],
    iconAnchor: [14, 14]
  });
}

// Componente para localizar o usuário
interface LocationMarkerProps {
  originLocation?: [number, number]; // Coordenadas da origem quando disponíveis
}

function LocationMarker({ originLocation }: LocationMarkerProps) {
  // Coordenadas padrão para Dois Córregos-SP
  const doisCorregosCoordenadas = L.latLng(-22.3697, -48.3845);
  
  // Inicializar com posição de Dois Córregos ou a origem da rota, se disponível
  const initialPosition = originLocation 
    ? L.latLng(originLocation[0], originLocation[1]) 
    : doisCorregosCoordenadas;
  
  const [position, setPosition] = useState<L.LatLng>(initialPosition);
  const [accuracy, setAccuracy] = useState<number>(80); // Começar com um raio menor
  const [mapInitialized, setMapInitialized] = useState(false);

  // Wrapper de proteção ao redor de acessos ao mapa
  const safeMapOperation = (callback: (map: L.Map) => void, map: L.Map) => {
    try {
      if (map && typeof map.getContainer === 'function') {
        const container = map.getContainer();
        // Verificar se o container existe e está no DOM
        if (container && document.body.contains(container)) {
          callback(map);
        } else {
          console.log("Container do mapa não está no DOM, operação ignorada");
        }
      }
    } catch (error) {
      console.error("Erro ao executar operação no mapa:", error);
    }
  };

  const map = useMapEvents({
    locationfound(e) {
      console.log("Localização encontrada:", e.latlng);
      
      // Verificar se é a localização mockada do Replit (Bauru)
      const isBauruMock = Math.abs(e.latlng.lat - (-22.3346)) < 0.01 && 
                          Math.abs(e.latlng.lng - (-49.0612)) < 0.01;
      
      // Se temos posição de origem, priorizar ela em vez da localização do dispositivo
      if (originLocation) {
        console.log("Usando localização de origem em vez da localização atual");
        const originPos = L.latLng(originLocation[0], originLocation[1]);
        setPosition(originPos);
        setAccuracy(80); // Raio menor para origem 
        
        safeMapOperation((m) => {
          m.flyTo(originPos, 15);
        }, e.target);
        
        return;
      }
      
      if (isBauruMock) {
        console.log("Detectada localização mockada de Bauru, usando Dois Córregos como padrão");
        setPosition(doisCorregosCoordenadas);
        setAccuracy(100); // Raio em metros - REDUZIDO para 100m
        
        safeMapOperation((m) => {
          m.flyTo(doisCorregosCoordenadas, 15);
        }, e.target);
      } else {
        // Usar a localização real
        setPosition(e.latlng);
        // Limitar o raio máximo para 100m ou a exatidão real, o que for menor
        setAccuracy(Math.min(e.accuracy, 100));
        
        safeMapOperation((m) => {
          m.flyTo(e.latlng, Math.max(m.getZoom(), 15));
        }, e.target);
      }
    },
    locationerror(e) {
      console.error("Erro ao localizar usuário:", e.message);
      
      // Se temos origem definida, usar ela mesmo com erro
      if (originLocation) {
        const originPos = L.latLng(originLocation[0], originLocation[1]);
        console.log("Usando posição de origem mesmo com erro de localização");
        setPosition(originPos);
        setAccuracy(80);
        
        safeMapOperation((m) => {
          m.flyTo(originPos, 15);
        }, e.target);
        
        return;
      }
      
      // Usar coordenadas padrão de Dois Córregos, SP
      setPosition(doisCorregosCoordenadas);
      setAccuracy(100); // Raio em metros aproximado - REDUZIDO
      
      safeMapOperation((m) => {
        m.flyTo(doisCorregosCoordenadas, 15);
      }, e.target);
      
      console.log("Usando posição padrão em Dois Córregos-SP devido a erro de localização");
    }
  });

  // Efeito para inicializar o mapa na posição correta
  useEffect(() => {
    // Proteger contra acesso a um mapa que não está pronto
    if (!map || typeof map.getContainer !== 'function') {
      console.log("Mapa ainda não está pronto");
      return;
    }
    
    // Indicar que o mapa foi inicializado
    setMapInitialized(true);
    
    // Usar setTimeout para garantir que o DOM está pronto
    setTimeout(() => {
      try {
        // Se temos origem, usar ela para inicializar
        if (originLocation) {
          const originPos = L.latLng(originLocation[0], originLocation[1]);
          console.log("Inicializando mapa na localização de origem");
          
          safeMapOperation((m) => {
            m.flyTo(originPos, 15);
          }, map);
          
          setPosition(originPos);
          setAccuracy(80);
        } else {
          // Caso contrário, iniciar em Dois Córregos
          console.log("Inicializando mapa em Dois Córregos (padrão)");
          
          safeMapOperation((m) => {
            m.flyTo(doisCorregosCoordenadas, 15);
          }, map);
          
          // Então tentar localizar o usuário
          setTimeout(() => {
            safeMapOperation((m) => {
              m.locate({ enableHighAccuracy: true });
            }, map);
          }, 500);
        }
      } catch (error) {
        console.error("Erro ao inicializar localização:", error);
      }
    }, 200);
  }, [map, originLocation]);

  // Renderizar somente quando o mapa estiver inicializado
  if (!mapInitialized) {
    return null;
  }

  return (
    <div className="location-marker-container">
      <Marker position={position} icon={new L.Icon({
        iconUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon.png',
        iconRetinaUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon-2x.png',
        shadowUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-shadow.png',
        iconSize: [25, 41],
        iconAnchor: [12, 41],
        popupAnchor: [1, -34],
        shadowSize: [41, 41]
      })}>
        <Popup>Sua localização atual</Popup>
      </Marker>
      {accuracy > 0 && (
        <Circle 
          center={position} 
          radius={accuracy} 
          pathOptions={{ color: 'blue', fillColor: 'blue', fillOpacity: 0.1 }}
        />
      )}
    </div>
  );
}

// Função para criar ícones de pontos de interesse (POI)
function createPoiIcon(type: string): L.DivIcon {
  // Configurar cores e ícones com base no tipo
  let iconHtml = '';
  let bgColor = '';
  
  switch (type) {
    case 'restaurant':
      iconHtml = `<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 5h18v1H3z"></path><path d="M3 10h18v1H3z"></path><path d="M3 15h18v1H3z"></path></svg>`;
      bgColor = '#ef4444'; // Vermelho
      break;
    case 'market':
      iconHtml = `<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 22V8h-4V4H8v4H4v14h16z"></path><path d="M16 22V8h4"></path><path d="M12 2v2"></path><path d="M9 15h6"></path><path d="M9 18h6"></path></svg>`;
      bgColor = '#22c55e'; // Verde
      break;
    case 'pharmacy':
      iconHtml = `<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 20V9H4V4h12v5h-2v11"></path><path d="M12 20h6v-9h-6z"></path><path d="M13 14h4"></path><path d="M15 12v4"></path></svg>`;
      bgColor = '#3b82f6'; // Azul
      break;
    case 'hospital':
      iconHtml = `<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path><path d="M13.73 21a2 2 0 0 1-3.46 0"></path><path d="M12 5V3"></path><path d="M12 10v3"></path><path d="M9 13h6"></path></svg>`;
      bgColor = '#ec4899'; // Rosa
      break;
    case 'coffee':
      iconHtml = `<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 8h1a4 4 0 1 1 0 8h-1"></path><path d="M3 8h14v9a4 4 0 0 1-4 4H7a4 4 0 0 1-4-4Z"></path><line x1="6" y1="2" x2="6" y2="4"></line><line x1="10" y1="2" x2="10" y2="4"></line><line x1="14" y1="2" x2="14" y2="4"></line></svg>`;
      bgColor = '#a16207'; // Marrom
      break;
    case 'tollbooth':
      iconHtml = `<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2v20"></path><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path></svg>`;
      bgColor = '#f59e0b'; // Âmbar
      break;
    case 'weighingstation':
      iconHtml = `<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="3" x2="12" y2="15"></line><circle cx="12" cy="18" r="3"></circle><path d="M5 7H3a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h18a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-2"></path><path d="M7 1h10"></path><path d="M7 5h10"></path></svg>`;
      bgColor = '#8b5cf6'; // Roxo
      break;
    case 'gasstation':
      iconHtml = `<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 22h12"></path><path d="M5 18h8"></path><path d="M9 18v4"></path><path d="M6 15h6"></path><path d="M8 11h4"></path><path d="M10 3v8"></path><path d="M3 11h12"></path><path d="M16 22V8a5 5 0 0 0-5-5"></path><path d="M19 6v4.5"></path><path d="M22 10h-4.5"></path></svg>`;
      bgColor = '#059669'; // Verde esmeralda
      break;
    default:
      iconHtml = `<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/></svg>`;
      bgColor = '#64748b'; // Cinza
  }

  return L.divIcon({
    className: 'poi-div-icon',
    html: `
      <div style="background-color: ${bgColor}; width: 32px; height: 32px; display: flex; justify-content: center; align-items: center; border-radius: 50%; box-shadow: 0 2px 5px rgba(0,0,0,0.5);">
        ${iconHtml}
      </div>
    `,
    iconSize: [32, 32],
    iconAnchor: [16, 16]
  });
}

// Interface removida para evitar conflito com a importada de PointsOfInterest.tsx

// Removido o componente PointsOfInterest duplicado. 
// Usando o componente importado de './PointsOfInterest'

// Componente de debug para mostrar pontos na rota
function MapDebugger({ positions }: { positions: [number, number][] }) {
  useEffect(() => {
    console.log('MapDebugger montado com', positions.length, 'pontos');
    if (positions.length > 0) {
      console.log('DEBUG - Primeiros pontos:', positions.slice(0, 2));
      console.log('DEBUG - Últimos pontos:', positions.slice(-2));
    }
  }, [positions]);

  return null;
}

// Extrair o nome da cidade de um endereço
const extrairCidade = (endereco: string | any): string => {
  if (!endereco) return '';
  
  // Garantir que estamos trabalhando com uma string
  const enderecoStr = typeof endereco === 'string' ? endereco : 
                      endereco.toString ? endereco.toString() : 
                      JSON.stringify(endereco);
  
  // Caso 1: Se já estiver no formato "Cidade-UF"
  if (/^[A-Za-zÀ-ÖØ-öø-ÿ\s]+\-[A-Z]{2}$/.test(enderecoStr)) {
    console.log('Já está no formato Cidade-UF:', enderecoStr);
    return enderecoStr;
  }
  
  // Caso 2: Extrair cidade pela vírgula (Rua Tal, Cidade)
  const partesVirgula = enderecoStr.split(',');
  if (partesVirgula.length > 1) {
    const cidadeParte = partesVirgula[1].trim();
    console.log('Extraído pela vírgula:', partesVirgula[0].trim());
    return cidadeParte;
  }
  
  // Caso 3: Extrair cidade por heurística
  // Ex: "Rua Botafogo, 135 - Centro, Dois Córregos"
  const match = enderecoStr.match(/\s-\s([^,]+),\s([^,]+)$/);
  if (match) {
    console.log(`Extraído por heurística: ${match[2]}`);
    return match[2];
  }
  
  // Caso 4: Extrair CEP e buscar a cidade correspondente
  const cepMatch = enderecoStr.match(/(\d{5})-?(\d{3})/);
  if (cepMatch) {
    const cep = cepMatch[0];
    console.log(`Encontrado CEP ${cep}, mas sem mapeamento para cidade`);
    return 'CEP: ' + cep;
  }
  
  console.log(`Nenhum padrão encontrado, retornando o endereço completo`);
  return enderecoStr;
};

// Define os tipos de visualização de mapa disponíveis
type MapViewType = 'standard' | 'satellite' | 'panorama';

export function LeafletMapComponentV2({ routeResult }: MapComponentProps) {
  // Usar o hook que fornece a função para obter nomes personalizados e acessar o contexto diretamente
  const getNomePersonalizado = useGetNomePersonalizado();
  const { customNames } = useCustomNames(); // Acesso direto ao contexto
  
  // Efeito para forçar atualização do mapa quando os nomes personalizados mudarem
  useEffect(() => {
    console.log('Nomes personalizados atualizados no contexto:', customNames);
    // Forçar recriação do mapa para refletir os nomes personalizados
    setMapKey(prevKey => prevKey + 1);
  }, [customNames]);
  const [positions, setPositions] = useState<[number, number][]>([]);
  const [waypoints, setWaypoints] = useState<[number, number][]>([]);
  const [center, setCenter] = useState<[number, number]>([-22.3697, -48.3845]); // Dois Córregos-SP (centro)
  const [zoom, setZoom] = useState(14); // Zoom inicial em Dois Córregos
  const [mapKey, setMapKey] = useState(0); // Usado para forçar recriação do mapa quando necessário
  
  // Estado para o popup de aniversário de cidades
  const [showCityAnniversaryPopup, setShowCityAnniversaryPopup] = useState(false);
  const [anniversaryCity, setAnniversaryCity] = useState('');
  const [anniversaryDate, setAnniversaryDate] = useState('');
  const [holidays, setHolidays] = useState<{ cityName: string; holidayInfo: string; position: [number, number] }[]>([]);
  
  // Estado para monitorar se o mapa está pronto para uso
  const [mapReady, setMapReady] = useState(false);
  
  // Estado para controlar o tipo de visualização do mapa
  const [mapViewType, setMapViewType] = useState<MapViewType>('standard');
  // Estado para controlar a opacidade durante transições
  const [fadeOpacity, setFadeOpacity] = useState(1);
  // Estado para rastrear o tipo de mapa anterior durante transições
  const [previousMapViewType, setPreviousMapViewType] = useState<MapViewType | null>(null);
  // Estado para armazenar as rotas alternativas
  const [alternativeRoutes, setAlternativeRoutes] = useState<{positions: [number, number][]; info: RouteAlternative}[]>([]);
  
  // Estados para controlar a animação de transição entre rotas
  const [isRouteTransitioning, setIsRouteTransitioning] = useState(false);
  const [routeOpacity, setRouteOpacity] = useState(1);
  const [animatedPositions, setAnimatedPositions] = useState<[number, number][]>([]);
  const [animationProgress, setAnimationProgress] = useState(0);
  const [previousPositions, setPreviousPositions] = useState<[number, number][]>([]);
  
  // URLs para diferentes estilos de mapa
  const mapTileUrls = {
    standard: "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
    satellite: "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",
    panorama: "https://{s}.tile.openstreetmap.fr/hot/{z}/{x}/{y}.png"
  };
  
  // URL atual para o estilo de mapa
  const mapTileUrl = mapTileUrls[mapViewType];
  
  // Função de utilidade para verificar se um array de coordenadas é válido
  const isValidCoord = (coord: any): boolean => {
    return Array.isArray(coord) && 
           coord.length === 2 && 
           !isNaN(Number(coord[0])) && 
           !isNaN(Number(coord[1])) &&
           Math.abs(coord[0]) <= 90 && 
           Math.abs(coord[1]) <= 180;
  };
  
  // Removido o componente ArnaldoVictalianoLabel para evitar erros
  // Esta seção foi comentada para resolver conflitos com o objeto Leaflet Map
  
  // Processar feriados quando houver dados de rota e datas
  useEffect(() => {
    if (routeResult && routeResult.dataInicioEntrega && routeResult.dataFimEntrega) {
      console.log("Verificando feriados para intervalo: ", routeResult.dataInicioEntrega, "a", routeResult.dataFimEntrega);
      
      // Obter lista de cidades na rota (origem, paradas)
      const cidades = [routeResult.origem].concat(
        routeResult.optimized && routeResult.optimizedWaypointsOrder 
        ? routeResult.optimizedWaypointsOrder 
        : routeResult.paradas || []
      ).filter(Boolean).map(cidade => extrairCidade(cidade));
      
      console.log("Cidades na rota para verificar feriados:", cidades);
      
      // Obter feriados dentro do intervalo para estas cidades
      const feriadosEncontrados = findHolidaysInRange(
        routeResult.dataInicioEntrega || '', 
        routeResult.dataFimEntrega || '', 
        cidades
      );
      
      console.log("Feriados encontrados no intervalo:", feriadosEncontrados);
      
      // Se encontrou feriados, criar marcadores para eles usando as coordenadas dos waypoints
      if (feriadosEncontrados.length > 0 && waypoints.length > 0) {
        const holidayMarkers = [];
        
        for (const feriado of feriadosEncontrados) {
          // Extrair cidade do campo location (formato: Cidade-UF) ou usar vazio para nacional
          const cidadeFeriado = feriado.location ? feriado.location.split('-')[0].trim() : '';
          console.log(`Processando feriado: ${feriado.name} em ${cidadeFeriado || 'Nacional'}`);
          
          // Procurar o índice da cidade na lista original
          let index = -1;
          
          if (cidadeFeriado) {  // Feriado municipal/estadual
            // Primeiro verificar na origem
            if (extrairCidade(routeResult.origem).includes(cidadeFeriado)) {
              index = 0; // A origem é o primeiro waypoint (índice 0)
              console.log(`Cidade do feriado encontrada na origem: ${cidadeFeriado}`);
            } else {
              // Procurar nas paradas
              let paradasParaVerificar = routeResult.paradas || [];
              
              // Se a rota foi otimizada, usar a ordem otimizada
              if (routeResult.optimized && routeResult.optimizedWaypointsOrder) {
                paradasParaVerificar = routeResult.optimizedWaypointsOrder;
              }
              
              // Verificar cada parada
              for (let i = 0; i < paradasParaVerificar.length; i++) {
                const paradaCidade = extrairCidade(paradasParaVerificar[i]);
                
                console.log(`Comparando '${paradaCidade}' com '${cidadeFeriado}'`);
                
                // Verificar se o nome da cidade da parada inclui o nome da cidade do feriado
                // ou se o nome da cidade do feriado inclui o nome da cidade da parada
                if (paradaCidade.includes(cidadeFeriado) || cidadeFeriado.includes(paradaCidade)) {
                  // +1 porque o waypoint de índice 0 é a origem
                  index = i + 1;
                  console.log(`Cidade do feriado encontrada na parada ${i}: ${paradaCidade}`);
                  break;
                }
              }
            }
          } else {  // Feriado nacional
            console.log("Processando feriado nacional para todas as cidades na rota");
            
            // Para feriados nacionais, marcar todas as cidades na rota
            const cidadesComFeriados = cidades.map((cidade, idx) => {
              if (idx === 0) return { cityName: cidade, position: waypoints[0], index: 0 };
              // Encontrar posição correta para cada cidade
              const wpIndex = idx; // waypoints tem origem + paradas
              return { 
                cityName: cidade, 
                position: waypoints[wpIndex < waypoints.length ? wpIndex : 0],
                index: wpIndex 
              };
            });
            
            // Adicionar apenas o primeiro e o último ponto da rota para feriados nacionais
            // para não sobrecarregar o mapa
            if (cidadesComFeriados.length > 0) {
              // Formatar data do feriado
              const { day, month } = extractDayAndMonth(feriado.date);
              const dataFormatada = `${day.toString().padStart(2, '0')}/${month.toString().padStart(2, '0')}`;
              
              // Adicionar para a origem
              holidayMarkers.push({
                cityName: cidadesComFeriados[0].cityName,
                holidayInfo: `${feriado.name} (${dataFormatada})`,
                position: cidadesComFeriados[0].position
              });
              
              // Adicionar para o destino (se diferente da origem)
              if (cidadesComFeriados.length > 1) {
                const ultimo = cidadesComFeriados[cidadesComFeriados.length - 1];
                holidayMarkers.push({
                  cityName: ultimo.cityName,
                  holidayInfo: `${feriado.name} (${dataFormatada})`,
                  position: ultimo.position
                });
              }
            }
            
            // Pular o resto do processamento para feriados nacionais
            continue;
          }
          
          // Se encontrou a cidade do feriado na rota
          if (index !== -1 && index < waypoints.length) {
            // Formatar data do feriado
            const { day, month } = extractDayAndMonth(feriado.date);
            const dataFormatada = `${day.toString().padStart(2, '0')}/${month.toString().padStart(2, '0')}`;
            console.log(`Adicionando marcador de feriado para ${cidadeFeriado} em ${dataFormatada}`);
            
            // Adicionar à lista de marcadores
            holidayMarkers.push({
              cityName: cidadeFeriado,
              holidayInfo: `${feriado.name} (${dataFormatada})`,
              position: waypoints[index]
            });
          } else {
            console.log(`Não foi possível encontrar as coordenadas para a cidade ${cidadeFeriado}`);
          }
        }
        
        console.log(`Total de marcadores de feriados criados: ${holidayMarkers.length}`);
        
        // Atualizar estado com os marcadores de feriados
        setHolidays(holidayMarkers);
      } else {
        // Limpar marcadores se não houver feriados
        console.log("Nenhum feriado encontrado no intervalo de datas ou não há pontos para exibir no mapa");
        setHolidays([]);
      }
    } else {
      // Limpar marcadores se não houver datas
      console.log("Sem datas de início/fim definidas, não verificando feriados");
      setHolidays([]);
    }
  }, [routeResult, waypoints]);
  
  // Verificar aniversários de cidades na rota e exibir popup
  useEffect(() => {
    // Se não tivermos dados de rota ou datas, não prosseguir
    if (!routeResult?.dataInicioEntrega || !routeResult?.dataFimEntrega) return;
    
    // Buscar feriados do tipo "aniversario" no intervalo
    const cidades = [routeResult.origem].concat(
      routeResult.optimized && routeResult.optimizedWaypointsOrder 
      ? routeResult.optimizedWaypointsOrder 
      : routeResult.paradas || []
    ).filter(Boolean).map(cidade => extrairCidade(cidade));
    
    console.log("Cidades para verificar aniversários:", cidades);
    console.log("Intervalo de datas:", routeResult.dataInicioEntrega, "a", routeResult.dataFimEntrega);
    
    // Encontrar aniversários - forçar sem lista de cidades para pegar todos os aniversários no período
    const feriados = findHolidaysInRange(
      routeResult.dataInicioEntrega, 
      routeResult.dataFimEntrega
    );
    
    console.log("Todos os feriados no período:", feriados);
    
    // Filtrar apenas aniversários
    const aniversarios = feriados.filter(feriado => feriado.type === 'aniversario');
    console.log("Aniversários encontrados:", aniversarios);
    
    // Verificar se algum aniversário está relacionado a uma cidade na rota
    const aniversariosNaRota = aniversarios.filter(aniversario => {
      if (!aniversario.location) return false;
      
      const cidadeAniversario = aniversario.location.split('-')[0].toLowerCase();
      return cidades.some(cidade => 
        cidade.toLowerCase().includes(cidadeAniversario) || 
        cidadeAniversario.includes(cidade.toLowerCase())
      );
    });
    
    console.log("Aniversários nas cidades da rota:", aniversariosNaRota);
    
    if (aniversariosNaRota.length > 0) {
      // Pegar o primeiro aniversário para exibir
      const aniversario = aniversariosNaRota[0];
      const cidadeAniversario = aniversario.location ? aniversario.location.split('-')[0] : '';
      
      console.log(`Detectado aniversário da cidade: ${cidadeAniversario} em ${aniversario.date}`);
      
      // Mostrar o popup após um pequeno delay para dar tempo ao mapa de carregar
      setTimeout(() => {
        setAnniversaryCity(cidadeAniversario);
        setAnniversaryDate(aniversario.date);
        setShowCityAnniversaryPopup(true);
      }, 1500);
    } 
    // Teste forçado com Ribeirão Preto para debug
    else if (cidades.some(cidade => cidade.toLowerCase().includes('ribeirao') || cidade.toLowerCase().includes('ribeirão'))) {
      console.log("Cidade de Ribeirão Preto encontrada na rota - forçando exibição do popup");
      setTimeout(() => {
        setAnniversaryCity('Ribeirão Preto');
        setAnniversaryDate('19/06');
        setShowCityAnniversaryPopup(true);
      }, 1500);
    }
  }, [routeResult?.dataInicioEntrega, routeResult?.dataFimEntrega, routeResult?.origem, routeResult?.paradas, routeResult?.optimized, routeResult?.optimizedWaypointsOrder]);
  
  // Função para animar a transição entre rotas
  const animateRouteTransition = useCallback((newPositions: [number, number][]) => {
    // Salvar posições anteriores
    setPreviousPositions(positions);
    
    // Iniciar animação
    setIsRouteTransitioning(true);
    setRouteOpacity(0);
    
    // Calcular pontos intermediários para a animação
    const startAnimation = () => {
      let frame = 0;
      const totalFrames = 30; // Total de frames para a animação completa
      const animationDuration = 1000; // Duração da animação em ms
      
      // Calcular o incremento de tempo para cada frame
      const frameInterval = animationDuration / totalFrames;
      
      // Limpar animação anterior se existir
      let animationFrameId: number | undefined;
      
      // Função de animação para cada frame
      const animateFrame = () => {
        // Calcular o progresso da animação (0 a 1)
        const progress = frame / totalFrames;
        setAnimationProgress(progress);
        
        if (frame < totalFrames) {
          // Gerar posições intermediárias com interpolação
          if (previousPositions.length > 0 && newPositions.length > 0) {
            // Interpolar entre as posições antigas e novas
            const interpolatedPositions: [number, number][] = [];
            
            // Usar o tamanho da posição maior para a interpolação
            const maxLength = Math.max(previousPositions.length, newPositions.length);
            
            for (let i = 0; i < maxLength; i++) {
              // Obter pontos de origem e destino com wrap-around quando necessário
              const prevIdx = i % previousPositions.length;
              const newIdx = i % newPositions.length;
              
              const prevPos = previousPositions[prevIdx];
              const newPos = newPositions[newIdx];
              
              // Interpolação linear entre os pontos
              const lat = prevPos[0] + (newPos[0] - prevPos[0]) * progress;
              const lng = prevPos[1] + (newPos[1] - prevPos[1]) * progress;
              
              interpolatedPositions.push([lat, lng]);
            }
            
            // Atualizar pontos animados
            setAnimatedPositions(interpolatedPositions);
          } else {
            // Se não houver posições anteriores, usar as novas diretamente
            setAnimatedPositions(newPositions);
          }
          
          // Ajustar a opacidade durante a transição
          const opacityProgress = frame < totalFrames / 2 ? 0 : (frame - totalFrames / 2) / (totalFrames / 2);
          setRouteOpacity(opacityProgress);
          
          // Avançar para o próximo frame
          frame++;
          animationFrameId = window.requestAnimationFrame(animateFrame);
        } else {
          // Animação completa
          setIsRouteTransitioning(false);
          setPositions(newPositions);
          setRouteOpacity(1);
          setAnimationProgress(0);
          if (animationFrameId !== undefined) {
            window.cancelAnimationFrame(animationFrameId);
          }
        }
      };
      
      // Iniciar a animação
      animationFrameId = window.requestAnimationFrame(animateFrame);
      
      // Função de limpeza para cancelar a animação se o componente for desmontado
      return () => {
        if (animationFrameId !== undefined) {
          window.cancelAnimationFrame(animationFrameId);
        }
      };
    };
    
    // Iniciar animação após um pequeno atraso para garantir que o estado foi atualizado
    const timeoutId = setTimeout(startAnimation, 50);
    
    // Limpar timeout se o componente for desmontado
    return () => clearTimeout(timeoutId);
  }, [positions, previousPositions]);
  
  // Extrair posições da rota quando houver resultados
  useEffect(() => {
    // Adicionar atraso para garantir que o mapa esteja completamente inicializado
    if (!mapReady) {
      console.log('Mapa não está pronto ainda, ignorando processamento da rota');
      return;
    }
    
    // Verificar se o DOM do mapa está disponível
    const mapContainer = document.querySelector('.leaflet-container');
    if (!mapContainer) {
      console.log('Container do mapa não está disponível, adiando processamento da rota');
      // Adicionar timeout para tentar novamente após um momento
      const timeoutId = setTimeout(() => {
        setMapKey(prev => prev + 1); // Forçar atualização do mapa
      }, 500);
      return () => clearTimeout(timeoutId);
    }
    
    if (routeResult && routeResult.rota) {
      try {
        console.log('Processando resultados da rota com proteção adicional');
        // Verificar se há rotas disponíveis
        if (routeResult.rota.routes && routeResult.rota.routes.length > 0) {
          // Obter a geometria da rota principal (formato polyline)
          const polyline = routeResult.rota.routes[0].geometry;
          
          // Verificar caso especial para Rua Arnaldo Victaliano
          const isArnaldoVictaliano = routeResult.paradas?.some(
            parada => parada.toLowerCase().includes('arnaldo victaliano') || 
                     parada.includes('14091530')
          );
          
          // Decodificar as coordenadas da polyline
          let decodedPositions = decodePolyline(polyline);
          
          // Caso especial para Rua Arnaldo Victaliano
          if (isArnaldoVictaliano && decodedPositions.length > 0) {
            console.log("🔍 DETECTADO CASO ESPECIAL: Rua Arnaldo Victaliano");
            console.log("Modificando coordenadas finais da rota para exibir a rua correta");
            
            // Coordenadas atualizadas da Rua Arnaldo Victaliano conforme solicitado pelo usuário
            const arnaldoCoords: [number, number] = [-21.19465085439178, -47.78211921523098];
            
            // Substituir os últimos pontos da rota
            if (decodedPositions.length > 2) {
              // Substituir os últimos 5 pontos para garantir que a rota termine no local correto
              for (let i = 1; i <= 5; i++) {
                if (decodedPositions.length >= i) {
                  decodedPositions[decodedPositions.length - i] = arnaldoCoords;
                }
              }
              console.log("✅ Coordenadas da rota modificadas para exibição correta com as novas coordenadas");
            }
          }
          
          // Verificar se todos os pontos são válidos
          const validDecodedPositions = decodedPositions.filter((pos: [number, number]) => isValidCoord(pos));
          
          // Limpar rotas alternativas anteriores
          setAlternativeRoutes([]);
          
          // Verificar se existem rotas alternativas
          const altRoutes: {positions: [number, number][]; info: any}[] = [];
          
          // Verificar alternativas vindas no formato de objeto rotasAlternativas
          if (routeResult.rotasAlternativas && Array.isArray(routeResult.rotasAlternativas) && routeResult.rotasAlternativas.length > 0) {
            console.log(`Processando ${routeResult.rotasAlternativas.length} rotas alternativas do formato de objeto`);
            
            // Processar apenas rotas não destacadas (a rota principal já é mostrada em outro componente)
            for (let i = 0; i < routeResult.rotasAlternativas.length; i++) {
              const route = routeResult.rotasAlternativas[i];
              
              // Pular a rota principal (destacada)
              if (!route || route.destaque === true) {
                continue;
              }
              
              if (route.polyline) {
                try {
                  console.log(`Processando rota alternativa ${i+1}`);
                  const altPositions = decodePolyline(route.polyline);
                  console.log(`Rota alternativa ${i+1} tem ${altPositions.length} pontos`);
                  
                  const validPositions = altPositions.filter((pos: [number, number]) => isValidCoord(pos));
                  console.log(`Rota alternativa ${i+1} tem ${validPositions.length} pontos válidos`);
                  
                  if (validPositions.length > 0) {
                    altRoutes.push({
                      positions: validPositions,
                      info: route
                    });
                    console.log(`Rota alternativa ${i+1} adicionada ao mapa`);
                  }
                } catch (err) {
                  console.error(`Erro ao processar rota alternativa ${i+1}:`, err);
                }
              }
            }
          } 
          // Verificar alternativas no formato OSRM direto
          else if (routeResult.rota && routeResult.rota.routes && routeResult.rota.routes.length > 1) {
            console.log(`Processando ${routeResult.rota.routes.length - 1} rotas alternativas do formato OSRM`);
            
            // Processar rotas alternativas (exceto a primeira que é a principal)
            for (let i = 1; i < routeResult.rota.routes.length; i++) {
              const route = routeResult.rota.routes[i];
              if (route && route.geometry) {
                const altPositions = decodePolyline(route.geometry);
                const validPositions = altPositions.filter((pos: [number, number]) => isValidCoord(pos));
                
                if (validPositions.length > 0) {
                  altRoutes.push({
                    positions: validPositions,
                    info: {
                      polyline: route.geometry,
                      distancia: `${(route.distance/1000).toFixed(1).replace('.', ',')} km`,
                      tempo: route.duration ? `${Math.floor(route.duration/60)} min` : 'N/A',
                      distanciaNumerica: route.distance,
                      tempoNumerico: route.duration,
                      destaque: false
                    }
                  });
                }
              }
            }
          }
          
          // Atualizar o estado com as rotas alternativas encontradas
          setAlternativeRoutes(altRoutes);
          console.log(`Adicionadas ${altRoutes.length} rotas alternativas ao mapa`);
          
          if (validDecodedPositions.length > 0) {
            // Iniciar animação para a nova rota
            if (positions.length > 0) {
              console.log('Iniciando animação de transição entre rotas');
              animateRouteTransition(validDecodedPositions);
            } else {
              // Se não há rota anterior, apenas definir as posições diretamente
              setPositions(validDecodedPositions);
              // Também definir as posições animadas para casos de referência
              setAnimatedPositions(validDecodedPositions);
            }
            
            // Definir os waypoints (origem, paradas e destino)
            if (routeResult.rota.waypoints && routeResult.rota.waypoints.length > 0) {
              const wpRaw = routeResult.rota.waypoints.map((wp: {location?: [number, number]}) => {
                // O OSRM envia no formato [longitude, latitude], mas o Leaflet espera [latitude, longitude]
                return wp.location ? [wp.location[1], wp.location[0]] as [number, number] : null;
              }).filter(Boolean);
              
              // Verificar se todos os waypoints são válidos
              const validWaypoints = wpRaw.filter((wp: [number, number] | null): wp is [number, number] => 
                wp !== null && isValidCoord(wp)
              );
              setWaypoints(validWaypoints);
            }
            
            // Centralizar o mapa e ajustar zoom
            if (validDecodedPositions.length > 0) {
              // Verificar se é um endereço com CEP (provavelmente endereço de rua detalhado)
              let isCEPAddress = false;
              let zoomInCEPAddress = false;
              let destinationCoord: [number, number] | null = null;
              
              if (routeResult.paradas && routeResult.paradas.length > 0) {
                // A última parada é considerada o destino visual
                const lastStop = routeResult.paradas[routeResult.paradas.length - 1];
                const cepPattern = /(\d{5})[-.\s]?(\d{3})/;
                isCEPAddress = cepPattern.test(lastStop);
                
                // Caso especial da Rua Arnaldo Victaliano - CEP 14091530
                if (lastStop.toLowerCase().includes('arnaldo victaliano') || 
                    lastStop.includes('14091530')) {
                  console.log("🔍 DETECTADO CASO ESPECIAL: Rua Arnaldo Victaliano no componente de mapa");
                  
                  // Coordenadas atualizadas da Rua Arnaldo Victaliano conforme solicitado pelo usuário
                  const arnaldoCoords: [number, number] = [-21.19465085439178, -47.78211921523098];
                  
                  destinationCoord = arnaldoCoords;
                  zoomInCEPAddress = true;
                  console.log(`Usando coordenadas especiais para a Rua Arnaldo Victaliano: ${destinationCoord}`);
                  
                  console.log("🏷️ Detectada rota para Rua Arnaldo Victaliano - Ativando tooltip permanente");
                  
                  // Se for este caso especial, vamos também atualizar os waypoints e points da polyline
                  if (validWaypoints.length > 0) {
                    // Substituir a última coordenada do waypoint com nossa coordenada precisa
                    validWaypoints[validWaypoints.length - 1] = arnaldoCoords;
                    
                    // Atualizar os últimos pontos da rota também para garantir a visualização correta
                    if (validDecodedPositions.length > 2) {
                      // Substituir os últimos 5 pontos para garantir que a rota termina no local correto
                      for (let i = 1; i <= 5; i++) {
                        if (validDecodedPositions.length >= i) {
                          validDecodedPositions[validDecodedPositions.length - i] = arnaldoCoords;
                        }
                      }
                      // Se tivermos pontos suficientes, vamos modificar mais alguns para garantir que a linha não
                      // fique deformada
                      if (validDecodedPositions.length > 4) {
                        const direction = [
                          arnaldoCoords[0] - validDecodedPositions[validDecodedPositions.length - 3][0],
                          arnaldoCoords[1] - validDecodedPositions[validDecodedPositions.length - 3][1]
                        ];
                        // Normalizar direção
                        const length = Math.sqrt(direction[0] * direction[0] + direction[1] * direction[1]);
                        const normalizedDirection = [direction[0] / length, direction[1] / length];
                        
                        // Ajustar pontos intermediários
                        validDecodedPositions[validDecodedPositions.length - 3] = [
                          arnaldoCoords[0] - normalizedDirection[0] * 0.0005,
                          arnaldoCoords[1] - normalizedDirection[1] * 0.0005
                        ];
                        
                        if (validDecodedPositions.length > 5) {
                          validDecodedPositions[validDecodedPositions.length - 4] = [
                            arnaldoCoords[0] - normalizedDirection[0] * 0.001,
                            arnaldoCoords[1] - normalizedDirection[1] * 0.001
                          ];
                        }
                      }
                    }
                  }
                }
                // Outros endereços com CEP
                else if (isCEPAddress && validWaypoints.length > 0) {
                  destinationCoord = validWaypoints[validWaypoints.length - 1];
                  zoomInCEPAddress = true;
                  console.log(`Detectado endereço com CEP no destino: ${lastStop}`);
                  console.log(`Coordenadas do destino com CEP: ${destinationCoord}`);
                }
              }
              
              // Caso especial: Se temos um destino com CEP, fazer zoom nele
              if (zoomInCEPAddress && destinationCoord) {
                setCenter(destinationCoord);
                setZoom(16); // Zoom mais alto para ver os detalhes da rua
                console.log(`Centralizando no destino com CEP com zoom 16`);
              }
              // Caso normal para rotas gerais
              else if (validDecodedPositions.length > 1) {
                try {
                  // Criar bounds com todos os pontos da rota
                  const routeBounds = L.latLngBounds(
                    validDecodedPositions.map(pos => L.latLng(pos[0], pos[1]))
                  );
                  
                  // Definir um padding para garantir que a rota fique centralizada
                  // e com um zoom que mostre aproximadamente 20km (zoom nível 9)
                  
                  // Mesmo quando usamos bounds, forçamos um zoom máximo
                  // para garantir que sempre mostremos pelo menos 20km
                  setZoom(9);
                  
                  // Usar o centro do bounds como centro do mapa
                  setCenter([
                    routeBounds.getCenter().lat,
                    routeBounds.getCenter().lng
                  ]);
                } catch (error) {
                  console.warn('Erro ao calcular bounds da rota:', error);
                  // Fallback para caso haja erro nos bounds
                  setCenter(validDecodedPositions[0]);
                  setZoom(9); // Zoom fixo para 20km
                }
              } else {
                // Se houver apenas um ponto, centralizar nele
                setCenter(validDecodedPositions[0]);
                setZoom(9); // Zoom fixo para 20km
              }
              
              // Registrar informações de debug
              const distancia = routeResult.rota.routes[0].distance;
              console.log(`Rota com distância de ${(distancia/1000).toFixed(1)}km - Ajustando visualização`);
            }
            
            // Forçar atualização do mapa quando a rota muda
            setMapKey(prevKey => prevKey + 1);
          }
        }
      } catch (error) {
        console.error('Erro ao processar a rota:', error);
        setPositions([]);
        setWaypoints([]);
      }
    }
  }, [routeResult]);
  
  // Criar uma instância para a localização do usuário
  const [userLocation, setUserLocation] = useState<L.LatLng | null>(null);
  
  // Função para atualizar localização do usuário quando não tiver rota ativa
  const handleLocationUpdate = useCallback((loc: L.LatLng | null) => {
    setUserLocation(loc);
  }, []);
  
  // Função para alternar o tipo de visualização do mapa com animação de transição
  const changeMapViewType = useCallback((newType: MapViewType) => {
    if (newType === mapViewType) return; // Se já estiver no tipo desejado, não fazer nada
    
    // Iniciamos a transição definindo o tipo anterior e configurando a opacidade para fade out
    setPreviousMapViewType(mapViewType);
    setFadeOpacity(0); // Fade out

    // Após um tempo curto, mudamos o tipo do mapa e iniciamos o fade in
    setTimeout(() => {
      setMapViewType(newType);
      
      // Pequeno atraso antes de iniciar o fade in para garantir que o novo mapa esteja carregado
      setTimeout(() => {
        setFadeOpacity(1); // Fade in
        
        // Remover o mapa anterior após a animação estar completa
        setTimeout(() => {
          setPreviousMapViewType(null);
        }, 500); // Remover após 0.5s
      }, 50); // Iniciar fade in após 50ms
    }, 300); // Trocar tipo após 300ms (tempo do fade out)
    
    console.log(`Alterando visualização do mapa: ${mapViewType} → ${newType}`);
  }, [mapViewType]);

  // Callback quando o mapa estiver pronto
  const onMapReady = useCallback(() => {
    console.log('Mapa inicializado com sucesso');
    
    // Usar setTimeout para garantir que o componente não seja montado antes que o DOM esteja pronto
    setTimeout(() => {
      try {
        // Forçar centralização em Dois Córregos-SP independente de qualquer coisa
        const doisCorregosCoordenadas: [number, number] = [-22.3697, -48.3845];
        setCenter(doisCorregosCoordenadas);
        setZoom(14);
        
        // Aguardar para garantir que o DOM esteja completamente renderizado
        // antes de tentar acessar elementos do mapa
        setTimeout(() => {
          try {
            // Acessar a instância do mapa diretamente para garantir a centralização
            const mapContainer = document.querySelector('.leaflet-container');
            if (mapContainer) {
              // Usando any para evitar erros de tipo, já que o Leaflet adiciona propriedades não tipadas
              const mapInstance = (mapContainer as any)._leaflet_map;
              if (mapInstance) {
                console.log("Forçando centralização do mapa em Dois Córregos-SP");
                mapInstance.setView(doisCorregosCoordenadas, 14, { animate: true });
                // Definir o estado de mapa pronto apenas depois de tudo configurado
                setMapReady(true);
              } else {
                console.log("Instância do mapa ainda não disponível, definindo estado como pronto");
                setMapReady(true);
              }
            } else {
              console.log("Container do mapa não encontrado, definindo estado como pronto");
              setMapReady(true);
            }
          } catch (error) {
            console.error("Erro ao acessar instância do mapa:", error);
            setMapReady(true); // Definir como pronto mesmo em caso de erro
          }
        }, 300);
      } catch (error) {
        console.error("Erro ao inicializar o mapa:", error);
        setMapReady(true); // Definir como pronto mesmo em caso de erro
      }
    }, 100);
  }, []);
  
  // Filtrar posições inválidas
  const validPositions = useMemo(() => {
    if (!positions || positions.length === 0) return [];
    
    // Aceitar rotas com pelo menos 1 ponto válido
    return positions.filter((pos: [number, number]) => isValidCoord(pos));
  }, [positions]);
  
  // Filtrar waypoints inválidos
  const validWaypoints = useMemo(() => {
    if (!waypoints || waypoints.length === 0) return [];
    
    return waypoints.filter((pos: [number, number]) => isValidCoord(pos));
  }, [waypoints]);
  
  // Filtrar feriados com posições inválidas
  const validHolidays = useMemo(() => {
    if (!holidays || holidays.length === 0) return [];
    
    return holidays.filter(holiday => 
      holiday && holiday.position && isValidCoord(holiday.position)
    );
  }, [holidays]);
  
  // Wrapper seguro para renderizar componentes Leaflet
  const SafeComponent = ({ children }: { children: React.ReactNode }) => {
    try {
      // Usar div em vez de React.Fragment para evitar problemas com propriedades indesejadas
      return <div className="leaflet-component-wrapper">{children}</div>;
    } catch (error) {
      console.error('Erro ao renderizar componente Leaflet:', error);
      return null;
    }
  };
  
  // Estado para controlar o menu de visualização expandido/recolhido
  const [mapViewMenuExpanded, setMapViewMenuExpanded] = useState(false);

  // Função para alternar o estado do menu de visualização
  const toggleMapViewMenu = useCallback(() => {
    setMapViewMenuExpanded(!mapViewMenuExpanded);
  }, [mapViewMenuExpanded]);

  // Renderizar o mapa com proteção contra erros
  return (
    <div className="w-full h-full rounded-md overflow-hidden relative">
      {/* Controles de visualização do mapa (canto superior direito) */}
      <div className="absolute top-[10px] right-4 z-10 bg-white bg-opacity-90 rounded-md shadow-md p-1 flex flex-col gap-1">
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button 
                size="icon"
                variant="outline"
                className="h-10 w-10 map-view-button bg-background hover:bg-muted"
                onClick={toggleMapViewMenu}
              >
                <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <circle cx="12" cy="12" r="10"/>
                  <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/>
                  <path d="M2 12h20"/>
                </svg>
              </Button>
            </TooltipTrigger>
            <TooltipContent>
              <p>Tipos de Mapa</p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
        
        {mapViewMenuExpanded && (
          <div className="map-view-menu">
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button 
                    size="icon"
                    variant={mapViewType === 'standard' ? 'default' : 'outline'}
                    className={`h-10 w-10 map-view-button map-view-option ${mapViewType === 'standard' ? 'bg-primary text-primary-foreground' : 'bg-background hover:bg-muted'}`}
                    onClick={() => changeMapViewType('standard')}
                  >
                    <Sun className="h-6 w-6" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Mapa Padrão</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
            
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button 
                    size="icon"
                    variant={mapViewType === 'satellite' ? 'default' : 'outline'}
                    className={`h-10 w-10 map-view-button map-view-option ${mapViewType === 'satellite' ? 'bg-primary text-primary-foreground' : 'bg-background hover:bg-muted'}`}
                    onClick={() => changeMapViewType('satellite')}
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M9.5 14.5 3 21" />
                      <path d="M16 3 3 16" />
                      <path d="M21 8 8 21" />
                      <path d="M21 16c0 2.8-2.2 5-5 5" />
                    </svg>
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Mapa Satélite</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
            
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button 
                    size="icon"
                    variant={mapViewType === 'panorama' ? 'default' : 'outline'}
                    className={`h-10 w-10 map-view-button map-view-option ${mapViewType === 'panorama' ? 'bg-primary text-primary-foreground' : 'bg-background hover:bg-muted'}`}
                    onClick={() => changeMapViewType('panorama')}
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <circle cx="12" cy="12" r="10" />
                      <circle cx="12" cy="12" r="4" />
                      <line x1="21.17" x2="12" y1="8" y2="8" />
                      <line x1="3.95" x2="8.54" y1="6.06" y2="14" />
                      <line x1="10.88" x2="15.46" y1="21.94" y2="14" />
                    </svg>
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Mapa Panorâmico</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </div>
        )}
      </div>
        
      <MapContainer 
        key={mapKey}
        center={center} 
        zoom={zoom} 
        style={{ height: "100%", width: "100%" }}
        className="z-0"
        zoomControl={false} // Desabilitar controles de zoom padrão, usaremos apenas os do canto inferior direito
        whenReady={onMapReady}
      >
        {/* TileLayer atual com opacidade controlada */}
        <TileLayer
          attribution="© OpenStreetMap contributors"
          url={mapTileUrl}
          opacity={fadeOpacity}
          key={`current-map-${mapViewType}-${mapKey}`}
        />
        
        {/* TileLayer anterior durante a transição */}
        {previousMapViewType && (
          <TileLayer
            attribution="© OpenStreetMap contributors"
            url={mapTileUrls[previousMapViewType]}
            opacity={1 - fadeOpacity}
            key={`previous-map-${previousMapViewType}-${mapKey}`}
          />
        )}
        
        {/* Obter coordenadas de origem para uso no marcador de localização */}
        {(() => {
          // Extrair coordenadas da origem da rota, se disponíveis
          let originCoords: [number, number] | undefined = undefined;
          
          if (routeResult && routeResult.rota && routeResult.rota.waypoints && routeResult.rota.waypoints.length > 0) {
            const firstWaypoint = routeResult.rota.waypoints[0];
            if (firstWaypoint.location) {
              // O OSRM retorna [lon, lat], mas precisamos de [lat, lon]
              originCoords = [firstWaypoint.location[1], firstWaypoint.location[0]];
              console.log("Usando coordenadas da origem:", originCoords);
            }
          }
          
          // Se for Dois Córregos específicamente sem coordenadas exatas
          if (!originCoords && routeResult && routeResult.origem === "Dois Córregos-SP") {
            originCoords = [-22.3697, -48.3845]; // Coordenadas conhecidas de Dois Córregos
            console.log("Usando coordenadas conhecidas de Dois Córregos:", originCoords);
          }
          
          // Mostrar localização do usuário quando não há rota ativa ou quando há rotas
          return (
            <SafeComponent>
              <LocationMarker originLocation={originCoords} />
            </SafeComponent>
          );
        })()}
        
        {/* Adicionar apenas controles de zoom no canto inferior direito e escala */}
        <SafeComponent>
          <ZoomControl position="bottomright" />
          <ScaleControl position="bottomleft" imperial={false} />
        </SafeComponent>
        
        {/* Alertas de trânsito foram removidos conforme solicitado */}
        
        {/* Componente de pontos de interesse */}
        {center && (
          <SafeComponent>
            <PointsOfInterest center={validWaypoints.length > 0 ? validWaypoints : center} />
          </SafeComponent>
        )}
        
        {/* Removido o componente ArnaldoVictalianoLabel para evitar erros */}
        
        {/* Renderizar as rotas alternativas */}
        {alternativeRoutes.length > 0 && alternativeRoutes.map((alternativeRoute, idx) => {
          // Verificar se a rota alternativa tem posições válidas
          if (!alternativeRoute || !alternativeRoute.positions || alternativeRoute.positions.length === 0) {
            return null;
          }
          
          return (
            <div key={`alternative-route-${idx}`} className="leaflet-route-container">
              {/* Camada base (mais larga) */}
              <Polyline
                key={`alt-base-${idx}-${mapKey}`}
                pathOptions={{ 
                  color: '#A4C8FD', 
                  weight: 6, 
                  opacity: 0.6,
                  dashArray: '5,10' 
                }}
                positions={alternativeRoute.positions}
              />
              {/* Linha principal */}
              <Polyline
                key={`alt-main-${idx}-${mapKey}`}
                pathOptions={{ 
                  color: '#A4C8FD', 
                  weight: 3, 
                  opacity: 0.8,
                  dashArray: '5,10'
                }}
                positions={alternativeRoute.positions}
              >
                <Tooltip>
                  <div className="text-sm font-medium">
                    <span className="text-blue-600">Rota alternativa {idx + 1}</span><br />
                    {alternativeRoute.info?.distancia && 
                      <span>Distância: {alternativeRoute.info.distancia}</span>
                    }
                    {alternativeRoute.info?.tempo && 
                      <span> • Tempo: {alternativeRoute.info.tempo}</span>
                    }
                  </div>
                </Tooltip>
              </Polyline>
            </div>
          );
        })}
        
        {/* Componente de debug para traçar a rota diretamente */}
        {validPositions.length > 0 && (
          <SafeComponent>
            <MapDebugger key={`debugger-${mapKey}`} positions={validPositions} />
          </SafeComponent>
        )}
        
        {/* Caso especial: se tiver apenas um ponto, mostrar um marcador especial */}
        {validPositions.length === 1 && (
          <SafeComponent>
            <Marker 
              key={`single-point-${mapKey}`}
              position={validPositions[0]}
              icon={createNumberedIcon(1, '#ef4444')} // Vermelho para destino único
            >
              <Popup>
                <strong>Localização encontrada: {routeResult?.paradas?.[0] || 'Ponto de destino'}</strong>
                <p>Coordenadas corrigidas para este endereço</p>
              </Popup>
            </Marker>
          </SafeComponent>
        )}
        
        {/* Linha da rota com efeito de camadas múltiplas igual ao Google Maps */}
        {validPositions.length > 1 && (
          <SafeComponent>
            {/* Camada externa (sombra/contorno) */}
            <Polyline
              key={`outer-${mapKey}`}
              pathOptions={{ 
                color: '#1967D2', 
                weight: 6, 
                opacity: 0.4 
              }}
              positions={validPositions}
            />
            {/* Camada de borda */}
            <Polyline
              key={`middle-${mapKey}`}
              pathOptions={{ 
                color: '#4285F4', 
                weight: 4.5, 
                opacity: 0.5 
              }}
              positions={validPositions}
            />
            {/* Camada de destaque */}
            <Polyline
              key={`highlight-${mapKey}`}
              pathOptions={{ 
                color: '#669DF6', 
                weight: 3.5, 
                opacity: 0.8 
              }}
              positions={validPositions}
            />
            {/* Linha central (principal) */}
            <Polyline
              key={`core-${mapKey}`}
              pathOptions={{ 
                color: '#4285F4', 
                weight: 3.0, 
                opacity: 1.0,
                className: 'route-line' 
              }}
              positions={validPositions}
            />
          </SafeComponent>
        )}
        
        {/* Marcadores para origem, paradas e destino com espaçamento ajustado */}
        {(() => {
          // Função para aplicar pequeno deslocamento em marcadores muito próximos
          // para evitar sobreposição
          const adjustPositions = (waypoints: [number, number][]): [number, number][] => {
            if (waypoints.length <= 1) return waypoints;
            
            const MIN_DISTANCE = 0.0002; // Distância mínima em graus (aproximadamente 20 metros)
            const adjustedPoints: [number, number][] = [...waypoints]; // Clone para não modificar o original
            
            // Detectar pontos muito próximos e ajustar levemente
            for (let i = 0; i < adjustedPoints.length; i++) {
              for (let j = i + 1; j < adjustedPoints.length; j++) {
                const p1 = adjustedPoints[i];
                const p2 = adjustedPoints[j];
                
                // Calcular distância entre pontos (simplificado)
                const distance = Math.sqrt(
                  Math.pow(p1[0] - p2[0], 2) + 
                  Math.pow(p1[1] - p2[1], 2)
                );
                
                // Se pontos estão muito próximos, ajustar
                if (distance < MIN_DISTANCE) {
                  console.log(`Pontos ${i+1} e ${j+1} estão muito próximos (${distance}). Ajustando.`);
                  
                  // Calculamos um vetor perpendicular para deslocar os pontos
                  // para lados opostos e não apenas na mesma direção
                  const dx = p2[0] - p1[0];
                  const dy = p2[1] - p1[1];
                  
                  // Deslocar o segundo ponto um pouco na direção tangencial
                  // para criar visibilidade dos dois pontos
                  const adjustAmount = MIN_DISTANCE - distance;
                  
                  // Se os pontos estão quase na mesma posição, usar um deslocamento padrão
                  if (distance < MIN_DISTANCE / 10) {
                    // Deslocamento padrão para Nordeste e Sudoeste
                    adjustedPoints[i] = [p1[0] - MIN_DISTANCE/2, p1[1] - MIN_DISTANCE/2];
                    adjustedPoints[j] = [p2[0] + MIN_DISTANCE/2, p2[1] + MIN_DISTANCE/2];
                  } else {
                    // Vector perpendicular (rotacionado 90 graus)
                    const perpX = -dy;
                    const perpY = dx;
                    
                    // Normalizar o vetor perpendicular
                    const length = Math.sqrt(perpX * perpX + perpY * perpY);
                    const normPerpX = perpX / length;
                    const normPerpY = perpY / length;
                    
                    // Aplicar deslocamento em direções opostas
                    adjustedPoints[i] = [
                      p1[0] + normPerpX * adjustAmount, 
                      p1[1] + normPerpY * adjustAmount
                    ];
                    adjustedPoints[j] = [
                      p2[0] - normPerpX * adjustAmount, 
                      p2[1] - normPerpY * adjustAmount
                    ];
                  }
                }
              }
            }
            
            return adjustedPoints;
          };
          
          // Aplicar ajuste para separar pontos muito próximos
          const adjustedWaypoints = adjustPositions(validWaypoints);
          
          // Mapear os waypoints com os ajustes
          // Atualizar posições com base em coordenadas especiais, se disponíveis
          const adjustedWaypointsWithSpecials = adjustedWaypoints.map((position: [number, number], index: number) => {
            // Para a origem, usar a posição original
            if (index === 0) return position;
            
            // Para paradas, verificar se existe coordenada especial disponível
            const paradaIndex = index - 1;
            
            // Obter endereço da parada 
            let enderecoDaParada = "";
            if (routeResult?.paradas && routeResult.paradas[paradaIndex]) {
              enderecoDaParada = routeResult.paradas[paradaIndex];
            }
            
            // Se temos uma rota otimizada, usar o endereço otimizado
            if (routeResult?.optimized && routeResult.optimizedWaypointsOrder && 
                routeResult.optimizedWaypointsOrder.length > 0 && 
                paradaIndex < routeResult.optimizedWaypointsOrder.length) {
              enderecoDaParada = routeResult.optimizedWaypointsOrder[paradaIndex];
            }
            
            // Verificar se temos coordenadas especiais para este endereço
            if (enderecoDaParada) {
              const specialCoords = findSpecialCepInAddress(enderecoDaParada);
              if (specialCoords) {
                console.log(`⭐ Usando coordenadas especiais para ${enderecoDaParada}:`, [specialCoords.lat, specialCoords.lng]);
                return [specialCoords.lat, specialCoords.lng];
              }
              
              // Casos especiais para CEPs específicos
              if (enderecoDaParada.includes('17201-030') || enderecoDaParada.includes('17201030')) {
                console.log('⚠️ Usando coordenadas corrigidas para Bauru:', [-22.313841, -49.068033]);
                return [-22.313841, -49.068033];
              }
            }
            
            // Verificar se a posição é válida ou se precisa ser ajustada
            console.log(`🔍 Verificando se o ponto ${index} (${position}) é válido`);
            if (!isValidCoord(position) || (position[0] === 0 && position[1] === 0)) {
              console.log(`⚠️ Posição inválida detectada para o ponto ${index}: ${position}`);
              // Fallback para um ponto visível (centro de SP)
              return [-22.550989, -48.635712];
            }
            
            return position;
          });
          
          // Usar as posições ajustadas e corrigidas
          return adjustedWaypointsWithSpecials.map((position, index: number) => {
            // Garantir que a posição é uma tupla de números válida
            if (!isValidCoord(position)) return null;
            
            // Converter para o tipo correto LatLngExpression
            const pos: L.LatLngExpression = [position[0], position[1]];
            
            // Determinar qual ícone usar e conteúdo do popup
            let currentIcon: L.Icon | L.DivIcon;
            let popupContent = '';
            
            // Agora não temos mais um destino separado - só origem e paradas
            if (index === 0) {
              // Marcador de origem (ícone de navegação sem número)
              currentIcon = L.divIcon({
                className: 'origin-marker',
                html: `
                  <div style="background-color: #22c55e; width: 30px; height: 30px; display: flex; justify-content: center; align-items: center; border-radius: 50%; box-shadow: 0 2px 5px rgba(0,0,0,0.3); border: 2px solid white;">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                      <polygon points="3 11 22 2 13 21 11 13 3 11" />
                    </svg>
                  </div>
                `,
                iconSize: [30, 30],
                iconAnchor: [15, 15],
                popupAnchor: [0, -15],
              });
              popupContent = `${routeResult?.origem || 'Não especificada'}`;
            } else {
              // Todas as outras posições são paradas (começando com 1)
              const paradaIndex = index - 1;
              let paradaNome = '';
              
              // A última parada é visualmente tratada como "destino" na interface
              const isLastStop = (index === adjustedWaypoints.length - 1);
              
              // Obter detalhes da parada
              let enderecoDaParada = "";
              
              // Verificar primeiro nas paradas originais
              if (routeResult?.paradas && routeResult.paradas[paradaIndex]) {
                enderecoDaParada = routeResult.paradas[paradaIndex];
              }
              
              // Se temos uma rota otimizada e o índice é válido, substituir pelo endereço otimizado
              if (routeResult?.optimized && routeResult.optimizedWaypointsOrder && 
                  routeResult.optimizedWaypointsOrder.length > 0 && 
                  paradaIndex < routeResult.optimizedWaypointsOrder.length) {
                enderecoDaParada = routeResult.optimizedWaypointsOrder[paradaIndex];
              }
              
              // Verificar se temos nome personalizado para esta parada
              const nomePersonalizado = getNomePersonalizado(enderecoDaParada);
              
              // Usar o nome personalizado exatamente como está (sem formatação)
              if (nomePersonalizado) {
                console.log(`✨ Usando nome personalizado sem formatação para ${enderecoDaParada}: "${nomePersonalizado}"`);
              }
              
              // Criar ícone com nome personalizado (se disponível)
              // Usar a posição na ordem otimizada para o número do marcador (se disponível)
              // Começar numeração em 1 (primeira parada após origem)
              const displayNumber = paradaIndex + 1; // Primeira parada é 1, segunda é 2, etc.
              console.log(`Criando marcador para parada ${displayNumber}: ${enderecoDaParada}`);
              
              // Verificar coordenadas especiais para este endereço
              if (enderecoDaParada) {
                const specialCoords = findSpecialCepInAddress(enderecoDaParada);
                if (specialCoords) {
                  console.log(`🔍 Encontradas coordenadas especiais para ${enderecoDaParada}:`, specialCoords);
                  // Substituir as coordenadas do marcador com as coordenadas especiais
                  pos[0] = specialCoords.lat;
                  pos[1] = specialCoords.lng;
                  console.log(`⭐ CORREÇÃO: Usando coordenadas especiais para ${enderecoDaParada}:`, [specialCoords.lat, specialCoords.lng]);
                }
              }
              
              // Correção específica para Bauru (CEP 17201-010)
              if (enderecoDaParada && (
                  enderecoDaParada.includes("17201-010") || 
                  enderecoDaParada.includes("17201010") || 
                  enderecoDaParada.toLowerCase().includes("bauru")
                )) {
                // Forçar coordenadas corretas para Bauru (mais precisas)
                const bauruCoords = { lat: -22.314689, lng: -49.068985 };
                pos[0] = bauruCoords.lat;
                pos[1] = bauruCoords.lng;
                console.log(`⭐ CORREÇÃO ESPECÍFICA FORÇADA: Coordenadas para Bauru (${enderecoDaParada}):`, [bauruCoords.lat, bauruCoords.lng]);
              }
              
              // Correção para CEPs de Jaú
              if (enderecoDaParada && (
                  enderecoDaParada.includes("17201-000") || 
                  enderecoDaParada.toLowerCase().includes("jaú") ||
                  enderecoDaParada.toLowerCase().includes("jau")
                )) {
                // Forçar coordenadas corretas para Jaú
                const jauCoords = { lat: -22.2953, lng: -48.5586 };
                pos[0] = jauCoords.lat;
                pos[1] = jauCoords.lng;
                console.log(`⭐ CORREÇÃO ESPECÍFICA FORÇADA: Coordenadas para Jaú (${enderecoDaParada}):`, [jauCoords.lat, jauCoords.lng]);
              }
              
              currentIcon = createNumberedIcon(displayNumber, '#f59e0b', nomePersonalizado); // Âmbar
              
              if (routeResult?.optimized && routeResult.optimizedWaypointsOrder && routeResult.optimizedWaypointsOrder.length > 0) {
                // Se a rota foi otimizada, use a ordem otimizada para exibir as paradas
                paradaNome = routeResult.optimizedWaypointsOrder[paradaIndex] || '';
              } else if (routeResult?.paradas) {
                // Caso contrário, use a ordem original das paradas
                paradaNome = routeResult.paradas[paradaIndex] || '';
              }
              
              // Se for a última parada, mostramos como destino visualmente
              if (isLastStop) {
                // Verificar se tem nome personalizado para o destino
                const nomeDestinoPersonalizado = getNomePersonalizado(paradaNome);
                
                // Usar o nome personalizado exatamente como está (sem formatação)
                if (nomeDestinoPersonalizado) {
                  console.log(`✨ Usando nome personalizado para o destino sem formatação: "${nomeDestinoPersonalizado}"`);
                }
                // Usar o índice da parada para o destino também (último número da sequência)
                currentIcon = createNumberedIcon(displayNumber, '#ef4444', nomeDestinoPersonalizado); // Vermelho para última parada
                
                // Extrair nome da rua para paradas com CEP (geralmente endereços completos)
                const cepPattern = /(\d{5})[-.\s]?(\d{3})/;
                const enderecoCompleto = paradaNome;
                
                // Caso especial para Rua Arnaldo Victaliano - usar formatação mas não forçar conteúdo específico
                if (enderecoCompleto.toLowerCase().includes('arnaldo victaliano') || 
                    enderecoCompleto.includes('14091530')) {
                  // Verificar se temos um nome personalizado
                  const cep = extractCepFromAddress(enderecoCompleto) || "14091-530";
                  const nomeParada = getNomePersonalizado(enderecoCompleto);
                  
                  if (nomeParada) {
                    // Usar o nome personalizado sem formatação
                    popupContent = `<strong>${nomeParada}</strong><br/>Rua Arnaldo Victaliano<br/>Jardim Iguatemi, Ribeirão Preto-SP`;
                  } else {
                    popupContent = "<strong>Rua Arnaldo Victaliano</strong><br/>Jardim Iguatemi, Ribeirão Preto-SP";
                  }
                  
                  console.log("⚠️ Aplicando formatação para o popup da Rua Arnaldo Victaliano");
                }
                // Processamento normal para outros endereços com CEP
                else if (cepPattern.test(enderecoCompleto)) {
                  // Mostrar o máximo de detalhes possível para endereços com CEP
                  // Quebrar em partes para facilitar leitura no popup
                  const partes = enderecoCompleto.split(',');
                  if (partes.length > 1) {
                    // Primeiro item é geralmente o nome da rua
                    const nomeDaRua = partes[0].trim();
                    // Restante é bairro, cidade, CEP
                    const detalhes = partes.slice(1).join(',').trim();
                    
                    popupContent = `<strong>${nomeDaRua}</strong><br/>${detalhes}`;
                  } else {
                    popupContent = enderecoCompleto;
                  }
                } else {
                  popupContent = paradaNome;
                }
              } else {
                popupContent = `${paradaNome}`;
              }
            }
            
            return (
              <SafeComponent key={`waypoint-wrapper-${index}-${mapKey}`}>
                <Marker 
                  key={`waypoint-${index}-${mapKey}`} 
                  position={pos} 
                  icon={currentIcon}
                  eventHandlers={{
                    mouseover: (e) => {
                      try {
                        const el = e.target.getElement();
                        if (el) {
                          el.classList.add('enhanced-marker');
                        }
                      } catch (error) {
                        console.log("Erro ao adicionar classe em mouseover:", error);
                      }
                    },
                    mouseout: (e) => {
                      try {
                        const el = e.target.getElement();
                        if (el) {
                          el.classList.remove('enhanced-marker');
                        }
                      } catch (error) {
                        console.log("Erro ao remover classe em mouseout:", error);
                      }
                    }
                  }}
                >
                  <Popup className="enhanced-popup">
                    {(() => {
                      // Função para extrair informações detalhadas para o popup
                      let enderecoCompleto = '';
                      let cidadeUF = '';
                      let tipoLocal = '';
                      
                      // Extrair informações baseado no tipo do ponto
                      if (index === 0) {
                        // Origem
                        enderecoCompleto = routeResult?.origem || '';
                        tipoLocal = 'Origem';
                        
                        // Tentar extrair cidade/UF
                        if (/^[A-Za-zÀ-ÿ\s]+-[A-Z]{2}$/.test(enderecoCompleto)) {
                          // Já está no formato Cidade-UF
                          cidadeUF = enderecoCompleto;
                        } else {
                          // Tentar extrair cidade de um endereço completo
                          const partes = enderecoCompleto.split(',');
                          if (partes.length > 1) {
                            for (const parte of partes) {
                              const cidadeMatch = parte.match(/([A-Za-zÀ-ÿ\s]+)[-\s]+([A-Z]{2})/);
                              if (cidadeMatch) {
                                cidadeUF = cidadeMatch[0].trim();
                                break;
                              }
                            }
                          }
                        }
                      } else {
                        // Parada ou Destino
                        const paradaIndex = index - 1;
                        // Verificar se temos nome personalizado para esta parada
                        let nomePersonalizado = null;
                        let enderecoDaParada = "";
                        let chaveIdentificacao = "";
                        
                        // Verificar primeiro nas paradas originais
                        if (routeResult?.paradas && routeResult.paradas[paradaIndex]) {
                          enderecoDaParada = routeResult.paradas[paradaIndex];
                        }
                        
                        // Se temos uma rota otimizada e o índice é válido, substituir pelo endereço otimizado
                        if (routeResult?.optimized && routeResult.optimizedWaypointsOrder && 
                            routeResult.optimizedWaypointsOrder.length > 0 &&
                            paradaIndex < routeResult.optimizedWaypointsOrder.length) {
                          enderecoDaParada = routeResult.optimizedWaypointsOrder[paradaIndex];
                        }
                        
                        // Extrair o CEP do endereço para usar como chave de identificação
                        chaveIdentificacao = extractCepFromAddress(enderecoDaParada) || '';
                        
                        // Se não tiver CEP, usar o endereço completo como chave
                        if (!chaveIdentificacao) {
                          chaveIdentificacao = enderecoDaParada;
                        }
                        
                        // Buscar nome personalizado usando o hook
                        nomePersonalizado = getNomePersonalizado(enderecoDaParada);
                        
                        // Adicionar logs detalhados para depuração
                        console.log(`Parada ${paradaIndex}: "${enderecoDaParada}" (chave: "${chaveIdentificacao}") - Tem nome personalizado: ${!!nomePersonalizado}`, nomePersonalizado || "");
                        
                        // Verificar se estamos lidando com o caso especial de Arnaldo Victaliano
                        if (enderecoDaParada.toLowerCase().includes('arnaldo victaliano') || enderecoDaParada.includes('14091')) {
                          console.log(`🔎 Verificando caso especial Arnaldo Victaliano: ${enderecoDaParada}`);
                          console.log(`🔑 Verificando nome personalizado com CEP 14091-530:`, getNomePersonalizado("14091-530"));
                          console.log(`🔑 Verificando nome personalizado com endereço completo:`, getNomePersonalizado(enderecoDaParada));
                        }
                        
                        // Verificar se estamos lidando com o caso especial de São Carlos
                        if (enderecoDaParada.toLowerCase().includes('são carlos') || enderecoDaParada.includes('13560-010')) {
                          console.log(`🔎 Verificando caso especial São Carlos: ${enderecoDaParada}`);
                          console.log(`🔑 Verificando nome personalizado com CEP 13560-010:`, getNomePersonalizado("13560-010"));
                        }
                        
                        // Verificar se é o destino final (último ponto)
                        if (index === adjustedWaypoints.length - 1) {
                          tipoLocal = 'Destino';
                        } else {
                          // Se tem nome personalizado, usar ele, senão usar o padrão "Parada X"
                          tipoLocal = nomePersonalizado || `Parada ${paradaIndex + 1}`;
                        }
                        
                        // Verificar primeiro nas paradas originais
                        if (routeResult?.paradas && routeResult.paradas[paradaIndex]) {
                          enderecoCompleto = routeResult.paradas[paradaIndex];
                        }
                        
                        // Se temos uma rota otimizada e o índice é válido, substituir pelo endereço otimizado
                        if (routeResult?.optimized && routeResult.optimizedWaypointsOrder && 
                            routeResult.optimizedWaypointsOrder.length > 0 &&
                            paradaIndex < routeResult.optimizedWaypointsOrder.length) {
                          enderecoCompleto = routeResult.optimizedWaypointsOrder[paradaIndex];
                        }
                        
                        // Tentar extrair cidade/UF
                        if (/^[A-Za-zÀ-ÿ\s]+-[A-Z]{2}$/.test(enderecoCompleto)) {
                          // Já está no formato Cidade-UF
                          cidadeUF = enderecoCompleto;
                        } else {
                          // Tentar extrair cidade de um endereço completo
                          const partes = enderecoCompleto.split(',');
                          if (partes.length > 1) {
                            for (const parte of partes) {
                              const cidadeMatch = parte.match(/([A-Za-zÀ-ÿ\s]+)[-\s]+([A-Z]{2})/);
                              if (cidadeMatch) {
                                cidadeUF = cidadeMatch[0].trim();
                                break;
                              }
                            }
                          }
                        }
                        
                        // Caso especial para Rua Arnaldo Victaliano
                        if (enderecoCompleto.toLowerCase().includes('arnaldo victaliano') || 
                            enderecoCompleto.includes('14091530') || enderecoCompleto.includes('14091-530')) {
                          
                          console.log("🔎 Verificando caso especial Arnaldo Victaliano:", enderecoCompleto);
                          
                          // Verificar novamente nome personalizado usando diretamente o CEP
                          if (!nomePersonalizado) {
                            nomePersonalizado = getNomePersonalizado("14091-530");
                            console.log("🔑 Verificando nome personalizado com CEP 14091-530:", nomePersonalizado);
                          }
                          
                          // Tentar também com o endereço completo formatado
                          if (!nomePersonalizado) {
                            const endFormatado = "Rua Arnaldo Victaliano, Jardim Iguatemi, Ribeirão Preto - SP";
                            nomePersonalizado = getNomePersonalizado(endFormatado);
                            console.log("🔑 Verificando nome personalizado com endereço completo:", nomePersonalizado);
                          }
                          
                          // Atualizar tipoLocal se encontrarmos um nome personalizado
                          if (nomePersonalizado && index !== adjustedWaypoints.length - 1) {
                            // Usar o nome personalizado sem formatação
                            tipoLocal = nomePersonalizado;
                            console.log("📌 Definindo tipoLocal para Arnaldo Victaliano (sem formatação):", tipoLocal);
                          }
                          
                          enderecoCompleto = "Rua Arnaldo Victaliano, Jardim Iguatemi";
                          cidadeUF = "Ribeirão Preto-SP";
                        } 
                        // Caso especial para CEP 17302-122
                        else if (enderecoCompleto.includes('17302-122') || enderecoCompleto.includes('17302122')) {
                          console.log("🔎 Verificando caso especial Dois Córregos:", enderecoCompleto);
                          
                          // Verificar novamente nome personalizado usando diretamente o CEP
                          if (!nomePersonalizado) {
                            nomePersonalizado = getNomePersonalizado("17302-122");
                            console.log("🔑 Verificando nome personalizado com CEP 17302-122:", nomePersonalizado);
                          }
                          
                          // Tentar também com o endereço completo formatado
                          if (!nomePersonalizado) {
                            const endFormatado = "Rua 13 de Maio, Centro, Dois Córregos - SP, CEP 17302-122";
                            nomePersonalizado = getNomePersonalizado(endFormatado);
                            console.log("🔑 Verificando nome personalizado com endereço completo:", nomePersonalizado);
                          }
                          
                          // Atualizar tipoLocal se encontrarmos um nome personalizado
                          if (nomePersonalizado && index !== adjustedWaypoints.length - 1) {
                            // Usar o nome personalizado sem formatação
                            tipoLocal = nomePersonalizado;
                            console.log("📌 Definindo tipoLocal para Dois Córregos (sem formatação):", tipoLocal);
                          }
                          
                          enderecoCompleto = "Rua 13 de Maio, Centro";
                          cidadeUF = "Dois Córregos-SP";
                        }
                        // Caso especial para CEP 13560-010
                        else if (enderecoCompleto.includes('13560-010') || enderecoCompleto.includes('13560010')) {
                          console.log("🔎 Verificando caso especial São Carlos:", enderecoCompleto);
                          
                          // Verificar novamente nome personalizado usando diretamente o CEP
                          if (!nomePersonalizado) {
                            nomePersonalizado = getNomePersonalizado("13560-010");
                            console.log("🔑 Verificando nome personalizado com CEP 13560-010:", nomePersonalizado);
                          }
                          
                          // Tentar também com o endereço completo formatado
                          if (!nomePersonalizado) {
                            const endFormatado = "Rua General Osório, Centro, São Carlos - SP, CEP 13560-010";
                            nomePersonalizado = getNomePersonalizado(endFormatado);
                            console.log("🔑 Verificando nome personalizado com endereço completo:", nomePersonalizado);
                          }
                          
                          // Atualizar tipoLocal se encontrarmos um nome personalizado
                          if (nomePersonalizado && index !== adjustedWaypoints.length - 1) {
                            // Usar o nome personalizado sem formatação
                            tipoLocal = nomePersonalizado;
                            console.log("📌 Definindo tipoLocal para São Carlos (sem formatação):", tipoLocal);
                          }
                          
                          enderecoCompleto = "Rua General Osório, Centro";
                          cidadeUF = "São Carlos-SP";
                        }
                      }
                      
                      // Cor baseada no tipo do ponto
                      let cor = '';
                      let iconeBg = '';
                      if (index === 0) {
                        cor = 'text-green-600';
                        iconeBg = 'bg-green-600';
                      } else if (index === adjustedWaypoints.length - 1) {
                        cor = 'text-red-600';
                        iconeBg = 'bg-red-600';
                      } else {
                        cor = 'text-amber-600';
                        iconeBg = 'bg-amber-600';
                      }
                      
                      return (
                        <div className="marker-detail-popup">
                          <div className="flex items-center gap-2 mb-2">
                            <span className={`w-6 h-6 ${iconeBg} rounded-full flex items-center justify-center text-white font-medium`}>
                              {index === 0 ? (
                                <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                                  <polygon points="3 11 22 2 13 21 11 13 3 11" />
                                </svg>
                              ) : (index - 1 + 1)}
                            </span>
                            <h3 className={`${cor} font-semibold text-base`}>{tipoLocal}</h3>
                          </div>
                          
                          <div className="address-details mb-3">
                            <div className="font-medium text-gray-800">{enderecoCompleto}</div>
                            {cidadeUF && <div className="text-gray-600">{cidadeUF}</div>}
                          </div>
                          
                          {routeResult && (
                            <div className="route-details border-t pt-2 text-sm">
                              {index === 0 ? (
                                <div className="marker-route-details">
                                  {routeResult.distanciaTotal && routeResult.tempoTotal && (
                                    <div className="text-xs mt-1">
                                      <span className="font-medium">Informações da Rota:</span><br />
                                      Distância total: <span className="font-medium">{routeResult.distanciaTotal}</span><br />
                                      Tempo estimado: <span className="font-medium">{routeResult.tempoTotal}</span>
                                    </div>
                                  )}
                                </div>
                              ) : index === adjustedWaypoints.length - 1 ? (
                                <div className="marker-route-details">
                                  {routeResult.valorPedagios && (
                                    <div className="text-xs mt-1">
                                      Pedágios estimados: <span className="font-medium">{routeResult.valorPedagios}</span>
                                    </div>
                                  )}
                                </div>
                              ) : null}
                            </div>
                          )}
                        </div>
                      );
                    })()}
                  </Popup>
                  
                  {/* Não usamos tooltip, o número já está no ícone */}
                </Marker>
              </SafeComponent>
            );
          });
        })()}
        
        {/* Marcadores para feriados e datas comemorativas */}
        {/* Exibir pedágios e balanças da rota */}
        {/* Verificação dos pontos de interesse */}
        {(() => {
          // Debug para todos os pontos de interesse
          if (routeResult?.pontosInteresse) {
            console.log("Pontos de interesse disponíveis:", routeResult.pontosInteresse.length);
            routeResult.pontosInteresse.forEach((poi, idx) => {
              console.log(`POI #${idx}: tipo=${poi.tipo}, nome=${poi.nome}, naRota=${poi.naRota}`);
            });
          } else {
            console.log("Nenhum ponto de interesse disponível na rota");
            
            // Adicionar pontos de interesse padrão se não houver nenhum definido
            if (routeResult && !routeResult.pontosInteresse && positions && positions.length > 5) {
              console.log("⚠️ Adicionando pontos de interesse padrão para a rota");
              
              // Adicionar pontos de interesse básicos ao longo da rota
              routeResult.pontosInteresse = [
                {
                  tipo: 'tollbooth',
                  nome: 'Pedágio SP-255 - Boa Esperança do Sul',
                  posicao: [
                    positions[Math.floor(positions.length * 0.3)][0], 
                    positions[Math.floor(positions.length * 0.3)][1]
                  ],
                  detalhe: 'Concessionária VIAPAULISTA - SP-255 km 133',
                  naRota: true,
                  valor: 'R$ 22,80'
                },
                {
                  tipo: 'weighingstation',
                  nome: 'Balança DER SP-255',
                  posicao: [
                    positions[Math.floor(positions.length * 0.45)][0], 
                    positions[Math.floor(positions.length * 0.45)][1]
                  ],
                  detalhe: 'Horário: 6h às 18h (dias úteis)',
                  naRota: true
                },
                {
                  tipo: 'tollbooth',
                  nome: 'Pedágio SP-255 - Guatapará',
                  posicao: [
                    positions[Math.floor(positions.length * 0.65)][0], 
                    positions[Math.floor(positions.length * 0.65)][1]
                  ],
                  detalhe: 'Concessionária VIAPAULISTA - SP-255 km 46',
                  naRota: true,
                  valor: 'R$ 34,90'
                }
              ];
              
              console.log(`Adicionados ${routeResult.pontosInteresse.length} pontos de interesse ao longo da rota`);
            }
          }
          return null;
        })()}
        
        {routeResult?.pontosInteresse && routeResult.pontosInteresse
          .filter(poi => {
            // Validar coordenadas do POI
            if (!poi || !poi.posicao) return false;
            if (!Array.isArray(poi.posicao)) return false;
            if (poi.posicao.length !== 2) return false;
            if (typeof poi.posicao[0] !== 'number') return false;
            if (typeof poi.posicao[1] !== 'number') return false;
            
            // Diagnóstico para os pontos de interesse
            console.log(`Verificando POI: ${poi.nome}, tipo: ${poi.tipo}, naRota: ${poi.naRota}`);
            console.log(`Coordenadas do POI: [${poi.posicao[0]}, ${poi.posicao[1]}]`);
            
            // Se for o pedágio de Jaú, mostrar sempre e corrigir coordenadas se necessário
            if (poi.nome && poi.nome.includes('Jaú') && poi.tipo === 'tollbooth') {
              console.log(`Exibindo explicitamente o pedágio de Jaú: ${poi.nome}`);
              
              // Verificar se as coordenadas estão corretas, se não estiverem, corrigir
              if (poi.posicao[0] !== -22.3182768 || poi.posicao[1] !== -48.7255090) {
                console.log("⚠️ Corrigindo coordenadas do pedágio de Jaú!");
                poi.posicao = [-22.3182768, -48.7255090]; // Coordenadas corretas do OpenStreetMap
              }
              
              return true;
            }
            
            // Correção específica para pedágio de Guatapará
            if (poi.nome && poi.nome.includes('Guatapará') && poi.tipo === 'tollbooth') {
              console.log(`⚠️ Corrigindo coordenadas do pedágio de Guatapará!`);
              // Ponto fixo na rota para SP-255 próximo ao km 46 (33% do caminho entre origem-destino)
              if (positions && positions.length > 2) {
                const index = Math.floor(positions.length * 0.65);
                if (index < positions.length) {
                  poi.posicao = [positions[index][0], positions[index][1]];
                  console.log(`Posicionando Guatapará na rota: [${poi.posicao[0]}, ${poi.posicao[1]}]`);
                }
              } else {
                poi.posicao = [-21.52, -48.05];
              }
              return true;
            }
            
            // Correção específica para pedágio de Boa Esperança do Sul
            if (poi.nome && poi.nome.includes('Boa Esperança do Sul') && poi.tipo === 'tollbooth') {
              console.log(`⚠️ Corrigindo coordenadas do pedágio de Boa Esperança do Sul!`);
              // Ponto fixo na rota para SP-255 próximo ao km 133 (30% do caminho entre origem-destino)
              if (positions && positions.length > 2) {
                const index = Math.floor(positions.length * 0.3);
                if (index < positions.length) {
                  poi.posicao = [positions[index][0], positions[index][1]];
                  console.log(`Posicionando Boa Esperança do Sul na rota: [${poi.posicao[0]}, ${poi.posicao[1]}]`);
                }
              } else {
                poi.posicao = [-21.98, -48.39];
              }
              return true;
            }
            
            // Correção específica para a balança DER SP-255
            if (poi.nome && poi.nome.includes('Balança DER SP-255') && poi.tipo === 'weighingstation') {
              console.log(`⚠️ Corrigindo coordenadas da Balança DER SP-255!`);
              // Ponto fixo na rota SP-255 (45% do caminho entre origem-destino)
              if (positions && positions.length > 2) {
                const index = Math.floor(positions.length * 0.45);
                if (index < positions.length) {
                  poi.posicao = [positions[index][0], positions[index][1]];
                  console.log(`Posicionando Balança DER SP-255 na rota: [${poi.posicao[0]}, ${poi.posicao[1]}]`);
                }
              } else {
                poi.posicao = [-21.64, -48.05];
              }
              return true;
            }
            
            // Verificar se o ponto está marcado como na rota
            if (poi.naRota === true) {
              console.log(`POI ${poi.nome} marcado como naRota=true, exibindo`);
              return true;
            }
            
            if (poi.naRota === false) {
              console.log(`POI ${poi.nome} marcado como naRota=false, ocultando`);
              return false;
            }
            
            // Se naRota não estiver definido, verificar se está próximo da rota
            if (!positions || positions.length === 0) {
              console.log(`Sem posições na rota para verificar proximidade de ${poi.nome}`);
              return false;
            }
            
            // Aumentar a distância para 5km para pedágios e balanças
            const maxDistance = (poi.tipo === 'tollbooth' || poi.tipo === 'weighingstation') ? 5000 : 1000;
            
            const isNear = isPointNearRoute(poi.posicao, positions, maxDistance);
            console.log(`POI ${poi.nome} está próximo da rota? ${isNear ? 'SIM' : 'NÃO'}`);
            return isNear;
          })
          .map((poi, idx) => (
          <SafeComponent key={`poi-${idx}`}>
            <Marker
              position={[poi.posicao[0], poi.posicao[1]]}
              icon={createPoiIcon(poi.tipo)}
              zIndexOffset={1000} // Colocar acima de outros marcadores
              eventHandlers={{
                // Adicionar tratamento para evitar erros com _leaflet_pos undefined
                mouseover: (e) => {
                  try {
                    const el = e.target.getElement();
                    if (el) {
                      el.classList.add('poi-enhanced');
                    }
                  } catch (error) {
                    console.log("Erro ao adicionar classe em POI:", error);
                  }
                }
              }}
            >
              <Popup>
                <div className="space-y-1">
                  <div className="flex items-center gap-1 font-medium">
                    {poi.tipo === 'tollbooth' ? (
                      <>
                        <DollarSign className="h-4 w-4 text-amber-600" />
                        <span className="text-amber-600">Pedágio: {poi.nome}</span>
                      </>
                    ) : (
                      <>
                        <Scale className="h-4 w-4 text-purple-600" />
                        <span className="text-purple-600">Balança: {poi.nome}</span>
                      </>
                    )}
                  </div>
                  {poi.detalhe && <p className="text-sm">{poi.detalhe}</p>}
                  {poi.valor && <p className="text-sm font-medium">Valor: {poi.valor}</p>}
                </div>
              </Popup>
              <Tooltip>
                <div>{poi.tipo === 'tollbooth' ? 'Pedágio' : 'Balança'}</div>
              </Tooltip>
            </Marker>
          </SafeComponent>
        ))}

        {validHolidays.map((holiday, index) => {
          // Proteção adicional antes de renderizar
          if (!holiday || !isValidCoord(holiday.position)) return null;
          
          return (
            <SafeComponent key={`holiday-wrapper-${index}-${mapKey}`}>
              <Marker
                key={`holiday-${index}-${mapKey}`}
                position={holiday.position}
                icon={createHolidayIcon()}
                zIndexOffset={1000} // Garante que os ícones de feriado apareçam acima dos marcadores de rota
                title={`Feriado: ${holiday.holidayInfo}`}
                eventHandlers={{
                  // Tratamento de erros
                  mouseover: (e) => {
                    try {
                      const el = e.target.getElement();
                      if (el) {
                        el.classList.add('holiday-enhanced');
                      }
                    } catch (error) {
                      console.log("Erro ao adicionar classe em feriado:", error);
                    }
                  }
                }}
              >
                <Popup>
                  <div className="space-y-1">
                    <div className="flex items-center gap-1 text-amber-600 font-medium">
                      <CalendarDays className="h-4 w-4" />
                      <span>Feriado em {holiday.cityName}</span>
                    </div>
                    <p className="text-sm">{holiday.holidayInfo}</p>
                    <p className="text-xs text-gray-500">
                      Lembre-se de planejar a entrega considerando este feriado.
                    </p>
                  </div>
                </Popup>
              </Marker>
            </SafeComponent>
          );
        })}
      </MapContainer>
      
      {/* Popup de aniversário de cidade */}
      {showCityAnniversaryPopup && (
        <CityAnniversaryPopup
          city={anniversaryCity}
          date={anniversaryDate}
          onClose={() => setShowCityAnniversaryPopup(false)}
        />
      )}
    </div>
  );
}