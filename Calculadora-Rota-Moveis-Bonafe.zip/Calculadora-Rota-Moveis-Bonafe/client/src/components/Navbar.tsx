import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Truck, Menu, X } from "lucide-react";

export function Navbar() {
  const [location] = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <nav className="bg-white border-b border-gray-200">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <Link href="/">
              <div className="flex items-center gap-2 cursor-pointer">
                <Truck className="h-6 w-6 text-[hsl(var(--transportadora-primary))]" />
                <span className="font-bold text-lg">RotaExpress</span>
              </div>
            </Link>
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden">
            <Button 
              variant="ghost" 
              size="icon"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? (
                <X className="h-6 w-6" />
              ) : (
                <Menu className="h-6 w-6" />
              )}
            </Button>
          </div>

          {/* Desktop menu */}
          <div className="hidden md:flex items-center space-x-4">
            <Link href="/">
              <div className={`px-3 py-2 rounded-md text-sm font-medium cursor-pointer ${
                location === "/" ? "bg-gray-100 text-gray-900" : "text-gray-600 hover:bg-gray-50"
              }`}>
                Início
              </div>
            </Link>
            <Link href="/sobre">
              <div className={`px-3 py-2 rounded-md text-sm font-medium cursor-pointer ${
                location === "/sobre" ? "bg-gray-100 text-gray-900" : "text-gray-600 hover:bg-gray-50"
              }`}>
                Sobre
              </div>
            </Link>
            <Link href="/contato">
              <div className={`px-3 py-2 rounded-md text-sm font-medium cursor-pointer ${
                location === "/contato" ? "bg-gray-100 text-gray-900" : "text-gray-600 hover:bg-gray-50"
              }`}>
                Contato
              </div>
            </Link>

          </div>
        </div>
      </div>

      {/* Mobile menu */}
      {mobileMenuOpen && (
        <div className="md:hidden">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
            <Link href="/">
              <div 
                className={`block px-3 py-2 rounded-md text-base font-medium cursor-pointer ${
                  location === "/" ? "bg-gray-100 text-gray-900" : "text-gray-600 hover:bg-gray-50"
                }`}
                onClick={() => setMobileMenuOpen(false)}
              >
                Início
              </div>
            </Link>
            <Link href="/sobre">
              <div 
                className={`block px-3 py-2 rounded-md text-base font-medium cursor-pointer ${
                  location === "/sobre" ? "bg-gray-100 text-gray-900" : "text-gray-600 hover:bg-gray-50"
                }`}
                onClick={() => setMobileMenuOpen(false)}
              >
                Sobre
              </div>
            </Link>
            <Link href="/contato">
              <div 
                className={`block px-3 py-2 rounded-md text-base font-medium cursor-pointer ${
                  location === "/contato" ? "bg-gray-100 text-gray-900" : "text-gray-600 hover:bg-gray-50"
                }`}
                onClick={() => setMobileMenuOpen(false)}
              >
                Contato
              </div>
            </Link>
            

          </div>
        </div>
      )}
    </nav>
  );
}
