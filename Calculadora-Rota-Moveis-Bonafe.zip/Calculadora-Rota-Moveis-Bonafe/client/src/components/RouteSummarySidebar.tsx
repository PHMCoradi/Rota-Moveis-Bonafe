import { useState, useEffect } from "react";
import { ChevronsRight, ChevronsLeft, Clock, Navigation, MapPin, Truck, DollarSign, Route as RouteIcon, AlertCircle, Calendar, Gift } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { formatDistance, formatCurrency } from "@/lib/utils";
import { TruckRestriction, verificarRestricoesCidades, extrairCidadeDeEndereco } from "@/lib/truckRestrictions";
import { Holiday, findHolidaysInRange, extractCityAndStateFromAddress, formatHolidayDate } from "@/lib/holidays";
import { useCustomNames } from "@/lib/nameContext";
import { formatarNome } from "@/lib/textUtils";

// Função para extrair CEP de um endereço
function extractCepFromAddress(address: string): string | null {
  const cepRegex = /\b(\d{5})[-.\s]?(\d{3})\b/;
  const match = address.match(cepRegex);
  if (match) {
    return `${match[1]}-${match[2]}`;
  }
  return null;
}

// Hook personalizado para obter nome personalizado usando o contexto
function useGetNomePersonalizado() {
  const { customNames } = useCustomNames();
  
  return (endereco: string): string | null => {
    try {
      let nomePersonalizado: string | null = null;
      
      // Estratégia 1: Verificar por CEP
      const cep = extractCepFromAddress(endereco);
      if (cep && customNames[cep]) {
        nomePersonalizado = customNames[cep];
      }
      
      // Estratégia 2: Verificar endereço completo
      if (!nomePersonalizado && customNames[endereco]) {
        nomePersonalizado = customNames[endereco];
      }
      
      // Estratégia 3: Casos especiais conhecidos
      // Caso Ribeirão Preto
      if (!nomePersonalizado && (
          endereco.includes("Arnaldo Victaliano") || 
          endereco.includes("Jardim Iguatemi") || 
          endereco.toLowerCase().includes("ribeirao") || 
          endereco.toLowerCase().includes("ribeirão"))) {
        nomePersonalizado = customNames["14091-530"] || null;
      }
      
      // Caso Dois Córregos
      if (!nomePersonalizado && (
          endereco.includes("Rua 13 de Maio") || 
          endereco.includes("17302-122") || 
          endereco.includes("Dois Córregos"))) {
        nomePersonalizado = customNames["17302-122"] || null;
      }
      
      // Caso São Carlos
      if (!nomePersonalizado && (
          endereco.toLowerCase().includes("general osório") || 
          endereco.includes("13560-010") || 
          endereco.toLowerCase().includes("são carlos"))) {
        nomePersonalizado = customNames["13560-010"] || null;
      }
      
      // Caso Araraquara
      if (!nomePersonalizado && (
          endereco.includes("14800-022") || 
          endereco.toLowerCase().includes("araraquara"))) {
        nomePersonalizado = customNames["14800-022"] || null;
      }
      
      // Caso Atibaia
      if (!nomePersonalizado && (
          endereco.includes("12946-851") || 
          endereco.toLowerCase().includes("atibaia"))) {
        nomePersonalizado = customNames["12946-851"] || null;
      }
      
      // Caso Jaú
      if (!nomePersonalizado && (
          endereco.includes("17320-015") || 
          endereco.toLowerCase().includes("jaú"))) {
        nomePersonalizado = customNames["17320-015"] || null;
      }
      
      // Caso Bauru
      if (!nomePersonalizado && (
          endereco.includes("17201-030") || 
          endereco.toLowerCase().includes("bauru"))) {
        nomePersonalizado = customNames["17201-030"] || null;
      }
      
      // Retornar o nome personalizado no formato original (sem formatação)
      // para preservar o formato exato como foi importado do arquivo
      if (nomePersonalizado) {
        console.log(`📌 RouteSummarySidebar: Nome personalizado encontrado e será usado sem formatação: "${nomePersonalizado}"`);
        return nomePersonalizado;
      }
      return null;
    } catch (error) {
      console.error('Erro ao buscar nome personalizado:', error);
      return null;
    }
  };
}

// Define interface for Points of Interest
interface PointOfInterest {
  nome: string;
  tipo: string;
  posicao: [number, number];
  detalhe?: string;
  valor?: string;
  naRota?: boolean;
}

// Define interface for Route Alternatives
interface RouteAlternative {
  destaque?: boolean;
  distanciaNumerica: number;
  tempoNumerico: number;
}

// Define interface for Route Result
interface RouteResultData {
  distanciaTotal: string;
  tempoTotal: string;
  distanciaNumerica?: number;
  tempoNumerico?: number;
  origem: string;
  destino?: string;
  paradas?: string[];
  valorPedagios?: string;
  tipoVeiculo?: string;
  pontosInteresse?: PointOfInterest[];
  rotasAlternativas?: RouteAlternative[];
  optimized?: boolean;
  originalWaypointsOrder?: string[];
  optimizedWaypointsOrder?: string[];
  dataInicioEntrega?: string; // data início no formato DD/MM/YYYY
  dataFimEntrega?: string;    // data fim no formato DD/MM/YYYY
}

interface RouteSummarySidebarProps {
  routeResult: RouteResultData | null;
  isVisible?: boolean;
}

export function RouteSummarySidebar({ routeResult, isVisible = true }: RouteSummarySidebarProps) {
  const [isOpen, setIsOpen] = useState(isVisible);
  const [restricoesCaminhoes, setRestricoesCaminhoes] = useState<TruckRestriction[]>([]);
  const [cidadesVerificadas, setCidadesVerificadas] = useState<string[]>([]);
  const [eventosRota, setEventosRota] = useState<{nome: string, data: string, tipo: string}[]>([]);
  const [carregando, setCarregando] = useState(false);
  
  // Use o hook personalizado para obter nomes personalizados
  const { customNames } = useCustomNames();
  const getNomePersonalizado = useGetNomePersonalizado();
  
  // Log para debugging
  useEffect(() => {
    console.log("RouteSummarySidebar - customNames:", customNames);
  }, [customNames]);

  // Toggle sidebar open/closed
  const toggleSidebar = () => {
    setIsOpen(!isOpen);
  };

  // Verificar restrições de caminhões e eventos quando a rota mudar
  useEffect(() => {
    if (!routeResult) return;

    setCarregando(true);
    
    // Construir lista de todos os pontos da rota
    const todosPontos = [
      routeResult.origem, 
      ...(routeResult.paradas || [])
    ].filter(Boolean);

    // Extrair nomes de cidades
    const cidades = todosPontos
      .map(endereco => extrairCidadeDeEndereco(endereco))
      .filter((cidade, index, self) => 
        // Remover duplicatas
        index === self.findIndex(c => c.cidade === cidade.cidade && c.uf === cidade.uf)
      );

    // Lista de cidades para exibição
    const cidadesFormatadas = cidades.map(c => c.uf ? `${c.cidade}-${c.uf}` : c.cidade);
    setCidadesVerificadas(cidadesFormatadas);
    
    // Verificar restrições para estas cidades
    const restricoesEncontradas = verificarRestricoesCidades(cidades);
    setRestricoesCaminhoes(restricoesEncontradas);

    // Verificar eventos e feriados se houver datas de entrega
    if (routeResult.dataInicioEntrega && routeResult.dataFimEntrega) {
      console.log("Verificando feriados no período de entrega:", routeResult.dataInicioEntrega, "até", routeResult.dataFimEntrega);
      
      // Encontrar feriados no intervalo de datas
      const eventos = findHolidaysInRange(
        routeResult.dataInicioEntrega,
        routeResult.dataFimEntrega,
        cidadesFormatadas
      );
      
      if (eventos.length > 0) {
        console.log("Eventos encontrados durante o período de entrega:", eventos);
        
        // Formatar eventos para exibição
        const eventosFormatados = eventos.map(evento => {
          const ano = new Date().getFullYear();
          return {
            nome: evento.name,
            data: formatHolidayDate(evento.date, ano),
            tipo: evento.type === 'nacional' ? 'Feriado Nacional' :
                  evento.type === 'estadual' ? `Feriado Estadual (${evento.location})` :
                  evento.type === 'municipal' ? `Feriado Municipal (${evento.location})` :
                  evento.type === 'aniversario' ? `Aniversário de ${evento.location?.split('-')[0]}` :
                  'Evento'
          };
        });
        
        setEventosRota(eventosFormatados);
      } else {
        setEventosRota([]);
      }
    } else {
      console.log("Sem datas de início/fim definidas, não verificando feriados");
      setEventosRota([]);
    }
    
    setCarregando(false);
  }, [routeResult]);

  if (!routeResult) {
    return null;
  }

  // Extract relevant information from route result
  const { 
    distanciaTotal, 
    tempoTotal, 
    origem, 
    paradas = [], 
    valorPedagios, 
    tipoVeiculo,
    pontosInteresse = [],
    rotasAlternativas = [],
    optimized = false,
    optimizedWaypointsOrder = [],
    originalWaypointsOrder = []
  } = routeResult;
  
  // Use optimized waypoints order if available, otherwise use paradas
  const displayParadas = optimized && optimizedWaypointsOrder.length > 0 
    ? optimizedWaypointsOrder 
    : paradas;

  // Count tollbooths
  const numPedagios = pontosInteresse.filter((poi: PointOfInterest) => poi.tipo === 'tollbooth').length;
  
  // Count weighing stations
  const numBalancas = pontosInteresse.filter((poi: PointOfInterest) => poi.tipo === 'weighingstation').length;

  // Calculate estimated fuel cost (basic estimate)
  const distanceInKm = parseFloat(distanciaTotal.replace(/[^\d,]/g, '').replace(',', '.')) || 0;
  const consumoEstimado = tipoVeiculo?.includes('caminhao') ? 3.5 : 10; // km/L
  const precoCombustivel = tipoVeiculo?.includes('caminhao') ? 6.5 : 5.8; // R$/L
  const custoEstimadoCombustivel = (distanceInKm / consumoEstimado) * precoCombustivel;

  // Find route alternatives with better time or distance
  const tempoMelhor = rotasAlternativas.find((r: RouteAlternative) => r.tempoNumerico < (routeResult.tempoNumerico || 0));
  const distanciaMelhor = rotasAlternativas.find((r: RouteAlternative) => r.distanciaNumerica < (routeResult.distanciaNumerica || 0));

  return (
    <div className={`fixed top-1/4 right-0 z-40 transition-all duration-300 bg-white border border-gray-200 shadow-lg rounded-l-lg ${isOpen ? 'translate-x-0' : 'translate-x-[calc(100%-2rem)]'}`}>
      <div 
        className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-1/2 bg-white border border-gray-200 rounded-full p-1 cursor-pointer shadow-md"
        onClick={toggleSidebar}
      >
        {isOpen ? <ChevronsRight size={20} /> : <ChevronsLeft size={20} />}
      </div>
      
      <div className={`p-4 w-80 max-h-[70vh] overflow-y-auto`}>
        <div className="flex items-center justify-between mb-2">
          <h3 className="font-bold text-lg flex items-center gap-2">
            <RouteIcon size={18} className="text-blue-600" />
            Resumo da Rota
          </h3>
        </div>
        
        <Separator className="my-2" />
        
        <div className="space-y-4">
          {/* Origin and destination overview */}
          <div className="space-y-2">
            <div className="flex items-start gap-2">
              <Navigation size={16} className="min-w-4 mt-1 text-green-600" />
              <div>
                <span className="text-sm font-medium text-green-600">Origem</span>
                <p className="text-sm">{origem}</p>
              </div>
            </div>
            
            {displayParadas.length > 0 && displayParadas.map((parada: string, index: number) => {
              // Extrair o CEP para debug
              const cep = extractCepFromAddress(parada);
              
              // Usar o hook personalizado para obter o nome
              let nomePersonalizado = getNomePersonalizado(parada);
              
              // Se não encontrou pelo endereço, tentar pelo CEP direto
              if (!nomePersonalizado && cep) {
                nomePersonalizado = customNames[cep];
                console.log(`  Tentativa direta pelo CEP: ${cep} => ${nomePersonalizado || 'null'}`);
              }
              
              // Caso específico: Ribeirão Preto/Arnaldo Victaliano
              if (!nomePersonalizado && 
                  (parada.toLowerCase().includes('arnaldo victaliano') || 
                   parada.includes('14091-530') || 
                   parada.includes('14091530'))) {
                nomePersonalizado = customNames['14091-530'];
                console.log(`  🔍 Caso especial: Ribeirão Preto identificado, usando chave 14091-530 => ${nomePersonalizado || 'null'}`);
              }
              
              // Caso específico: Dois Córregos
              if (!nomePersonalizado && 
                  (parada.toLowerCase().includes('13 de maio') || 
                   parada.includes('17302-122') || 
                   parada.includes('17302122') ||
                   parada.includes('dois córregos'))) {
                nomePersonalizado = customNames['17302-122'];
                console.log(`  🔍 Caso especial: Dois Córregos identificado, usando chave 17302-122 => ${nomePersonalizado || 'null'}`);
              }
              
              // Caso específico: São Carlos
              if (!nomePersonalizado && 
                  (parada.toLowerCase().includes('general osório') || 
                   parada.includes('13560-010') || 
                   parada.includes('13560010') ||
                   parada.toLowerCase().includes('são carlos'))) {
                nomePersonalizado = customNames['13560-010'];
                console.log(`  🔍 Caso especial: São Carlos identificado, usando chave 13560-010 => ${nomePersonalizado || 'null'}`);
              }
              
              // Caso específico: Araraquara
              if (!nomePersonalizado && 
                  (parada.includes('14800-022') || 
                   parada.includes('14800022') ||
                   parada.toLowerCase().includes('araraquara'))) {
                nomePersonalizado = customNames['14800-022'];
                console.log(`  🔍 Caso especial: Araraquara identificado, usando chave 14800-022 => ${nomePersonalizado || 'null'}`);
              }
              
              // Caso específico: Atibaia
              if (!nomePersonalizado && 
                  (parada.includes('12946-851') || 
                   parada.includes('12946851') ||
                   parada.toLowerCase().includes('atibaia'))) {
                nomePersonalizado = customNames['12946-851'];
                console.log(`  🔍 Caso especial: Atibaia identificado, usando chave 12946-851 => ${nomePersonalizado || 'null'}`);
              }
              
              // Caso específico: Jaú
              if (!nomePersonalizado && 
                  (parada.includes('17320-015') || 
                   parada.includes('17320015') ||
                   parada.toLowerCase().includes('jaú'))) {
                nomePersonalizado = customNames['17320-015'];
                console.log(`  🔍 Caso especial: Jaú identificado, usando chave 17320-015 => ${nomePersonalizado || 'null'}`);
              }
              
              // Caso específico: Bauru
              if (!nomePersonalizado && 
                  (parada.includes('17201-030') || 
                   parada.includes('17201030') ||
                   parada.toLowerCase().includes('bauru'))) {
                nomePersonalizado = customNames['17201-030'];
                console.log(`  🔍 Caso especial: Bauru identificado, usando chave 17201-030 => ${nomePersonalizado || 'null'}`);
              }
              
              // Debug
              console.log(`RouteSummarySidebar - Parada ${index}:`);
              console.log(`  Endereço: "${parada}"`);
              console.log(`  CEP extraído: "${cep}"`);
              console.log(`  Nome personalizado: ${nomePersonalizado ? `"${nomePersonalizado}"` : 'null'}`);
              console.log(`  Lista de nomes disponíveis:`, customNames);
              
              return (
                <div key={index} className="flex items-start gap-2">
                  <div className="min-w-4 mt-1 flex justify-center">
                    <div className="flex items-center justify-center rounded-full w-4 h-4 bg-amber-500 text-white text-[10px] font-bold">
                      {index + 1}
                    </div>
                  </div>
                  <div>
                    {nomePersonalizado ? (
                      <>
                        <span className="text-sm font-medium text-amber-600">
                          <span className="bg-amber-100 text-amber-800 px-2 py-0.5 rounded border border-amber-300 text-sm shadow-sm">
                            {nomePersonalizado}
                          </span>
                        </span>
                        <p className="text-sm text-gray-700 mt-0.5">{parada}</p>
                      </>
                    ) : (
                      <>
                        <span className="text-sm font-medium text-amber-600">Parada {index + 1}</span>
                        <p className="text-sm text-gray-800">{parada}</p>
                      </>
                    )}
                  </div>
                </div>
              );
            })}
            
            <div className="flex items-start gap-2">
              <MapPin size={16} className="min-w-4 mt-1 text-red-600" />
              <div>
                <span className="text-sm font-medium text-red-600">Destino</span>
                {displayParadas.length > 0 ? (
                  (() => {
                    const destino = displayParadas[displayParadas.length - 1];
                    // Usar o hook personalizado para obter o nome
                    let nomePersonalizado = getNomePersonalizado(destino);
                    
                    // Extrair o CEP para debug
                    const cep = extractCepFromAddress(destino);
                    
                    // Se não encontrou pelo endereço, tentar pelo CEP direto
                    if (!nomePersonalizado && cep) {
                      nomePersonalizado = customNames[cep];
                      console.log(`  Destino - Tentativa direta pelo CEP: ${cep} => ${nomePersonalizado || 'null'}`);
                    }
                    
                    // Caso específico: Ribeirão Preto/Arnaldo Victaliano
                    if (!nomePersonalizado && 
                        (destino.toLowerCase().includes('arnaldo victaliano') || 
                        destino.includes('14091-530') || 
                        destino.includes('14091530'))) {
                      nomePersonalizado = customNames['14091-530'];
                      console.log(`  🔍 Caso especial: Ribeirão Preto identificado no destino, usando chave 14091-530`);
                    }
                    
                    // Caso específico: Dois Córregos
                    if (!nomePersonalizado && 
                        (destino.toLowerCase().includes('13 de maio') || 
                        destino.includes('17302-122') || 
                        destino.includes('17302122') ||
                        destino.includes('dois córregos'))) {
                      nomePersonalizado = customNames['17302-122'];
                      console.log(`  🔍 Caso especial: Dois Córregos identificado no destino, usando chave 17302-122`);
                    }
                    
                    // Caso específico: São Carlos
                    if (!nomePersonalizado && 
                        (destino.toLowerCase().includes('general osório') || 
                        destino.includes('13560-010') || 
                        destino.includes('13560010') ||
                        destino.toLowerCase().includes('são carlos'))) {
                      nomePersonalizado = customNames['13560-010'];
                      console.log(`  🔍 Caso especial: São Carlos identificado no destino, usando chave 13560-010`);
                    }
                    
                    // Caso específico: Araraquara
                    if (!nomePersonalizado && 
                        (destino.includes('14800-022') || 
                        destino.includes('14800022') ||
                        destino.toLowerCase().includes('araraquara'))) {
                      nomePersonalizado = customNames['14800-022'];
                      console.log(`  🔍 Caso especial: Araraquara identificado no destino, usando chave 14800-022`);
                    }
                    
                    // Caso específico: Atibaia
                    if (!nomePersonalizado && 
                        (destino.includes('12946-851') || 
                        destino.includes('12946851') ||
                        destino.toLowerCase().includes('atibaia'))) {
                      nomePersonalizado = customNames['12946-851'];
                      console.log(`  🔍 Caso especial: Atibaia identificado no destino, usando chave 12946-851`);
                    }
                    
                    // Caso específico: Jaú
                    if (!nomePersonalizado && 
                        (destino.includes('17320-015') || 
                        destino.includes('17320015') ||
                        destino.toLowerCase().includes('jaú'))) {
                      nomePersonalizado = customNames['17320-015'];
                      console.log(`  🔍 Caso especial: Jaú identificado no destino, usando chave 17320-015`);
                    }
                    
                    // Caso específico: Bauru
                    if (!nomePersonalizado && 
                        (destino.includes('17201-030') || 
                        destino.includes('17201030') ||
                        destino.toLowerCase().includes('bauru'))) {
                      nomePersonalizado = customNames['17201-030'];
                      console.log(`  🔍 Caso especial: Bauru identificado no destino, usando chave 17201-030`);
                    }
                    
                    return (
                      <>
                        {nomePersonalizado ? (
                          <>
                            <div className="text-sm font-medium">
                              <span className="bg-amber-100 text-amber-800 px-2 py-0.5 rounded border border-amber-300 text-sm shadow-sm">
                                {nomePersonalizado}
                              </span>
                            </div>
                            <p className="text-sm text-gray-700 mt-0.5">{destino}</p>
                          </>
                        ) : (
                          <p className="text-sm">{destino}</p>
                        )}
                      </>
                    );
                  })()
                ) : (
                  <p className="text-sm">Não especificado</p>
                )}
              </div>
            </div>
            
            {optimized && originalWaypointsOrder.length > 0 && (
              <div className="mt-3 bg-green-50 p-2 rounded-md text-xs text-green-700">
                <p className="font-semibold flex items-center gap-1">
                  <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M20 6 9 17l-5-5" />
                  </svg>
                  Rota otimizada para menor distância
                </p>
                <p>A ordem das paradas foi ajustada para economizar tempo e combustível.</p>
              </div>
            )}
          </div>
          
          <Separator className="my-2" />
          
          {/* Route statistics */}
          <div className="grid grid-cols-2 gap-y-2">
            <div className="col-span-2 font-medium flex items-center gap-2 text-blue-600">
              <span>Estatísticas da Viagem</span>
            </div>
            
            <div className="flex items-center gap-2">
              <RouteIcon size={14} className="text-gray-600" />
              <span className="text-sm">Distância:</span>
            </div>
            <div className="text-sm font-medium text-right">{distanciaTotal}</div>
            
            <div className="flex items-center gap-2">
              <Clock size={14} className="text-gray-600" />
              <span className="text-sm">Tempo:</span>
            </div>
            <div className="text-sm font-medium text-right">{tempoTotal}</div>
            
            <div className="flex items-center gap-2">
              <DollarSign size={14} className="text-gray-600" />
              <span className="text-sm">Pedágios:</span>
            </div>
            <div className="text-sm font-medium text-right">{valorPedagios || "N/A"}</div>
            
            <div className="flex items-center gap-2">
              <Truck size={14} className="text-gray-600" />
              <span className="text-sm">Veículo:</span>
            </div>
            <div className="text-sm font-medium text-right">
              {tipoVeiculo === "caminhao_2_eixos" ? "Caminhão 2 eixos" : 
               tipoVeiculo === "caminhao_3_eixos" ? "Caminhão 3 eixos" :
               tipoVeiculo === "caminhao_4_eixos" ? "Caminhão 4 eixos" :
               tipoVeiculo === "caminhao_5_eixos" ? "Caminhão 5 eixos" :
               tipoVeiculo === "caminhao_6_eixos" ? "Caminhão 6 eixos" :
               tipoVeiculo === "caminhao_7_eixos" ? "Caminhão 7 eixos" :
               tipoVeiculo === "caminhao_8_eixos" ? "Caminhão 8 eixos" :
               tipoVeiculo === "caminhao_9_eixos" ? "Caminhão 9 eixos" :
               tipoVeiculo}
            </div>
          </div>
          
          <Separator className="my-2" />
          
          {/* Cost estimates */}
          <div>
            <div className="font-medium flex items-center gap-2 text-blue-600 mb-2">
              <span>Estimativas de Custo</span>
            </div>
            
            <div className="bg-blue-50 p-3 rounded-md space-y-2">
              <div className="flex justify-between">
                <span className="text-sm">Combustível:</span>
                <span className="text-sm font-medium">
                  {formatCurrency(custoEstimadoCombustivel)}
                </span>
              </div>
              
              <div className="flex justify-between">
                <span className="text-sm">Pedágios:</span>
                <span className="text-sm font-medium">
                  {valorPedagios || "R$ 0,00"}
                </span>
              </div>
              
              <Separator className="my-1 bg-blue-200" />
              
              <div className="flex justify-between font-medium text-blue-800">
                <span className="text-sm">Total estimado:</span>
                <span className="text-sm">
                  {formatCurrency(custoEstimadoCombustivel + 
                     (valorPedagios ? parseFloat(valorPedagios.replace(/[^\d,]/g, '').replace(',', '.')) : 0)
                    )}
                </span>
              </div>
            </div>
          </div>
          
          {/* POIs summary */}
          {(numPedagios > 0 || numBalancas > 0) && (
            <>
              <Separator className="my-2" />
              
              <div>
                <div className="font-medium flex items-center gap-2 text-blue-600 mb-2">
                  <span>Pontos de Interesse</span>
                </div>
                
                <div className="space-y-1">
                  {numPedagios > 0 && (
                    <div className="flex items-center justify-between">
                      <span className="text-sm flex items-center gap-1">
                        <DollarSign size={14} className="text-amber-600" />
                        Pedágios na rota:
                      </span>
                      <span className="text-sm font-medium">{numPedagios}</span>
                    </div>
                  )}
                  
                  {numBalancas > 0 && (
                    <div className="flex items-center justify-between">
                      <span className="text-sm flex items-center gap-1">
                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-purple-600">
                          <circle cx="12" cy="12" r="10" />
                          <line x1="8" y1="3" x2="8" y2="21" />
                          <line x1="16" y1="3" x2="16" y2="21" />
                          <line x1="3" y1="8" x2="21" y2="8" />
                          <line x1="3" y1="16" x2="21" y2="16" />
                        </svg>
                        Balanças na rota:
                      </span>
                      <span className="text-sm font-medium">{numBalancas}</span>
                    </div>
                  )}
                </div>
              </div>
            </>
          )}
          
          {/* Truck Restrictions */}
          {restricoesCaminhoes.length > 0 && (
            <>
              <Separator className="my-2" />
              
              <div>
                <div className="font-medium flex items-center gap-2 text-amber-600 mb-2">
                  <Truck size={16} />
                  <span>Restrições para Caminhões</span>
                </div>
                
                <div className="bg-amber-50 border border-amber-200 rounded-md p-2">
                  <p className="text-sm text-amber-800 mb-2 flex items-start gap-1">
                    <AlertCircle size={14} className="min-w-[14px] mt-0.5" />
                    <span>Existem {restricoesCaminhoes.length} cidades na rota com restrições de tráfego</span>
                  </p>
                  
                  <div className="space-y-1">
                    {restricoesCaminhoes.map((restricao, index) => (
                      <div key={index} className="text-xs border-l-2 border-amber-300 pl-2 py-1">
                        <p className="font-medium text-amber-800">{restricao.cidade}-{restricao.uf}</p>
                        <p className="text-gray-700">{restricao.horarios.join(", ")} ({restricao.diasSemana[0]})</p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </>
          )}
          
          {/* Events during delivery period */}
          {routeResult.dataInicioEntrega && routeResult.dataFimEntrega && (
            <>
              <Separator className="my-2" />
              
              <div>
                <div className="font-medium flex items-center gap-2 text-purple-600 mb-2">
                  <Calendar size={16} />
                  <span>Período de Entrega</span>
                </div>
                
                <div className="bg-purple-50 border border-purple-200 rounded-md p-2 mb-2">
                  <div className="flex justify-between text-sm">
                    <div>
                      <span className="text-purple-700 font-medium">Início:</span>
                      <span className="ml-1 text-purple-900">{routeResult.dataInicioEntrega}</span>
                    </div>
                    <div>
                      <span className="text-purple-700 font-medium">Fim:</span>
                      <span className="ml-1 text-purple-900">{routeResult.dataFimEntrega}</span>
                    </div>
                  </div>
                </div>
                
                {eventosRota.length > 0 ? (
                  <div>
                    <div className="font-medium flex items-center gap-2 text-blue-600 mb-2">
                      <Gift size={16} />
                      <span>Eventos no Período</span>
                    </div>
                    
                    <div className="bg-blue-50 border border-blue-200 rounded-md p-2">
                      <div className="space-y-1">
                        {eventosRota.map((evento, index) => (
                          <div key={index} className="text-xs border-l-2 border-blue-300 pl-2 py-1">
                            <p className="font-medium text-blue-800">{evento.nome}</p>
                            <p className="text-gray-700">{evento.data} - {evento.tipo}</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="text-sm text-gray-500 italic text-center">
                    Nenhum evento ou feriado durante o período
                  </div>
                )}
              </div>
            </>
          )}

          {/* Alternative routes */}
          {(tempoMelhor || distanciaMelhor) && (
            <>
              <Separator className="my-2" />
              
              <div>
                <div className="font-medium flex items-center gap-2 text-blue-600 mb-2">
                  <span>Rotas Alternativas</span>
                </div>
                
                <div className="space-y-2">
                  {distanciaMelhor && routeResult.distanciaNumerica && (
                    <div className="text-sm">
                      <span className="text-green-600 font-medium">Rota mais curta disponível:</span>
                      <p>Poupa {formatDistance(routeResult.distanciaNumerica - distanciaMelhor.distanciaNumerica)}</p>
                    </div>
                  )}
                  
                  {tempoMelhor && routeResult.tempoNumerico && (
                    <div className="text-sm">
                      <span className="text-green-600 font-medium">Rota mais rápida disponível:</span>
                      <p>Economiza {Math.round((routeResult.tempoNumerico - tempoMelhor.tempoNumerico) / 60)} minutos</p>
                    </div>
                  )}
                  
                  <Button variant="outline" size="sm" className="w-full text-xs">
                    Ver rotas alternativas
                  </Button>
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}