import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Award, TrendingDown, Fuel, Timer, Leaf, TrendingUp, DollarSign } from 'lucide-react';
// Definindo nossa própria interface de RouteResponse para o componente
interface RouteResponse {
  distanciaTotal: string;
  tempoTotal: string;
  origem: string;
  destino?: string;
  paradas?: string[];
  valorPedagios?: string;
  tipoVeiculo?: string;
  optimized?: boolean;
  rotasAlternativas?: Array<{
    destaque?: boolean;
    distanciaNumerica: number;
    tempoNumerico: number;
  }>;
}

interface RouteGameificationProps {
  routeResult: RouteResponse;
  onSaveAchievement?: (achievement: RouteAchievement) => void;
}

export interface RouteAchievement {
  id: string;
  title: string;
  description: string;
  points: number;
  earnedAt: Date;
  type: 'efficiency' | 'speed' | 'eco' | 'cost';
  routeDetails: {
    origem: string;
    destino?: string;
    paradas?: string[];
    distancia: string;
    tempo: string;
  };
}

export function RouteGameification({ routeResult, onSaveAchievement }: RouteGameificationProps) {
  const [score, setScore] = useState(0);
  const [achievements, setAchievements] = useState<RouteAchievement[]>([]);
  const [showBadge, setShowBadge] = useState(false);
  
  // Calcular pontuação com base na rota
  useEffect(() => {
    if (!routeResult) return;
    
    let baseScore = 100; // Pontuação base
    let earnedAchievements: RouteAchievement[] = [];
    
    // Verificar se a rota está otimizada
    if (routeResult.optimized) {
      baseScore += 50;
      earnedAchievements.push({
        id: `opt-${Date.now()}`,
        title: 'Otimizador de Rotas',
        description: 'Você economizou tempo e combustível usando a rota otimizada!',
        points: 50,
        earnedAt: new Date(),
        type: 'efficiency',
        routeDetails: {
          origem: routeResult.origem,
          destino: routeResult.paradas?.[routeResult.paradas.length - 1],
          paradas: routeResult.paradas,
          distancia: routeResult.distanciaTotal,
          tempo: routeResult.tempoTotal
        }
      });
    }
    
    // Verificar se tem rotas alternativas e está usando a mais curta
    if (routeResult.rotasAlternativas && routeResult.rotasAlternativas.length > 0) {
      const rotaPrincipal = routeResult.rotasAlternativas.find((r: any) => r.destaque);
      const rotasAlternativas = routeResult.rotasAlternativas.filter((r: any) => !r.destaque);
      
      if (rotaPrincipal && rotasAlternativas.length > 0) {
        // Verificar se a rota principal é a mais curta em distância
        const rotaMaisCurta = [...routeResult.rotasAlternativas].sort((a, b) => 
          a.distanciaNumerica - b.distanciaNumerica)[0];
        
        if (rotaPrincipal.distanciaNumerica === rotaMaisCurta.distanciaNumerica) {
          baseScore += 30;
          earnedAchievements.push({
            id: `short-${Date.now()}`,
            title: 'Economia de Combustível',
            description: 'Você escolheu a rota mais curta disponível!',
            points: 30,
            earnedAt: new Date(),
            type: 'eco',
            routeDetails: {
              origem: routeResult.origem,
              destino: routeResult.paradas?.[routeResult.paradas.length - 1],
              paradas: routeResult.paradas,
              distancia: routeResult.distanciaTotal,
              tempo: routeResult.tempoTotal
            }
          });
        }
        
        // Verificar se a rota principal é a mais rápida
        const rotaMaisRapida = [...routeResult.rotasAlternativas].sort((a, b) => 
          a.tempoNumerico - b.tempoNumerico)[0];
        
        if (rotaPrincipal.tempoNumerico === rotaMaisRapida.tempoNumerico) {
          baseScore += 20;
          earnedAchievements.push({
            id: `fast-${Date.now()}`,
            title: 'Velocidade Máxima',
            description: 'Você escolheu a rota mais rápida para o seu destino!',
            points: 20,
            earnedAt: new Date(),
            type: 'speed',
            routeDetails: {
              origem: routeResult.origem,
              destino: routeResult.paradas?.[routeResult.paradas.length - 1],
              paradas: routeResult.paradas,
              distancia: routeResult.distanciaTotal,
              tempo: routeResult.tempoTotal
            }
          });
        }
      }
    }
    
    // Verificar a eficiência de custo com base nos pedágios
    if (routeResult.valorPedagios) {
      // Remover o símbolo R$ e converter para número
      const valorPedagio = parseFloat(routeResult.valorPedagios.replace('R$ ', '').replace(',', '.'));
      
      // Distância numérica em km
      const distanciaKm = parseFloat(routeResult.distanciaTotal.replace(' km', '').replace(',', '.'));
      
      // Calcular custo por km
      const custoPorKm = valorPedagio / distanciaKm;
      
      if (custoPorKm < 0.2) { // Menos de 20 centavos por km é eficiente
        baseScore += 40;
        earnedAchievements.push({
          id: `cost-${Date.now()}`,
          title: 'Economia em Pedágios',
          description: 'Excelente relação custo-benefício nos pedágios desta rota!',
          points: 40,
          earnedAt: new Date(),
          type: 'cost',
          routeDetails: {
            origem: routeResult.origem,
            destino: routeResult.paradas?.[routeResult.paradas.length - 1],
            paradas: routeResult.paradas,
            distancia: routeResult.distanciaTotal,
            tempo: routeResult.tempoTotal
          }
        });
      }
    }
    
    // Atualizar a pontuação e conquistas
    setScore(baseScore);
    setAchievements(earnedAchievements);
    
    // Exibir notificação de novas conquistas
    if (earnedAchievements.length > 0) {
      setShowBadge(true);
      setTimeout(() => setShowBadge(false), 5000);
      
      // Chamar callback se fornecido
      if (onSaveAchievement) {
        earnedAchievements.forEach(achievement => {
          onSaveAchievement(achievement);
        });
      }
    }
  }, [routeResult, onSaveAchievement]);
  
  // Determinar o nível com base na pontuação
  const getNível = (pontos: number) => {
    if (pontos < 100) return 'Iniciante';
    if (pontos < 150) return 'Navegador Bronze';
    if (pontos < 200) return 'Navegador Prata'; 
    return 'Navegador Ouro';
  };

  // Ícone para cada tipo de conquista
  const getAchievementIcon = (type: string) => {
    switch (type) {
      case 'efficiency': return <TrendingDown className="h-4 w-4 text-blue-500" />;
      case 'speed': return <Timer className="h-4 w-4 text-amber-500" />;
      case 'eco': return <Leaf className="h-4 w-4 text-green-500" />;
      case 'cost': return <DollarSign className="h-4 w-4 text-emerald-500" />;
      default: return <Award className="h-4 w-4" />;
    }
  };
  
  return (
    <Card className="w-full">
      <CardHeader>
        <div className="flex justify-between items-center">
          <CardTitle>Eficiência da Rota</CardTitle>
          {showBadge && (
            <Badge variant="outline" className="bg-green-100 text-green-800 animate-pulse">
              + {achievements.reduce((sum, a) => sum + a.points, 0)} pontos!
            </Badge>
          )}
        </div>
        <CardDescription>
          Sua pontuação de eficiência para esta rota
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex justify-between items-center">
          <div className="flex flex-col">
            <span className="text-xl font-bold">{score} pontos</span>
            <span className="text-sm text-muted-foreground">{getNível(score)}</span>
          </div>
          <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
            <Award className="h-6 w-6 text-primary" />
          </div>
        </div>
        
        <Progress value={score} max={200} className="h-2 w-full" />
        
        {achievements.length > 0 && (
          <div className="space-y-3 pt-2">
            <h4 className="text-sm font-medium">Conquistas nesta rota:</h4>
            <div className="space-y-2">
              {achievements.map(achievement => (
                <div key={achievement.id} className="flex items-center gap-2 bg-muted/50 p-2 rounded">
                  {getAchievementIcon(achievement.type)}
                  <div className="flex-1">
                    <p className="font-medium text-sm">{achievement.title}</p>
                    <p className="text-xs text-muted-foreground">{achievement.description}</p>
                  </div>
                  <Badge variant="secondary">+{achievement.points}</Badge>
                </div>
              ))}
            </div>
          </div>
        )}
      </CardContent>
      <CardFooter className="flex justify-between border-t pt-4">
        <div className="text-xs text-muted-foreground">
          {routeResult.distanciaTotal} • {routeResult.tempoTotal}
        </div>
        <div className="flex items-center gap-2">
          <Fuel className="h-4 w-4 text-muted-foreground" />
          <span className="text-xs text-muted-foreground">
            Economia estimada: 
            {Math.round(score / 10)}%
          </span>
        </div>
      </CardFooter>
    </Card>
  );
}