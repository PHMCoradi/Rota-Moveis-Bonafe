import React, { useState, useEffect } from 'react';
import { Marker, Popup, useMap } from 'react-leaflet';
import L from 'leaflet';
import { 
  Utensils, 
  Building2, 
  Pill, 
  HeartPulse,
  DollarSign,
  Fuel,
  Scale,
  Layers
} from 'lucide-react';

interface PointOfInterest {
  position: [number, number];
  name: string;
  type: 'restaurant' | 'market' | 'pharmacy' | 'hospital' | 'tollbooth' | 'gasstation' | 'weighingstation';
  address?: string;
  details?: string;
}

// Definição de tipo para os ícones das camadas
type POIType = 'restaurant' | 'market' | 'pharmacy' | 'hospital' | 'tollbooth' | 'gasstation' | 'weighingstation';

interface PointsOfInterestProps {
  center: [number, number] | [number, number][];
}

/**
 * Cria um ícone personalizado para os diferentes tipos de pontos de interesse
 */
function createPoiIcon(type: string): L.DivIcon {
  let icon;
  let backgroundColor;
  let title;

  switch(type) {
    case 'restaurant':
      icon = `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 13.87A4 4 0 0 1 7.41 6a5.11 5.11 0 0 1 1.05-1.54 5 5 0 0 1 7.08 0A5.11 5.11 0 0 1 16.59 6 4 4 0 0 1 18 13.87V21H6Z"></path><line x1="6" x2="18" y1="17" y2="17"></line></svg>`;
      backgroundColor = '#ef4444'; // Vermelho
      title = 'Restaurante';
      break;
    case 'market':
      icon = `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4Z"></path><path d="M3 6h18"></path><path d="M16 10a4 4 0 0 1-8 0"></path></svg>`;
      backgroundColor = '#3b82f6'; // Azul
      title = 'Mercado';
      break;
    case 'pharmacy':
      icon = `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 3h-4a2 2 0 0 0-2 2v12a3 3 0 0 0 3 3v1a1 1 0 0 0 1 1h0a1 1 0 0 0 1-1v-1a3 3 0 0 0 3-3V5a2 2 0 0 0-2-2Z"></path><path d="M13 3H9a2 2 0 0 0-2 2v12a3 3 0 0 0 3 3v1a1 1 0 0 0 1 1h0a1 1 0 0 0 1-1v-1a3 3 0 0 0 3-3V5a2 2 0 0 0-2-2Z"></path><path d="M3 15h8"></path><path d="M3 9h6"></path></svg>`;
      backgroundColor = '#22c55e'; // Verde
      title = 'Farmácia';
      break;
    case 'hospital':
      icon = `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 13V6a2 2 0 0 0-2-2H7a2 2 0 0 0-2 2v7"></path><path d="M12 4v16"></path><path d="M17 18h1a2 2 0 0 0 2-2v-3"></path><path d="M6 17a2 2 0 0 0 2 2h1"></path><path d="M16 8h-2"></path><path d="M10 8H8"></path></svg>`;
      backgroundColor = '#a855f7'; // Roxo
      title = 'Hospital';
      break;
    case 'tollbooth':
      icon = `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path></svg>`;
      backgroundColor = '#f59e0b'; // Âmbar
      title = 'Pedágio';
      break;
    case 'gasstation':
      icon = `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 19h16"></path><path d="M4 15h16"></path><path d="M4 11h16"></path><path d="M4 7h10"></path><rect width="16" height="20" x="4" y="2" rx="2"></rect><path d="M22 2v12a4 4 0 0 1-4 4h-4V2Z"></path></svg>`;
      backgroundColor = '#ca8a04'; // Amarelo escuro
      title = 'Posto de Combustível';
      break;
    case 'weighingstation':
      icon = `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 3a1 1 0 0 1 1-1h5a1 1 0 0 1 1 1v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V3Z"></path><path d="M14 12a1 1 0 0 1 1-1h5a1 1 0 0 1 1 1v5a1 1 0 0 1-1 1h-5a1 1 0 0 1-1-1v-5Z"></path><path d="M4 12a1 1 0 0 1 1-1h5a1 1 0 0 1 1 1v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1v-5Z"></path><path d="M14 3a1 1 0 0 1 1-1h5a1 1 0 0 1 1 1v5a1 1 0 0 1-1 1h-5a1 1 0 0 1-1-1V3Z"></path><path d="M4 21h17"></path><circle cx="12" cy="12" r="1"></circle></svg>`;
      backgroundColor = '#475569'; // Cinza escuro
      title = 'Balança';
      break;
    default:
      icon = `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="12" x2="12" y1="8" y2="16"></line><line x1="8" x2="16" y1="12" y2="12"></line></svg>`;
      backgroundColor = '#6b7280'; // Cinza
      title = 'Ponto de Interesse';
  }

  return L.divIcon({
    className: 'custom-poi-icon',
    html: `
      <div style="
        background-color: ${backgroundColor}; 
        width: 32px; 
        height: 32px; 
        display: flex; 
        align-items: center; 
        justify-content: center; 
        border-radius: 50%; 
        color: white; 
        font-weight: bold; 
        font-size: 14px;
        border: 2px solid white;
        box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.25);
      " title="${title}">
        ${icon}
      </div>
    `,
    iconSize: [32, 32],
    iconAnchor: [16, 16]
  });
}

export function PointsOfInterest({ center }: PointsOfInterestProps) {
  const [pois, setPois] = useState<PointOfInterest[]>([]);
  const [visibleLayers, setVisibleLayers] = useState<Record<POIType, boolean>>({
    restaurant: false,
    market: false,
    pharmacy: false,
    hospital: false,
    tollbooth: false, // Todos desabilitados por padrão conforme solicitação
    gasstation: false, 
    weighingstation: false
  });
  
  // Estado para controlar a visibilidade do menu de camadas
  const [menuVisible, setMenuVisible] = useState(false);
  
  // Referência ao mapa
  const map = useMap();
  
  // Configuração de ícones e cores para os tipos de POI
  const poiConfig = {
    restaurant: { icon: <Utensils size={16} />, color: '#ef4444', label: 'Restaurantes' },
    market: { icon: <Building2 size={16} />, color: '#3b82f6', label: 'Mercados' },
    pharmacy: { icon: <Pill size={16} />, color: '#22c55e', label: 'Farmácias' },
    hospital: { icon: <HeartPulse size={16} />, color: '#a855f7', label: 'Hospitais' },
    tollbooth: { icon: <DollarSign size={16} />, color: '#f59e0b', label: 'Pedágios' },
    gasstation: { icon: <Fuel size={16} />, color: '#ca8a04', label: 'Postos' },
    weighingstation: { icon: <Scale size={16} />, color: '#475569', label: 'Balanças' }
  };
  
  // Alternar a visibilidade de uma camada
  const toggleLayer = (type: POIType) => {
    setVisibleLayers(prev => ({
      ...prev,
      [type]: !prev[type]
    }));
  };
  
  // Efeito para gerar pontos de interesse quando o centro muda
  useEffect(() => {
    // Lista para armazenar os POIs gerados
    const generatedPois: PointOfInterest[] = [];
    
    // Função para adicionar POIs em torno de uma coordenada
    const addPoisAroundPoint = (centerPoint: [number, number], idPrefix: string = '') => {
      // Funções para criar pontos de interesse de cada tipo
      const addRestaurants = () => {
        generatedPois.push({
          position: [centerPoint[0] - 0.005, centerPoint[1] + 0.004],
          name: "Restaurante Silva",
          type: "restaurant",
          address: "Rua das Flores, 123",
          details: "Especializado em comida caseira. Aberto das 11h às 15h."
        });
        
        generatedPois.push({
          position: [centerPoint[0] + 0.003, centerPoint[1] - 0.002],
          name: "Cantina Italiana Don Marco",
          type: "restaurant",
          address: "Av. Principal, 456",
          details: "Massas e pizzas. Aberto das 18h às 23h."
        });
      };
      
      const addMarkets = () => {
        generatedPois.push({
          position: [centerPoint[0] + 0.002, centerPoint[1] + 0.007],
          name: "Supermercado Central",
          type: "market",
          address: "Rua do Comércio, 789",
          details: "Aberto 24 horas."
        });
      };
      
      const addPharmacies = () => {
        generatedPois.push({
          position: [centerPoint[0] - 0.004, centerPoint[1] - 0.003],
          name: "Farmácia São José",
          type: "pharmacy",
          address: "Av. Saúde, 321",
          details: "Plantão 24h. Telefone: (11) 5555-1234"
        });
      };
      
      const addHospitals = () => {
        generatedPois.push({
          position: [centerPoint[0] - 0.007, centerPoint[1] + 0.005],
          name: "Hospital Santa Clara",
          type: "hospital",
          address: "Av. da Esperança, 1000",
          details: "Pronto socorro 24h. Telefone: (11) 5555-7890"
        });
      };
      
      const addTollbooths = () => {
        generatedPois.push({
          position: [centerPoint[0] + 0.01, centerPoint[1] - 0.005],
          name: "Pedágio Anhanguera",
          type: "tollbooth",
          address: "Rodovia Anhanguera, km 25",
          details: "Valor: R$ 13,40 para veículos de passeio"
        });
        
        generatedPois.push({
          position: [centerPoint[0] - 0.009, centerPoint[1] - 0.008],
          name: "Pedágio Bandeirantes",
          type: "tollbooth",
          address: "Rodovia dos Bandeirantes, km 32",
          details: "Valor: R$ 10,90 para veículos de passeio"
        });
      };
      
      const addGasStations = () => {
        generatedPois.push({
          position: [centerPoint[0] - 0.003, centerPoint[1] + 0.009],
          name: "Posto Shell",
          type: "gasstation",
          address: "Rodovia Washington Luís, km 216",
          details: "Gasolina: R$ 5,79/L - Diesel: R$ 4,99/L"
        });
        
        generatedPois.push({
          position: [centerPoint[0] + 0.008, centerPoint[1] + 0.003],
          name: "Posto Petrobras",
          type: "gasstation",
          address: "Rodovia Castello Branco, km 97",
          details: "Diesel S10: R$ 5,59/L - Etanol: R$ 3,99/L"
        });
      };
      
      const addWeighingStations = () => {
        generatedPois.push({
          position: [centerPoint[0] + 0.006, centerPoint[1] + 0.01],
          name: "Balança DER-SP",
          type: "weighingstation",
          address: "Rodovia SP-225, km 150",
          details: "Horário de funcionamento: 06h às 22h"
        });
      };

      // Adicionar todos os tipos de pontos de interesse
      addRestaurants();
      addMarkets();
      addPharmacies();
      addHospitals();
      addTollbooths();
      addGasStations();
      addWeighingStations();
      
      console.log(`Adicionados POIs ao redor de ${centerPoint[0]}, ${centerPoint[1]}`);
    };
    
    // Processar pontos de interesse com base no tipo de entrada
    if (Array.isArray(center) && Array.isArray(center[0])) {
      // É um array de pontos (múltiplas paradas)
      const centerPoints = center as [number, number][];
      centerPoints.forEach((point, index) => {
        addPoisAroundPoint(point, `p${index}_`);
      });
      console.log(`Adicionados ${generatedPois.length} pontos de interesse em ${centerPoints.length} locais`);
    } else {
      // É um ponto único (origem)
      const singlePoint = center as [number, number];
      addPoisAroundPoint(singlePoint);
      console.log(`Adicionados ${generatedPois.length} pontos de interesse ao redor de ${singlePoint[0]}, ${singlePoint[1]}`);
    }
    
    // Atualizar o estado com os pontos de interesse gerados
    setPois(generatedPois);
    
  }, [center]);

  return (
    <>
      {/* Pontos de interesse filtrados por tipo visível */}
      {pois.filter(poi => visibleLayers[poi.type]).map((poi, index) => (
        <Marker
          key={`${poi.type}-${index}`}
          position={poi.position}
          icon={createPoiIcon(poi.type)}
        >
          <Popup>
            <div className="space-y-1">
              <div className="flex items-center gap-1 font-medium" style={{ color: poiConfig[poi.type].color }}>
                <div className="h-4 w-4">{poiConfig[poi.type].icon}</div>
                <span>{poi.name}</span>
              </div>
              {poi.address && <p className="text-sm text-gray-600">{poi.address}</p>}
              {poi.details && <p className="text-xs">{poi.details}</p>}
            </div>
          </Popup>
        </Marker>
      ))}
      
      {/* Controle de camadas personalizado */}
      <div className="absolute top-3 left-3 z-[1000] bg-white rounded-md shadow-md">
        <button
          onClick={() => setMenuVisible(!menuVisible)}
          className="w-9 h-9 flex items-center justify-center bg-white rounded-md hover:bg-gray-100"
          title="Pontos de interesse"
        >
          <Layers size={20} />
        </button>
        
        {menuVisible && (
          <div className="absolute top-full left-0 mt-1 p-2 bg-white rounded-md shadow-md w-48">
            <h3 className="text-sm font-bold mb-2 px-1">Pontos de Interesse</h3>
            
            {(Object.keys(poiConfig) as POIType[]).map(type => (
              <div 
                key={type}
                className="flex items-center gap-2 p-1 hover:bg-gray-100 rounded cursor-pointer mb-1"
                onClick={() => toggleLayer(type)}
              >
                <div 
                  className="w-5 h-5 rounded-sm flex items-center justify-center"
                  style={{ backgroundColor: visibleLayers[type] ? poiConfig[type].color : 'transparent', border: `1px solid ${poiConfig[type].color}` }}
                >
                  {visibleLayers[type] && (
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
                      <polyline points="20 6 9 17 4 12"></polyline>
                    </svg>
                  )}
                </div>
                <div className="flex items-center gap-1 text-sm">
                  <div style={{ color: poiConfig[type].color }}>{poiConfig[type].icon}</div>
                  <span>{poiConfig[type].label}</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </>
  );
}