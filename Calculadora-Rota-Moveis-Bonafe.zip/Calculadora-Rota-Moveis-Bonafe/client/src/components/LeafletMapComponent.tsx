import { useEffect, useState, useRef } from 'react';
import { MapContainer, TileLayer, Polyline, Marker, Popup, ZoomControl, ScaleControl, useMap, useMapEvents, CircleMarker } from 'react-leaflet';
import L from 'leaflet';
import { Card, CardContent } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import 'leaflet/dist/leaflet.css';
import { RouteResponse } from '@shared/schema';
import { getHolidaysInDateRange } from '@/lib/holidays';
import { CalendarDays, RotateCcw, RotateCw } from 'lucide-react';

// Importar ícones do Leaflet (necessário para os marcadores)
import icon from 'leaflet/dist/images/marker-icon.png';
import iconShadow from 'leaflet/dist/images/marker-shadow.png';

// Corrigir o problema com os ícones do Leaflet no React e criar ícones personalizados
const DefaultIcon = L.icon({
  iconUrl: icon,
  shadowUrl: iconShadow,
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34]
});

const OriginIcon = L.icon({
  iconUrl: icon,
  shadowUrl: iconShadow,
  iconSize: [30, 45],
  iconAnchor: [15, 45],
  popupAnchor: [1, -34],
  className: 'origin-marker' // Classe CSS personalizada para o marcador de origem
});

const DestinationIcon = L.icon({
  iconUrl: icon,
  shadowUrl: iconShadow,
  iconSize: [30, 45],
  iconAnchor: [15, 45],
  popupAnchor: [1, -34],
  className: 'destination-marker' // Classe CSS personalizada para o marcador de destino
});

// Função para criar um marcador numerado e colorido
const createNumberedIcon = (number: number, color: string = '#f59e0b') => {
  // Criar um ícone personalizado usando HTML e CSS
  return L.divIcon({
    className: 'custom-number-marker',
    html: `<div style="background-color: ${color}; width: 24px; height: 24px; border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; font-weight: bold; border: 2px solid white; box-shadow: 0 2px 4px rgba(0,0,0,0.3);">${number}</div>`,
    iconSize: [24, 24],
    iconAnchor: [12, 12],
    popupAnchor: [0, -12]
  });
};

// Função para criar um ícone de feriado
const createHolidayIcon = () => {
  // Criar um ícone personalizado usando HTML e CSS
  return L.divIcon({
    className: 'holiday-marker',
    html: `<div style="width: 20px; height: 20px; display: flex; align-items: center; justify-content: center; position: relative;">
      <div style="background-color: #fbbf24; width: 16px; height: 16px; border-radius: 3px; transform: rotate(45deg); border: 1px solid #fff; box-shadow: 0 2px 4px rgba(0,0,0,0.2);"></div>
      <div style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; display: flex; align-items: center; justify-content: center;">
        <svg xmlns="http://www.w3.org/2000/svg" width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
          <line x1="16" y1="2" x2="16" y2="6"></line>
          <line x1="8" y1="2" x2="8" y2="6"></line>
          <line x1="3" y1="10" x2="21" y2="10"></line>
        </svg>
      </div>
    </div>`,
    iconSize: [20, 20],
    iconAnchor: [10, 10],
    popupAnchor: [0, -10]
  });
};

// Atualiza o ícone padrão para os marcadores
if (L.Marker && L.Marker.prototype.options) {
  L.Marker.prototype.options.icon = DefaultIcon;
}

// Adicionar estilos CSS personalizados para os marcadores
const styleSheet = document.createElement('style');
styleSheet.type = 'text/css';
styleSheet.innerText = `
  .origin-marker img {
    filter: hue-rotate(120deg); /* Verde */
    z-index: 1000 !important;
  }
  .destination-marker img {
    filter: hue-rotate(240deg); /* Azul */
    z-index: 1000 !important;
  }
`;
document.head.appendChild(styleSheet);

interface MapComponentProps {
  routeResult: RouteResponse | null;
}

// Decodifica um polyline, tratando o encoding do OSRM que usa precision 6
function decodePolyline(encoded: string): [number, number][] {
  if (!encoded || encoded.length === 0) {
    console.error("Polyline vazio recebido");
    return [];
  }
  
  console.log(`Decodificando polyline com comprimento ${encoded.length}`);
  
  try {
    // OSRM usa 6 dígitos de precisão com polyline6
    const precision = 6;
    const factor = Math.pow(10, precision);
    
    const poly: [number, number][] = [];
    let index = 0;
    let lat = 0;
    let lng = 0;

    while (index < encoded.length) {
      let b;
      let shift = 0;
      let result = 0;

      // Decodificar latitude
      do {
        b = encoded.charCodeAt(index++) - 63;
        result |= (b & 0x1f) << shift;
        shift += 5;
      } while (b >= 0x20);
      const dlat = ((result & 1) !== 0 ? ~(result >> 1) : (result >> 1));
      lat += dlat;

      // Decodificar longitude
      shift = 0;
      result = 0;
      do {
        b = encoded.charCodeAt(index++) - 63;
        result |= (b & 0x1f) << shift;
        shift += 5;
      } while (b >= 0x20);
      const dlng = ((result & 1) !== 0 ? ~(result >> 1) : (result >> 1));
      lng += dlng;

      // CORREÇÃO CRÍTICA:
      // OSRM retorna coordenadas no formato [longitude, latitude]
      // Mas o Leaflet espera no formato [latitude, longitude]
      // Além disso, dividimos por factor para obter as coordenadas reais
      const pointLat = lat / factor;
      const pointLng = lng / factor;
      
      // Verificar se são coordenadas válidas (dentro dos limites de lat/lng)
      if (Math.abs(pointLat) <= 90 && Math.abs(pointLng) <= 180) {
        poly.push([pointLat, pointLng]);
      } else {
        // Se estiverem invertidas, corrigir automaticamente
        if (Math.abs(pointLng) <= 90 && Math.abs(pointLat) <= 180) {
          poly.push([pointLng, pointLat]);
        } else {
          console.warn(`Coordenadas inválidas ignoradas: [${pointLat}, ${pointLng}]`);
        }
      }
    }

    // Verificar amostras do resultado para depuração
    if (poly.length > 0) {
      console.log("POLYLINE - Primeiros pontos (brutos):", poly.slice(0, 3));
      console.log("POLYLINE - Últimos pontos (brutos):", poly.slice(-3));
      
      // Fazer uma análise para determinar a melhor maneira de normalizar os pontos
      // OSRM retorna coordenadas com 6 dígitos de precisão que podem precisar de normalização
      const firstPoint = poly[0];
      
      // Verificar em qual formato as coordenadas estão sendo retornadas
      console.log("Primeiro ponto bruto:", firstPoint);
      console.log("Faixa típica: lat: -90 a 90, lng: -180 a 180");
      
      // 1. Se os valores forem muito grandes (por exemplo, -223.x), precisamos ajustar
      if (Math.abs(firstPoint[0]) > 90 || Math.abs(firstPoint[1]) > 180) {
        console.log("CORREÇÃO: Valores fora da faixa normal, aplicando normalização");
        const normalized = poly.map(p => {
          // Dividir por 10000 para obter valores dentro da faixa normal
          return [p[0] / 10000, p[1] / 10000] as [number, number];
        });
        
        console.log("Após normalização:", normalized[0]);
        
        // O OSRM retorna as coordenadas como [longitude, latitude], mas o Leaflet espera [latitude, longitude]
        const inverted = normalized.map(p => [p[1], p[0]] as [number, number]);
        console.log("Após inversão:", inverted[0]);
        return inverted;
      }
      
      // 2. Se os valores forem muito pequenos, podem precisar ser ampliados
      if (Math.abs(firstPoint[0]) < 0.01 || Math.abs(firstPoint[1]) < 0.01) {
        console.log("CORREÇÃO: Valores muito pequenos, aplicando amplificação");
        const amplified = poly.map(p => {
          return [p[0] * 100, p[1] * 100] as [number, number];
        });
        
        console.log("Após amplificação:", amplified[0]);
        
        // O OSRM retorna as coordenadas como [longitude, latitude], mas o Leaflet espera [latitude, longitude]
        const inverted = amplified.map(p => [p[1], p[0]] as [number, number]);
        console.log("Após inversão:", inverted[0]);
        return inverted;
      }
      
            // SOLUÇÃO RADICAL: FORÇAR COORDENADAS PARA O FORMATO CORRETO
      
      // O Leaflet trabalha com coordenadas no formato [lat, lng]
      // Precisamos garantir que os pontos estejam nesse formato
      
      // 1. Verificar formato: Em SP, latitude deve ser ~ -22 e longitude ~ -48
      // 2. Forçar o formato correto independente de como os dados chegam
      
      // FORÇANDO CORREÇÃO (coordenadas brasileiras):
      const correctedPoints: [number, number][] = [];
      
      for (let i = 0; i < poly.length; i++) {
        const point = poly[i];
        let lat = point[0];
        let lng = point[1];
        
        // Verificar se os pontos parecem estar no formato errado
        if (Math.abs(lat) > 40 && Math.abs(lat) < 60) {
          // Se latitude parece ser longitude (próximo de -48), trocamos
          correctedPoints.push([point[1], point[0]]);
        } else {
          // Se latitude parece estar correta (próximo de -22), não trocamos
          correctedPoints.push([point[0], point[1]]);
        }
      }
      
      console.log("CORREÇÃO FINAL:", correctedPoints[0]);
      return correctedPoints;
    }

    return [];
  } catch (error) {
    console.error("Erro ao decodificar polyline:", error);
    return [];
  }
}

// Componente para debugar a rota no mapa
function MapDebugger({ positions }: { positions: [number, number][] }) {
  const map = useMap();
  const polylineRef = useRef<L.Polyline | null>(null);
  const secondaryLineRef = useRef<L.Polyline | null>(null);
  
  // Modo de debug ativado/desativado
  const debugMode = false;
  
  useEffect(() => {
    console.log("MapDebugger montado com", positions.length, "pontos");
    
    // Remover polylines anteriores se existirem
    if (polylineRef.current) {
      map.removeLayer(polylineRef.current);
      polylineRef.current = null;
    }
    
    if (secondaryLineRef.current) {
      map.removeLayer(secondaryLineRef.current);
      secondaryLineRef.current = null;
    }
    
    // Verificar se há pontos e se são válidos
    if (positions.length > 0) {
      try {
        // Criar bounds para os pontos
        const bounds = L.latLngBounds(positions);
        map.fitBounds(bounds, { padding: [50, 50] });
        
        // Mostrar os primeiros e últimos pontos no console para depuração
        console.log("DEBUG - Primeiros pontos:", positions.slice(0, 2));
        console.log("DEBUG - Últimos pontos:", positions.slice(-2));
        
        // Adicionar linhas apenas no modo de debug
        if (debugMode) {
          // Criar linha diretamente usando L (para debug)
          polylineRef.current = L.polyline(positions, { 
            color: '#FF0000', 
            weight: 8,
            opacity: 0.8,
            smoothFactor: 1
          }).addTo(map);
          
          // Adicionar um segundo polyline com uma borda mais clara
          secondaryLineRef.current = L.polyline(positions, { 
            color: '#FFAA00', 
            weight: 4,
            opacity: 1,
            smoothFactor: 1
          }).addTo(map);
          
          console.log("Linhas de debug adicionadas ao mapa");
        }
      } catch (error) {
        console.error("Erro ao criar linha da rota:", error);
      }
    }
    
    return () => {
      // Cleanup: remover a linha quando o componente for desmontado
      if (polylineRef.current) {
        map.removeLayer(polylineRef.current);
        polylineRef.current = null;
      }
      
      if (secondaryLineRef.current) {
        map.removeLayer(secondaryLineRef.current);
        secondaryLineRef.current = null;
      }
    };
  }, [positions, map, debugMode]);
  
  return null;
}

// Componente para rotação do mapa
function MapRotationControls() {
  const map = useMap();
  const [rotation, setRotation] = useState(0);
  
  // Função para girar o mapa em 15 graus no sentido horário
  const rotateClockwise = () => {
    const newRotation = rotation + 15;
    setRotation(newRotation);
    // Aplicar a rotação usando CSS transform
    const mapContainer = map.getContainer();
    const mapPane = mapContainer.querySelector('.leaflet-map-pane') as HTMLElement | null;
    if (mapPane) {
      mapPane.style.transform = `${mapPane.style.transform.replace(/rotate\(-?\d+deg\)/, '')} rotate(${newRotation}deg)`;
    }
  };
  
  // Função para girar o mapa em 15 graus no sentido anti-horário
  const rotateCounterclockwise = () => {
    const newRotation = rotation - 15;
    setRotation(newRotation);
    // Aplicar a rotação usando CSS transform
    const mapContainer = map.getContainer();
    const mapPane = mapContainer.querySelector('.leaflet-map-pane') as HTMLElement | null;
    if (mapPane) {
      mapPane.style.transform = `${mapPane.style.transform.replace(/rotate\(-?\d+deg\)/, '')} rotate(${newRotation}deg)`;
    }
  };
  
  // Função para resetar a rotação
  const resetRotation = () => {
    setRotation(0);
    const mapContainer = map.getContainer();
    const mapPane = mapContainer.querySelector('.leaflet-map-pane') as HTMLElement | null;
    if (mapPane) {
      mapPane.style.transform = mapPane.style.transform.replace(/rotate\(-?\d+deg\)/, '');
    }
  };
  
  return (
    <div className="absolute bottom-16 right-3 z-[1000] bg-white rounded-md shadow-md p-1 flex flex-col space-y-1">
      <button 
        className="p-2 bg-blue-500 text-white rounded-md hover:bg-blue-600" 
        onClick={rotateClockwise}
        title="Girar no sentido horário"
      >
        <RotateCw size={16} />
      </button>
      <button 
        className="p-2 bg-blue-500 text-white rounded-md hover:bg-blue-600" 
        onClick={rotateCounterclockwise}
        title="Girar no sentido anti-horário"
      >
        <RotateCcw size={16} />
      </button>
      {rotation !== 0 && (
        <button 
          className="p-2 bg-gray-200 text-gray-700 rounded-md hover:bg-gray-300" 
          onClick={resetRotation}
          title="Restaurar rotação"
        >
          <span className="text-xs font-bold">0°</span>
        </button>
      )}
    </div>
  );
}

// Componente para detectar e mostrar localização atual
function LocationMarker() {
  // Coordenadas de São Paulo capital como padrão quando geolocalização falhar
  const [position, setPosition] = useState<[number, number] | null>(null);
  const [accuracy, setAccuracy] = useState<number | null>(null);
  const [locationFound, setLocationFound] = useState(false);
  const [locationError, setLocationError] = useState(false);
  const map = useMap();

  useEffect(() => {
    // Tentar localizar o usuário assim que o componente for montado
    map.locate({ setView: true, maxZoom: 14, timeout: 10000 });
    
    // Definir um temporizador de fallback caso a geolocalização demore muito
    const timeoutId = setTimeout(() => {
      if (!locationFound && !locationError) {
        console.log('Timeout de geolocalização, usando localização padrão de Dois Córregos-SP');
        const defaultLocation: [number, number] = [-22.3673, -48.3844]; // Centro de Dois Córregos
        setPosition(defaultLocation);
        setAccuracy(500); // Precisão média para cidade
        setLocationFound(true);
        setLocationError(true); // Indicar que é localização padrão
        map.flyTo(defaultLocation, 12); // Zoom menor para mostrar a cidade inteira
      }
    }, 12000);
    
    return () => clearTimeout(timeoutId);
  }, [map, locationFound, locationError]);

  // Configurar eventos do mapa para localização
  useMapEvents({
    locationfound(e) {
      console.log('Localização encontrada:', e.latlng);
      
      // Verificar se a localização está próxima de Bauru (provavelmente mock do Replit)
      const isBauruMockLocation = 
        Math.abs(e.latlng.lat - (-22.3346)) < 0.01 && 
        Math.abs(e.latlng.lng - (-49.0612)) < 0.01;
      
      if (isBauruMockLocation) {
        console.log('Detectada localização mockada de Bauru, usando Dois Córregos-SP como fallback');
        const defaultLocation: [number, number] = [-22.3673, -48.3844]; // Centro de Dois Córregos
        setPosition(defaultLocation);
        setAccuracy(500); // Precisão média para cidade
        setLocationFound(true);
        setLocationError(true);
        map.flyTo(defaultLocation, 12); // Zoom menor para mostrar a cidade inteira
      } else {
        // Usar localização real detectada
        const pos: [number, number] = [e.latlng.lat, e.latlng.lng];
        setPosition(pos);
        setAccuracy(e.accuracy);
        setLocationFound(true);
        map.flyTo(e.latlng, Math.min(14, map.getZoom()));
      }
    },
    locationerror(e) {
      console.log('Erro ao obter localização:', e.message);
      setLocationError(true);
      
      // Usar localização padrão de Dois Córregos quando há erro
      const defaultLocation: [number, number] = [-22.3673, -48.3844]; // Centro de Dois Córregos
      setPosition(defaultLocation);
      setAccuracy(500); // Precisão média para cidade
      setLocationFound(true);
      map.flyTo(defaultLocation, 12); // Zoom menor para mostrar a cidade inteira
    }
  });

  return locationFound && position ? (
    <>
      {/* Círculo mostrando precisão da localização */}
      {accuracy && (
        <CircleMarker 
          center={position} 
          radius={20}
          pathOptions={{ 
            color: '#3B82F6', 
            fillColor: '#93C5FD', 
            fillOpacity: 0.3 
          }} 
        >
          <Popup>
            <div className="text-center">
              <p className="font-medium">Sua localização {locationError ? 'padrão (Dois Córregos)' : 'atual'}</p>
              {!locationError && <p className="text-xs text-gray-500">Precisão: ±{Math.round(accuracy)} metros</p>}
              {locationError && <p className="text-xs text-gray-500">Dois Córregos, SP</p>}
            </div>
          </Popup>
        </CircleMarker>
      )}
      {/* Marcador da localização atual */}
      <Marker position={position} icon={createNumberedIcon(0, '#3B82F6')}>
        <Popup>
          <div className="text-center">
            <p className="font-medium">Sua localização {locationError ? 'padrão (Dois Córregos)' : 'atual'}</p>
            <p className="text-xs text-gray-500">Coordenadas: {position[0].toFixed(5)}, {position[1].toFixed(5)}</p>
            {locationError && (
              <>
                <p className="text-xs text-gray-500">Dois Córregos - SP</p>
              </>
            )}
          </div>
        </Popup>
      </Marker>
    </>
  ) : null;
}

// Função auxiliar para extrair nome da cidade
const extrairCidade = (endereco?: string): string => {
  if (!endereco) return '';
  
  console.log(`Extraindo cidade de: ${endereco}`);
  
  // Verificar se o endereço já está no formato "Cidade-UF"
  if (endereco.includes('-') && endereco.split('-').length === 2) {
    console.log(`Já está no formato Cidade-UF: ${endereco}`);
    return endereco;
  }
  
  // Para "Ribeirão Preto", "Ribeirão Preto, SP", etc.
  if (endereco.includes('Ribeirão Preto')) {
    console.log(`Cidade especial encontrada: Ribeirão Preto`);
    // Verificar se já tem UF
    if (endereco.includes('SP') || endereco.includes('sp')) {
      return 'Ribeirão Preto-SP';
    }
    return 'Ribeirão Preto-SP'; // Adiciona UF por padrão
  }
  
  // Tenta extrair no formato "Cidade-UF" ou "Cidade, UF"
  const cidadeComEstado = endereco.match(/([A-Za-zÀ-ÖØ-öø-ÿ\s]+)[-,]\s*([A-Z]{2})/);
  if (cidadeComEstado && cidadeComEstado[1] && cidadeComEstado[2]) {
    const resultado = cidadeComEstado[1].trim() + "-" + cidadeComEstado[2].trim();
    console.log(`Extraído com regex: ${resultado}`);
    return resultado;
  }
  
  // Tenta extrair somente a cidade
  const cidade = endereco.split(",")[0];
  if (cidade) {
    console.log(`Extraído pela vírgula: ${cidade.trim()}`);
    return cidade.trim();
  }
  
  console.log(`Nenhum padrão encontrado, retornando o endereço completo`);
  return endereco;
};

// Definição dos tipos de mapa disponíveis
type MapType = 'standard' | 'satellite' | 'panorama';

export function LeafletMapComponent({ routeResult }: MapComponentProps) {
  const [positions, setPositions] = useState<[number, number][]>([]);
  const [waypoints, setWaypoints] = useState<[number, number][]>([]);
  const [center, setCenter] = useState<[number, number]>([-22.3673, -48.3844]); // Centro de Dois Córregos
  const [zoom, setZoom] = useState(12); // Zoom inicial para mostrar a cidade inteira
  const [mapKey, setMapKey] = useState(0); // Usado para forçar recriação do mapa quando necessário
  const [holidays, setHolidays] = useState<{ cityName: string; holidayInfo: string; position: [number, number] }[]>([]);
  const [mapType, setMapType] = useState<MapType>('standard'); // Novo estado para tipo de mapa, padrão para standard
  
  // Estado para monitorar se o mapa está pronto para uso
  const [mapReady, setMapReady] = useState(false);
  
  // Referência para o mapa do Leaflet
  const mapRef = useRef<L.Map | null>(null);
  
  // Função para renderizar o seletor de tipo de mapa
  const MapTypeSelector = () => {
    return (
      <div className="absolute top-3 right-3 z-[1000] bg-white rounded-md shadow-md">
        <div className="flex flex-wrap p-1 gap-1">
          <button 
            className={`px-3 py-1 text-xs font-medium rounded-sm ${mapType === 'standard' ? 'bg-blue-500 text-white' : 'bg-gray-200 text-gray-700 hover:bg-gray-300'}`}
            onClick={() => setMapType('standard')}
          >
            Padrão
          </button>
          <button 
            className={`px-3 py-1 text-xs font-medium rounded-sm ${mapType === 'satellite' ? 'bg-blue-500 text-white' : 'bg-gray-200 text-gray-700 hover:bg-gray-300'}`}
            onClick={() => setMapType('satellite')}
          >
            Satélite
          </button>
          <button 
            className={`px-3 py-1 text-xs font-medium rounded-sm ${mapType === 'panorama' ? 'bg-blue-500 text-white' : 'bg-gray-200 text-gray-700 hover:bg-gray-300'}`}
            onClick={() => setMapType('panorama')}
          >
            Panorama 360°
          </button>
        </div>
      </div>
    );
  };
  
  // Função de utilidade para verificar se um array de coordenadas é válido
  const isValidCoord = (coord: any): boolean => {
    return Array.isArray(coord) && 
           coord.length === 2 && 
           !isNaN(Number(coord[0])) && 
           !isNaN(Number(coord[1])) &&
           Math.abs(coord[0]) <= 90 && 
           Math.abs(coord[1]) <= 180;
  };

  // Processar feriados quando houver dados de rota e datas
  useEffect(() => {
    if (routeResult && routeResult.dataInicio && routeResult.dataFim) {
      console.log("Verificando feriados para intervalo: ", routeResult.dataInicio, "a", routeResult.dataFim);
      
      // Obter lista de cidades na rota (origem, paradas)
      const cidades = [routeResult.origem].concat(
        routeResult.optimized && routeResult.optimizedWaypointsOrder 
        ? routeResult.optimizedWaypointsOrder 
        : routeResult.paradas || []
      ).filter(Boolean).map(cidade => extrairCidade(cidade));
      
      console.log("Cidades na rota para verificar feriados:", cidades);
      
      // Obter feriados dentro do intervalo para estas cidades
      const feriadosEncontrados = getHolidaysInDateRange(
        routeResult.dataInicio, 
        routeResult.dataFim, 
        cidades
      );
      
      console.log("Feriados encontrados no intervalo:", feriadosEncontrados);
      
      // Se encontrou feriados, criar marcadores para eles usando as coordenadas dos waypoints
      if (feriadosEncontrados.length > 0 && waypoints.length > 0) {
        const holidayMarkers = [];
        
        for (const feriado of feriadosEncontrados) {
          // Encontrar a cidade deste feriado na lista de cidades da rota
          const cidadeFeriado = feriado.cityName || '';
          console.log(`Processando feriado: ${feriado.name} em ${cidadeFeriado || 'Nacional'}`);
          
          // Procurar o índice da cidade na lista original
          let index = -1;
          
          if (cidadeFeriado) {  // Feriado municipal/estadual
            // Primeiro verificar na origem
            if (extrairCidade(routeResult.origem).includes(cidadeFeriado)) {
              index = 0; // A origem é o primeiro waypoint (índice 0)
              console.log(`Cidade do feriado encontrada na origem: ${cidadeFeriado}`);
            } else {
              // Procurar nas paradas
              let paradasParaVerificar = routeResult.paradas || [];
              
              // Se a rota foi otimizada, usar a ordem otimizada
              if (routeResult.optimized && routeResult.optimizedWaypointsOrder) {
                paradasParaVerificar = routeResult.optimizedWaypointsOrder;
              }
              
              // Verificar cada parada
              for (let i = 0; i < paradasParaVerificar.length; i++) {
                const paradaCidade = extrairCidade(paradasParaVerificar[i]);
                
                console.log(`Comparando '${paradaCidade}' com '${cidadeFeriado}'`);
                
                // Verificar se o nome da cidade da parada inclui o nome da cidade do feriado
                // ou se o nome da cidade do feriado inclui o nome da cidade da parada
                if (paradaCidade.includes(cidadeFeriado) || cidadeFeriado.includes(paradaCidade)) {
                  // +1 porque o waypoint de índice 0 é a origem
                  index = i + 1;
                  console.log(`Cidade do feriado encontrada na parada ${i}: ${paradaCidade}`);
                  break;
                }
              }
            }
          } else {  // Feriado nacional
            console.log("Processando feriado nacional para todas as cidades na rota");
            
            // Para feriados nacionais, marcar todas as cidades na rota
            const cidadesComFeriados = cidades.map((cidade, idx) => {
              if (idx === 0) return { cityName: cidade, position: waypoints[0], index: 0 };
              // Encontrar posição correta para cada cidade
              const wpIndex = idx; // waypoints tem origem + paradas
              return { 
                cityName: cidade, 
                position: waypoints[wpIndex < waypoints.length ? wpIndex : 0],
                index: wpIndex 
              };
            });
            
            // Adicionar apenas o primeiro e o último ponto da rota para feriados nacionais
            // para não sobrecarregar o mapa
            if (cidadesComFeriados.length > 0) {
              // Formatar data do feriado
              const dataFormatada = `${feriado.day.toString().padStart(2, '0')}/${feriado.month.toString().padStart(2, '0')}`;
              
              // Adicionar para a origem
              holidayMarkers.push({
                cityName: cidadesComFeriados[0].cityName,
                holidayInfo: `${feriado.name} (${dataFormatada})`,
                position: cidadesComFeriados[0].position
              });
              
              // Adicionar para o destino (se diferente da origem)
              if (cidadesComFeriados.length > 1) {
                const ultimo = cidadesComFeriados[cidadesComFeriados.length - 1];
                holidayMarkers.push({
                  cityName: ultimo.cityName,
                  holidayInfo: `${feriado.name} (${dataFormatada})`,
                  position: ultimo.position
                });
              }
            }
            
            // Pular o resto do processamento para feriados nacionais
            continue;
          }
          
          // Se encontrou a cidade do feriado na rota
          if (index !== -1 && index < waypoints.length) {
            // Formatar data do feriado
            const dataFormatada = `${feriado.day.toString().padStart(2, '0')}/${feriado.month.toString().padStart(2, '0')}`;
            console.log(`Adicionando marcador de feriado para ${cidadeFeriado} em ${dataFormatada}`);
            
            // Adicionar à lista de marcadores
            holidayMarkers.push({
              cityName: cidadeFeriado,
              holidayInfo: `${feriado.name} (${dataFormatada})`,
              position: waypoints[index]
            });
          } else {
            console.log(`Não foi possível encontrar as coordenadas para a cidade ${cidadeFeriado}`);
          }
        }
        
        console.log(`Total de marcadores de feriados criados: ${holidayMarkers.length}`);
        
        // Atualizar estado com os marcadores de feriados
        setHolidays(holidayMarkers);
      } else {
        // Limpar marcadores se não houver feriados
        console.log("Nenhum feriado encontrado no intervalo de datas ou não há pontos para exibir no mapa");
        setHolidays([]);
      }
    } else {
      // Limpar marcadores se não houver datas
      console.log("Sem datas de início/fim definidas, não verificando feriados");
      setHolidays([]);
    }
  }, [routeResult, waypoints]);
  
  // Extrair posições da rota quando houver resultados
  useEffect(() => {
    if (routeResult && routeResult.rota) {
      try {
        // Verificar se há rotas disponíveis
        if (routeResult.rota.routes && routeResult.rota.routes.length > 0) {
          // Log para depuração
          console.log('Dados da rota recebidos:', routeResult.rota);
          
          // Obter a geometria da rota (formato polyline)
          const polyline = routeResult.rota.routes[0].geometry;
          console.log('Geometria da rota (polyline):', polyline);
          
          // Decodificar as coordenadas da polyline
          const decodedPositions = decodePolyline(polyline);
          console.log('Posições decodificadas:', decodedPositions);
          console.log('Número de pontos na rota:', decodedPositions.length);
          
          // Verificar se temos pontos válidos
          if (decodedPositions.length > 0) {
            console.log('Primeiros 5 pontos da rota:', decodedPositions.slice(0, 5));
            console.log('Últimos 5 pontos da rota:', decodedPositions.slice(-5));
          }
          
          setPositions(decodedPositions);
          
          // TENTATIVA FINAL PARA CORRIGIR OS WAYPOINTS
          // O Leaflet espera pontos no formato [latitude, longitude]
          
          // Definir os waypoints (origem, paradas e destino)
          const wpRaw = routeResult.rota.waypoints.map((wp: any) => {
            console.log('Waypoint original:', wp);
            // Não inverter as coordenadas! 
            // Manter no formato em que vieram do servidor OSRM [longitude, latitude]
            return wp.location;
          });
          
          // Verificar formato dos pontos
          if (wpRaw.length > 0) {
            console.log('Formato original dos waypoints:', wpRaw);
            console.log('Primeiro waypoint original:', wpRaw[0]);
            
            // Vamos analisar o primeiro waypoint
            const lng = wpRaw[0][0];
            const lat = wpRaw[0][1];
            
            console.log(`Coordenadas do primeiro waypoint: lng=${lng}, lat=${lat}`);
            
            // No Brasil (São Paulo), a longitude deve ser aproximadamente -48 e latitude -22
            // Se a longitude está em torno de -22, está invertida
            if (lng > -30 && lng < -10) {
              console.log('CORREÇÃO FINAL: Os pontos parecem estar invertidos, corrigindo...');
              const correctWaypoints = wpRaw.map((wp: any) => [wp[1], wp[0]] as [number, number]);
              console.log('Pontos corrigidos:', correctWaypoints);
              setWaypoints(correctWaypoints);
            } else {
              // O OSRM envia no formato [longitude, latitude], mas o Leaflet espera [latitude, longitude]
              // Para coordenadas brasileiras, isso é [-48.xx, -22.xx] -> [-22.xx, -48.xx]
              console.log('CORREÇÃO FINAL: Os pontos precisam ser invertidos');
              const correctWaypoints = wpRaw.map((wp: any) => [wp[1], wp[0]] as [number, number]);
              console.log('Pontos formatados para Leaflet:', correctWaypoints);
              setWaypoints(correctWaypoints);
            }
          } else {
            setWaypoints([]);
          }
          
          // Centralizar o mapa automaticamente para mostrar toda a rota
          if (decodedPositions.length > 0) {
            // Centralizar mapa nas coordenadas de São Paulo capital no formato [lat, lng]
            const fixedCenter: [number, number] = [-23.5505, -46.6333]; // São Paulo capital
            setCenter(fixedCenter);
            
            // Ajustar o zoom com base na distância da rota
            const distancia = routeResult.rota.routes[0].distance;
            
            if (distancia < 500) { // menos de 500m - extremo detalhe
              setZoom(18);
            } else if (distancia < 2000) { // menos de 2km - muito detalhe
              setZoom(16);
            } else if (distancia < 10000) { // menos de 10km - detalhe urbano
              setZoom(15);
            } else if (distancia < 50000) { // menos de 50km - cidades próximas
              setZoom(13);
            } else if (distancia < 100000) { // menos de 100km
              setZoom(11);
            } else if (distancia < 300000) { // menos de 300km
              setZoom(9);
            } else if (distancia < 1000000) { // menos de 1000km
              setZoom(7);
            } else {
              setZoom(5);
            }
          }
          
          // Forçar atualização do mapa quando a rota muda
          setMapKey(prevKey => prevKey + 1);
        }
      } catch (error) {
        console.error('Erro ao processar a rota:', error);
      }
    }
  }, [routeResult]);

  if (!routeResult) {
    // Se não há rota, mostramos o mapa com a localização atual
    // Centralizar em São Paulo capital como padrão
    const defaultCenter: [number, number] = [-23.5505, -46.6333]; // São Paulo capital
    
    return (
      <div className="w-full h-full rounded-md overflow-hidden relative">
        <MapTypeSelector />
        <MapContainer 
          center={defaultCenter} 
          zoom={14} 
          style={{ height: '100%', width: '100%' }}
          scrollWheelZoom={true}
          maxZoom={19}
        >
          {/* Mapa base - varia conforme o tipo selecionado */}
          {mapType === 'standard' && (
            <TileLayer
              attribution={'&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'}
              url={"https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"}
            />
          )}
          

          
          {mapType === 'satellite' && (
            <>
              {/* Camada base de satélite com imagens de alta resolução da ESRI */}
              <TileLayer
                attribution={'&copy; <a href="https://www.esri.com/">Esri</a>, Maxar, Earthstar Geographics, USDA FSA'}
                url={"https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}"}
                maxZoom={23}
                tileSize={256}
              />
            </>
          )}
          
          {mapType === 'panorama' && (
            <TileLayer
              attribution={'&copy; <a href="https://www.cyclosm.org/">CyclOSM</a>'}
              url={"https://{s}.tile-cyclosm.openstreetmap.fr/cyclosm/{z}/{x}/{y}.png"}
              maxZoom={20}
            />
          )}

          {/* Camada com nomes de ruas e locais para mapa padrão */}
          {mapType === 'standard' && (
            <TileLayer
              attribution={'&copy; <a href="https://carto.com/">CartoDB</a> contributors'}
              url={"https://{s}.basemaps.cartocdn.com/rastertiles/voyager_only_labels/{z}/{x}/{y}{r}.png"}
              opacity={0.9}
              zIndex={1000}
            />
          )}
          
          {/* Camada de nomes de ruas estilo Google Maps para o modo satélite */}
          {mapType === 'satellite' && (
            <>
              {/* Usando CartoDB para labels no modo satélite - mais confiável */}
              <TileLayer
                attribution={'&copy; <a href="https://carto.com/">CartoDB</a> contributors'}
                url={"https://{s}.basemaps.cartocdn.com/rastertiles/voyager_only_labels/{z}/{x}/{y}{r}.png"}
                className="sattelite-labels"
                opacity={1}
                zIndex={1000}
              />
            </>
          )}
          
          {/* Controles de zoom e escala */}
          <ZoomControl position="bottomright" />
          <ScaleControl position="bottomleft" imperial={false} />
          
          {/* Controles de rotação apenas no modo panorama */}
          {mapType === 'panorama' && <MapRotationControls />}
          
          {/* Componente que localiza e mostra a posição atual */}
          <LocationMarker />
        </MapContainer>
      </div>
    );
  }

  return (
    <div className="w-full h-full rounded-md overflow-hidden relative">
      <MapTypeSelector />
      <MapContainer 
        key={mapKey}
        center={center} 
        zoom={zoom} 
        style={{ height: '100%', width: '100%', minHeight: '500px' }}
        scrollWheelZoom={true}
        maxZoom={23}
      >
        {/* Mapa base - varia conforme o tipo selecionado */}
        {mapType === 'standard' && (
          <TileLayer
            attribution={'&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'}
            url={"https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"}
          />
        )}
        

        
        {mapType === 'satellite' && (
          <>
            {/* Camada base de satélite com imagens de alta resolução da ESRI */}
            <TileLayer
              attribution={'&copy; <a href="https://www.esri.com/">Esri</a>, Maxar, Earthstar Geographics, USDA FSA'}
              url={"https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}"}
              maxZoom={23}
              tileSize={256}
            />
          </>
        )}
        
        {mapType === 'panorama' && (
          <TileLayer
            attribution={'&copy; <a href="https://www.cyclosm.org/">CyclOSM</a>'}
            url={"https://{s}.tile-cyclosm.openstreetmap.fr/cyclosm/{z}/{x}/{y}.png"}
            maxZoom={20}
          />
        )}

        {/* Camada com nomes de ruas e locais para mapa padrão */}
        {mapType === 'standard' && (
          <TileLayer
            attribution={'&copy; <a href="https://carto.com/">CartoDB</a> contributors'}
            url={"https://{s}.basemaps.cartocdn.com/rastertiles/voyager_only_labels/{z}/{x}/{y}{r}.png"}
            opacity={0.9}
            zIndex={1000}
          />
        )}
        
        {/* Camada de nomes de ruas estilo Google Maps para o modo satélite */}
        {mapType === 'satellite' && (
          <>
            {/* Usando CartoDB para labels no modo satélite - mais confiável */}
            <TileLayer
              attribution={'&copy; <a href="https://carto.com/">CartoDB</a> contributors'}
              url={"https://{s}.basemaps.cartocdn.com/rastertiles/voyager_only_labels/{z}/{x}/{y}{r}.png"}
              className="sattelite-labels"
              opacity={1}
              zIndex={1000}
            />
          </>
        )}
        
        {/* Adicionar controles de zoom e escala */}
        <ZoomControl position="bottomright" />
        <ScaleControl position="bottomleft" imperial={false} />
        
        {/* Controles de rotação apenas no modo panorama */}
        {mapType === 'panorama' && <MapRotationControls />}
        
        {/* Componente de debug para traçar a rota diretamente */}
        {positions && positions.length > 1 && <MapDebugger key={`debugger-${mapKey}`} positions={positions} />}
        
        {/* Linha da rota com efeito de camadas múltiplas igual ao Google Maps */}
        {positions && positions.length > 1 && (
          <>
            {/* Camada externa (sombra/contorno) - azul escuro */}
            <Polyline
              key={`outer-${mapKey}`}
              pathOptions={{ color: '#1967D2', weight: 10, opacity: 0.4 }}
              positions={positions}
            />
            {/* Camada de borda - azul médio com brilho */}
            <Polyline
              key={`middle-${mapKey}`}
              pathOptions={{ color: '#4285F4', weight: 8, opacity: 0.5 }}
              positions={positions}
            />
            {/* Camada de destaque - azul claro brilhante */}
            <Polyline
              key={`highlight-${mapKey}`}
              pathOptions={{ color: '#669DF6', weight: 6, opacity: 0.8 }}
              positions={positions}
            />
            {/* Linha central (principal) - azul Google Maps mais vibrante */}
            <Polyline
              key={`core-${mapKey}`}
              pathOptions={{ color: '#4285F4', weight: 4, opacity: 1.0 }}
              positions={positions}
            />
          </>
        )}
        
        {/* Marcadores para origem, paradas e destino */}
        {waypoints && waypoints.length > 0 && waypoints.map((position: [number, number], index: number) => {
          // Validar que as coordenadas são números válidos
          if (!position || position.length !== 2 || isNaN(position[0]) || isNaN(position[1])) {
            console.warn('Posição de waypoint inválida:', position);
            return null;
          }
          
          // Determinar qual ícone usar e conteúdo do popup
          let currentIcon: L.Icon | L.DivIcon;
          let popupContent = '';
          
          // Agora não temos mais um destino separado - só origem e paradas
          if (index === 0) {
            // Marcador de origem (numerado como 1)
            currentIcon = createNumberedIcon(1, '#22c55e'); // Verde
            popupContent = `Origem (1): ${routeResult?.origem || 'Não especificada'}`;
          } else {
            // Todas as outras posições são paradas
            currentIcon = createNumberedIcon(index + 1, '#f59e0b'); // Âmbar
            
            // Usar o índice da parada ajustado
            const paradaIndex = index - 1;
            let paradaNome = '';
            
            // A última parada é visualmente tratada como "destino" na interface
            const isLastStop = (index === waypoints.length - 1);
            
            if (routeResult?.optimized && routeResult.optimizedWaypointsOrder && routeResult.optimizedWaypointsOrder.length > 0) {
              // Se a rota foi otimizada, use a ordem otimizada para exibir as paradas
              paradaNome = routeResult.optimizedWaypointsOrder[paradaIndex] || '';
            } else if (routeResult?.paradas) {
              // Caso contrário, use a ordem original das paradas
              paradaNome = routeResult.paradas[paradaIndex] || '';
            }
            
            // Se for a última parada, mostramos como destino visualmente
            if (isLastStop) {
              currentIcon = createNumberedIcon(index + 1, '#ef4444'); // Vermelho para última parada
              popupContent = `Destino (${index + 1}): ${paradaNome}`;
            } else {
              popupContent = `Parada ${paradaIndex + 1} (${index + 1}): ${paradaNome}`;
            }
          }
          
          return (
            <Marker 
              key={`waypoint-${index}-${mapKey}`} 
              position={position} 
              icon={currentIcon}
              title={index === 0 ? `Origem (1)` : index === waypoints.length - 1 ? `Destino (${index + 1})` : `Parada ${index} (Sequência: ${index + 1})`}
            >
              <Popup>
                <strong>{popupContent}</strong>
              </Popup>
            </Marker>
          );
        }).filter(Boolean)}
        
        {/* Marcadores para feriados e datas comemorativas */}
        {holidays && holidays.length > 0 && holidays.map((holiday, index) => {
          // Validar posição antes de renderizar
          if (!holiday || !holiday.position || holiday.position.length !== 2 || 
              isNaN(holiday.position[0]) || isNaN(holiday.position[1])) {
            console.warn('Posição de feriado inválida:', holiday);
            return null;
          }
          
          return (
            <Marker
              key={`holiday-${index}-${mapKey}`}
              position={holiday.position}
              icon={createHolidayIcon()}
              zIndexOffset={1000} // Garante que os ícones de feriado apareçam acima dos marcadores de rota
              title={`Feriado: ${holiday.holidayInfo}`}
            >
              <Popup>
                <div className="space-y-1">
                  <div className="flex items-center gap-1 text-amber-600 font-medium">
                    <CalendarDays className="h-4 w-4" />
                    <span>Feriado em {holiday.cityName}</span>
                  </div>
                  <p className="text-sm">{holiday.holidayInfo}</p>
                  <p className="text-xs text-gray-500">
                    Lembre-se de planejar a entrega considerando este feriado.
                  </p>
                </div>
              </Popup>
            </Marker>
          );
        }).filter(Boolean)}
      </MapContainer>
    </div>
  );
}