import { useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import axios from 'axios';

export function PedagioDebugger() {
  // Posição exata do pedágio de Jaú segundo OpenStreetMap
  const pedagioJauCoords = [-22.3182768, -48.7255090];
  const otherCoords = [-22.2753, -48.5583]; // Coordenadas antigas

  useEffect(() => {
    console.log("Debugger de pedágio ativo");
    console.log("Pedágio de Jaú deve estar em:", pedagioJauCoords);
  }, []);

  const testPedagio = async () => {
    try {
      console.log("Testando pedágio...");
      
      // Fazer uma requisição para calcular a rota
      const resposta = await axios.post('/api/routes/calculate', {
        origem: "Dois Córregos-SP",
        paradas: ["Bauru-SP"],
        otimizar: true,
        tipoVeiculo: "caminhao_2_eixos",
        dataInicio: "05/05",
        dataFim: "09/05"
      });

      // Verificar os pontos de interesse na resposta
      if (resposta.data.pontosInteresse) {
        console.log("Pontos de interesse retornados pelo servidor:", resposta.data.pontosInteresse);
        
        // Verificar se existe o pedágio de Jaú
        const pedagioJau = resposta.data.pontosInteresse.find(
          (poi: any) => poi.nome && poi.nome.includes('Jaú') && poi.tipo === 'tollbooth'
        );
        
        if (pedagioJau) {
          console.log("Pedágio de Jaú encontrado:", pedagioJau);
          console.log("Coordenadas:", pedagioJau.posicao);
          console.log("naRota definido como:", pedagioJau.naRota);
        } else {
          console.log("Pedágio de Jaú NÃO encontrado na resposta!");
        }
      } else {
        console.log("Nenhum ponto de interesse retornado pelo servidor!");
      }
    } catch (error) {
      console.error("Erro ao testar pedágio:", error);
    }
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Debugger de Pedágio</CardTitle>
      </CardHeader>
      <CardContent>
        <p className="mb-2">Coordenadas do pedágio de Jaú: {pedagioJauCoords[0]}, {pedagioJauCoords[1]}</p>
        <p className="mb-4">Coordenadas antigas: {otherCoords[0]}, {otherCoords[1]}</p>
        <Button onClick={testPedagio}>Testar Pedágio</Button>
      </CardContent>
    </Card>
  );
}