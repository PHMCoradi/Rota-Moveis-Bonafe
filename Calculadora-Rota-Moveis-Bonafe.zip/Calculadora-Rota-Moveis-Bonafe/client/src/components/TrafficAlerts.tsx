import { useEffect, useState } from "react";
import { Marker, Popup, useMap } from "react-leaflet";
import L from "leaflet";

// Interface para alertas de trânsito
interface TrafficAlert {
  id: string;
  type: string;
  description: string;
  location: {
    lat: number;
    lng: number;
  };
  street?: string;
  city?: string;
  confidence: number;
  creationTime: string;
  thumbsUp: number;
}

// Interface para congestionamentos
interface TrafficJam {
  id: string;
  street: string;
  city: string;
  level: number;
  length: number;
  speedKMH: number;
  delay: number;
  line: [number, number][];
  description: string;
}

interface TrafficResponse {
  success: boolean;
  timestamp: string;
  location: {
    lat: number;
    lng: number;
    radius: number;
  };
  alerts: TrafficAlert[];
  jams: TrafficJam[];
}

interface TrafficAlertsProps {
  center: [number, number];
  radius?: number;
  enabled?: boolean;
}

/**
 * Componente para exibir alertas de trânsito do Waze no mapa
 */
export function TrafficAlerts({ center, radius = 10000, enabled = true }: TrafficAlertsProps) {
  const [trafficData, setTrafficData] = useState<TrafficResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const map = useMap();
  
  // Ícones personalizados para diferentes tipos de alertas
  const alertIcons = {
    ACCIDENT: createAlertIcon("#FF0000", "🚧"), // Vermelho - acidente
    JAM: createAlertIcon("#FFA500", "🚗"),      // Laranja - congestionamento
    ROAD_CLOSED: createAlertIcon("#800000", "🚫"), // Vermelho escuro - via fechada
    HAZARD: createAlertIcon("#FF00FF", "⚠️"),   // Roxo - perigo
    WEATHERHAZARD: createAlertIcon("#0000FF", "☔"), // Azul - clima
    CONSTRUCTION: createAlertIcon("#FFFF00", "🔨"), // Amarelo - obras 
    POLICE: createAlertIcon("#000080", "👮"),   // Azul escuro - polícia
    DEFAULT: createAlertIcon("#808080", "ℹ️")   // Cinza - default
  };
  
  // Carregar dados de trânsito
  const fetchTrafficData = async () => {
    if (!enabled || !center || center.some(isNaN)) return;
    
    setLoading(true);
    setError(null);
    
    try {
      // Extrair lat e lng do centro
      const [lat, lng] = center;
      
      // Chamada à API
      const response = await fetch(`/api/traffic?lat=${lat}&lng=${lng}&radius=${radius}`);
      
      if (!response.ok) {
        throw new Error(`Erro ${response.status}: ${response.statusText}`);
      }
      
      const data: TrafficResponse = await response.json();
      
      console.log(`Recebidos ${data.alerts.length} alertas e ${data.jams.length} congestionamentos`);
      setTrafficData(data);
    } catch (err) {
      console.error("Erro ao buscar dados de trânsito:", err);
      setError("Não foi possível carregar os alertas de trânsito. Tente novamente mais tarde.");
    } finally {
      setLoading(false);
    }
  };
  
  // Atualizar dados quando o centro mudar
  useEffect(() => {
    if (!enabled) return;
    
    // Esperar um momento antes de buscar (evita muitas requisições durante navegação no mapa)
    const timeoutId = setTimeout(() => {
      fetchTrafficData();
    }, 1000);
    
    return () => clearTimeout(timeoutId);
  }, [center, radius, enabled]);
  
  // Criar polylines para congestionamentos
  const renderJamPolylines = () => {
    if (!trafficData || !trafficData.jams || !map) return null;
    
    try {
      // Verificar se o mapa está inicializado
      try {
        // Usando tipagem any para evitar erros de TypeScript com propriedades internas do Leaflet
        const mapInstance = map as any;
        // Tentar acessar funções para verificar se o mapa está inicializado
        if (!mapInstance || typeof mapInstance.getContainer !== 'function') {
          console.log('Mapa ainda não está totalmente inicializado');
          return;
        }
      } catch (e) {
        console.log('Erro ao verificar estado do mapa:', e);
        return;
      }
      
      // Remover polylines existentes
      map.eachLayer(layer => {
        if ((layer as any)._jamId) {
          map.removeLayer(layer);
        }
      });
      
      // Renderizar novos polylines
      trafficData.jams.forEach(jam => {
        try {
          // Verificar se todas as coordenadas da linha são válidas
          const validLine = jam.line.filter(point => 
            point && point.length === 2 && 
            !isNaN(point[0]) && !isNaN(point[1])
          );
          
          if (validLine.length < 2) {
            console.log(`Congestionamento ${jam.id} com coordenadas insuficientes`);
            return;
          }
          
          // Criar polyline com cor baseada no nível de congestionamento
          const color = getJamColor(jam.level);
          const polyline = L.polyline(validLine, {
            color,
            weight: 5,
            opacity: 0.7
          }).addTo(map);
          
          // Adicionar ID para identificação
          (polyline as any)._jamId = jam.id;
          
          // Adicionar popup com informações
          polyline.bindPopup(`
            <div>
              <strong>${jam.street || 'Via sem nome'}</strong><br/>
              <span>${jam.description}</span><br/>
              <span>Comprimento: ${(jam.length / 1000).toFixed(1)} km</span>
            </div>
          `);
        } catch (err) {
          console.error(`Erro ao renderizar congestionamento ${jam.id}:`, err);
        }
      });
    } catch (error) {
      console.error('Erro ao renderizar congestionamentos:', error);
    }
  };
  
  // Renderizar polylines com tratamento de erros
  useEffect(() => {
    try {
      // Usar timeout para garantir que o mapa está pronto
      const timer = setTimeout(() => {
        renderJamPolylines();
      }, 500);
      
      return () => clearTimeout(timer);
    } catch (error) {
      console.error('Erro no useEffect de renderização de congestionamentos:', error);
    }
  }, [trafficData, map]);
  
  // Criar ícone personalizado para alertas
  function createAlertIcon(color: string, symbol: string) {
    return L.divIcon({
      className: 'waze-alert-icon',
      html: `<div style="background-color: ${color}; color: white; border-radius: 50%; width: 24px; height: 24px; display: flex; align-items: center; justify-content: center; border: 2px solid white; box-shadow: 0 0 5px rgba(0,0,0,0.5);">${symbol}</div>`,
      iconSize: [28, 28],
      iconAnchor: [14, 14]
    });
  }
  
  // Obter cor baseada no nível de congestionamento
  function getJamColor(level: number): string {
    const colors = {
      1: '#FFC107', // Amarelo - leve
      2: '#FF9800', // Laranja - moderado
      3: '#FF5722', // Laranja escuro - intenso
      4: '#E53935', // Vermelho - severo
      5: '#B71C1C'  // Vermelho escuro - parado
    };
    
    return colors[level as keyof typeof colors] || '#FF9800';
  }
  
  // Obter ícone baseado no tipo de alerta
  function getAlertIcon(type: string) {
    return alertIcons[type as keyof typeof alertIcons] || alertIcons.DEFAULT;
  }
  
  // Se não estiver habilitado, não renderizar nada
  if (!enabled) return null;
  
  // Mostrar loader para dados carregando
  if (loading && !trafficData) {
    return (
      <div style={{ position: 'absolute', bottom: 10, left: '50%', transform: 'translateX(-50%)', zIndex: 1000, background: 'white', padding: '5px 10px', borderRadius: 5, boxShadow: '0 0 5px rgba(0,0,0,0.2)' }}>
        Carregando informações de trânsito...
      </div>
    );
  }
  
  // Mostrar erro se houver
  if (error) {
    return (
      <div style={{ position: 'absolute', bottom: 10, left: '50%', transform: 'translateX(-50%)', zIndex: 1000, background: 'white', padding: '5px 10px', borderRadius: 5, boxShadow: '0 0 5px rgba(0,0,0,0.2)', color: 'red' }}>
        {error}
      </div>
    );
  }
  
  return (
    <>
      {/* Renderizar marcadores para alertas com tratamento de erros */}
      {trafficData?.alerts.map(alert => {
        // Verificar se as coordenadas são válidas
        if (!alert.location || isNaN(alert.location.lat) || isNaN(alert.location.lng)) {
          console.warn(`Alerta ${alert.id} com coordenadas inválidas:`, alert.location);
          return null;
        }
        
        try {
          return (
            <Marker
              key={alert.id}
              position={[alert.location.lat, alert.location.lng]}
              icon={getAlertIcon(alert.type)}
            >
              <Popup>
                <div style={{ minWidth: '200px' }}>
                  <h3 style={{ fontSize: '16px', margin: '0 0 5px 0' }}>{alert.description}</h3>
                  {alert.street && <p style={{ margin: '5px 0' }}><strong>Local:</strong> {alert.street}</p>}
                  {alert.city && <p style={{ margin: '5px 0' }}><strong>Cidade:</strong> {alert.city}</p>}
                  <p style={{ margin: '5px 0' }}><strong>Confirmações:</strong> {alert.thumbsUp}</p>
                  <p style={{ margin: '5px 0', fontSize: '12px', color: '#666' }}>
                    <strong>Reportado:</strong> {new Date(alert.creationTime).toLocaleString('pt-BR')}
                  </p>
                </div>
              </Popup>
            </Marker>
          );
        } catch (error) {
          console.error(`Erro ao renderizar alerta ${alert.id}:`, error);
          return null;
        }
      })}
      
      {/* Indicador do número de alertas - movido para o centro inferior */}
      {trafficData && (
        <div style={{ 
          position: 'absolute', 
          bottom: 10, 
          left: '50%', 
          transform: 'translateX(-50%)',
          zIndex: 1000, 
          background: 'white', 
          padding: '5px 10px', 
          borderRadius: 5,
          boxShadow: '0 0 5px rgba(0,0,0,0.2)',
          display: 'flex',
          alignItems: 'center',
          gap: '5px',
          fontSize: '14px'
        }}>
          <span title="Alertas">🚨 {trafficData.alerts.length}</span>
          <span title="Congestionamentos">🚗 {trafficData.jams.length}</span>
          <button 
            onClick={fetchTrafficData}
            style={{
              background: 'transparent',
              border: 'none',
              cursor: 'pointer',
              padding: '0 5px',
              fontSize: '16px'
            }}
            title="Atualizar dados"
          >
            🔄
          </button>
        </div>
      )}
    </>
  );
}