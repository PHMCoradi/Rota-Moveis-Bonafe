import { useState } from 'react';
import { Check, Copy, Share2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { RouteResponse } from '@shared/schema';

interface ShareRouteButtonProps {
  routeResult: RouteResponse;
}

export function ShareRouteButton({ routeResult }: ShareRouteButtonProps) {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [copied, setCopied] = useState(false);

  // Função para gerar um link compartilhável
  const generateShareableLink = () => {
    // Vamos codificar apenas os dados essenciais da rota para manter a URL curta
    const essentialData = {
      o: routeResult.origem, // origem
      p: routeResult.paradas || [], // paradas (array vazio se não existir)
      v: routeResult.tipoVeiculo || "caminhao_2_eixos", // tipo de veículo (default se não existir)
      di: routeResult.dataInicio || "", // data de início (opcional)
      df: routeResult.dataFim || "", // data de fim (opcional)
      opt: routeResult.optimized ? 1 : 0 // otimização ativada ou não
    };
    
    // Remover campos vazios para reduzir tamanho da URL
    const cleanData: Record<string, any> = {};
    Object.entries(essentialData).forEach(([key, value]) => {
      // Não incluir arrays vazios ou strings vazias
      if (
        (Array.isArray(value) && value.length > 0) || 
        (typeof value === 'string' && value.trim() !== '') ||
        typeof value === 'number'
      ) {
        cleanData[key] = value;
      }
    });
    
    try {
      // Converter para JSON e codificar em base64
      const encodedData = btoa(JSON.stringify(cleanData));
      
      // Criar a URL com o parâmetro de rota
      const baseUrl = window.location.origin;
      return `${baseUrl}/?route=${encodedData}`;
    } catch (error) {
      console.error("Erro ao gerar link compartilhável:", error);
      return window.location.origin; // URL base em caso de erro
    }
  };

  // Gerar o link apenas quando o dialog for aberto
  const shareableLink = isDialogOpen ? generateShareableLink() : '';

  // Função para copiar o link para a área de transferência
  const copyToClipboard = () => {
    navigator.clipboard.writeText(shareableLink)
      .then(() => {
        setCopied(true);
        setTimeout(() => setCopied(false), 2000); // Reset após 2 segundos
      })
      .catch(err => {
        console.error('Erro ao copiar o link: ', err);
      });
  };

  return (
    <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
      <DialogTrigger asChild>
        <Button 
          variant="outline" 
          size="sm" 
          className="flex items-center gap-1 bg-white text-blue-600 border-blue-200 hover:bg-blue-50"
        >
          <Share2 className="h-4 w-4" />
          Compartilhar
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Compartilhar Rota</DialogTitle>
          <DialogDescription>
            Copie o link abaixo e compartilhe esta rota com outras pessoas.
          </DialogDescription>
        </DialogHeader>
        <div className="flex items-center space-x-2 mt-4">
          <div className="grid flex-1 gap-2">
            <Input
              value={shareableLink}
              readOnly
              className="text-xs md:text-sm"
            />
          </div>
          <Button 
            type="button" 
            size="sm" 
            className="px-3" 
            onClick={copyToClipboard}
          >
            {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
            <span className="sr-only">Copiar</span>
          </Button>
        </div>
        <div className="mt-2 text-sm text-gray-500">
          <p>Este link contém todos os detalhes da rota atual, incluindo a origem, paradas e configurações definidas.</p>
          <p className="mt-1">Qualquer pessoa com o link poderá visualizar e carregar esta rota exatamente como você a configurou.</p>
        </div>
      </DialogContent>
    </Dialog>
  );
}