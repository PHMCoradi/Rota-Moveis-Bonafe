import { useEffect, useState } from "react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Truck, Clock, Calendar, MapPin, Info, AlertCircle } from "lucide-react";
import { Separator } from "@/components/ui/separator";
import { TruckRestriction, verificarRestricoesCidades, extrairCidadeDeEndereco } from "@/lib/truckRestrictions";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

interface TruckRestrictionsProps {
  origem: string;
  paradas: string[];
  destino?: string;
}

export function TruckRestrictions({ origem, paradas, destino }: TruckRestrictionsProps) {
  const [restricoes, setRestricoes] = useState<TruckRestriction[]>([]);
  const [cidadesNaRota, setCidadesNaRota] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    // Função para extrair cidades da rota
    const extrairCidades = () => {
      setLoading(true);
      const todasParadas = [origem, ...paradas];
      if (destino && !paradas.includes(destino)) {
        todasParadas.push(destino);
      }

      // Extrair nomes de cidades de cada parada
      const cidades = todasParadas
        .map(endereco => extrairCidadeDeEndereco(endereco))
        .filter((cidade, index, self) => 
          // Remover duplicatas
          index === self.findIndex(c => c.cidade === cidade.cidade && c.uf === cidade.uf)
        );

      // Mantém lista de cidades para exibição
      setCidadesNaRota(cidades.map(c => c.uf ? `${c.cidade}-${c.uf}` : c.cidade));
      
      // Verificar restrições para estas cidades
      const restricoesEncontradas = verificarRestricoesCidades(cidades);
      setRestricoes(restricoesEncontradas);
      setLoading(false);
    };

    extrairCidades();
  }, [origem, paradas, destino]);

  // Se não tiver paradas ou origem, não mostra nada
  if (!origem && paradas.length === 0) {
    return null;
  }

  return (
    <Card className="mt-4 border border-amber-200 bg-amber-50">
      <CardHeader className="pb-2">
        <CardTitle className="text-lg flex items-center gap-2">
          <Truck className="h-5 w-5 text-amber-600" /> Restrições para Caminhões
        </CardTitle>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="py-2 text-center text-sm text-gray-500">
            Verificando restrições...
          </div>
        ) : restricoes.length > 0 ? (
          <div className="space-y-2">
            <Alert className="bg-amber-100 border-amber-300">
              <AlertCircle className="h-4 w-4 text-amber-600" />
              <AlertTitle>Atenção - Restrições de Tráfego!</AlertTitle>
              <AlertDescription>
                Existem {restricoes.length} cidades na sua rota com restrições para circulação de caminhões.
              </AlertDescription>
            </Alert>
            
            <ScrollArea className="h-[300px]">
              <Accordion type="single" collapsible className="w-full">
                {restricoes.map((restricao, index) => (
                  <AccordionItem key={index} value={`restricao-${index}`}>
                    <AccordionTrigger className="py-2 px-3 hover:bg-amber-100 text-amber-800 font-medium">
                      {restricao.cidade}-{restricao.uf}
                    </AccordionTrigger>
                    <AccordionContent className="px-3 pb-3 bg-white rounded-md">
                      <div className="space-y-2 text-sm text-gray-700">
                        <p className="font-medium">{restricao.descricao}</p>
                        
                        <div className="grid grid-cols-[20px_1fr] gap-x-2 gap-y-2 items-start">
                          <Clock className="h-4 w-4 text-amber-600 mt-0.5" />
                          <div>
                            <span className="font-medium">Horários de Restrição:</span>
                            <ul className="list-disc list-inside ml-2">
                              {restricao.horarios.map((horario, i) => (
                                <li key={i}>{horario}</li>
                              ))}
                            </ul>
                          </div>
                          
                          <Calendar className="h-4 w-4 text-amber-600 mt-0.5" />
                          <div>
                            <span className="font-medium">Dias:</span>
                            <ul className="list-disc list-inside ml-2">
                              {restricao.diasSemana.map((dia, i) => (
                                <li key={i}>{dia}</li>
                              ))}
                            </ul>
                          </div>
                          
                          <Truck className="h-4 w-4 text-amber-600 mt-0.5" />
                          <div>
                            <span className="font-medium">Veículos afetados:</span>
                            <ul className="list-disc list-inside ml-2">
                              {restricao.tiposVeiculo.map((tipo, i) => (
                                <li key={i}>{tipo}</li>
                              ))}
                            </ul>
                          </div>
                          
                          <MapPin className="h-4 w-4 text-amber-600 mt-0.5" />
                          <div>
                            <span className="font-medium">Áreas restritas:</span>
                            <p className="ml-2">{restricao.areas}</p>
                          </div>
                          
                          <Info className="h-4 w-4 text-green-600 mt-0.5" />
                          <div>
                            <span className="font-medium text-green-700">Exceções:</span>
                            <p className="ml-2">{restricao.excecoes}</p>
                          </div>
                          
                          {restricao.observacoes && (
                            <>
                              <AlertCircle className="h-4 w-4 text-blue-600 mt-0.5" />
                              <div>
                                <span className="font-medium text-blue-700">Observações:</span>
                                <p className="ml-2">{restricao.observacoes}</p>
                              </div>
                            </>
                          )}
                        </div>
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>
            </ScrollArea>
          </div>
        ) : (
          <div className="py-2 text-gray-700">
            <Alert className="bg-green-50 border-green-200">
              <Info className="h-4 w-4 text-green-600" />
              <AlertTitle>Rota sem restrições conhecidas</AlertTitle>
              <AlertDescription>
                Não foram encontradas restrições para caminhões nas cidades da sua rota.
                <div className="mt-2">
                  <span className="text-xs text-gray-600">Cidades verificadas:</span>
                  <div className="flex flex-wrap gap-1 mt-1">
                    {cidadesNaRota.map((cidade, i) => (
                      <Badge key={i} variant="outline" className="bg-white">{cidade}</Badge>
                    ))}
                  </div>
                </div>
              </AlertDescription>
            </Alert>
            <p className="text-xs mt-3 text-gray-500">
              Nota: Algumas restrições podem não estar listadas. Sempre verifique junto às autoridades locais.
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}