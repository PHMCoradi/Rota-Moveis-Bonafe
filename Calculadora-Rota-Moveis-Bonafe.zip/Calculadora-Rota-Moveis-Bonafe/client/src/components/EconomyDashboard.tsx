import { useState, useEffect } from 'react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, 
  ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line,
  Area, AreaChart
} from 'recharts';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  TrendingDown, TrendingUp, Fuel, DollarSign, 
  Calendar, Timer, BarChart2, PieChart as PieChartIcon
} from 'lucide-react';
// Definição da interface RouteResponse para o componente
interface RouteResponse {
  distanciaTotal: string;
  tempoTotal: string;
  origem: string;
  destino?: string;
  paradas?: string[];
  valorPedagios?: string;
  tipoVeiculo?: string;
  rotasAlternativas?: Array<{
    destaque?: boolean;
    distanciaNumerica: number;
    tempoNumerico: number;
  }>;
}

interface EconomyDashboardProps {
  routeResult: RouteResponse;
}

interface EconomyData {
  combustivel: number;
  pedagios: number;
  manutencao: number;
  total: number;
  economia: number;
  economiaPercentual: number;
}

export function EconomyDashboard({ routeResult }: EconomyDashboardProps) {
  const [activeTab, setActiveTab] = useState('geral');
  const [economyData, setEconomyData] = useState<EconomyData | null>(null);
  const [compareData, setCompareData] = useState<any[]>([]);
  const [historicalData, setHistoricalData] = useState<any[]>([]);
  const [breakdownData, setBreakdownData] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!routeResult) return;
    
    // Simulação de carregamento para efeito de animação
    setLoading(true);
    
    const calcularCustos = () => {
      // Extrai a distância numérica
      const distanciaKm = parseFloat(routeResult.distanciaTotal.replace(/[^0-9,]/g, '').replace(',', '.')) || 0;
      
      // Extrai o valor do pedágio (se disponível)
      let valorPedagio = 0;
      if (routeResult.valorPedagios) {
        valorPedagio = parseFloat(routeResult.valorPedagios.replace(/[^0-9,]/g, '').replace(',', '.')) || 0;
      }
      
      // Calcular custos baseados na distância
      const consumoCombustivel = routeResult.tipoVeiculo === 'caminhao' || routeResult.tipoVeiculo === 'caminhao_2_eixos' 
        ? 4 // km/l para caminhões
        : routeResult.tipoVeiculo === 'moto' 
          ? 35 // km/l para motos
          : 12; // km/l para carros
          
      const precoCombustivel = 5.80; // R$ por litro
      
      // Custo de combustível
      const litrosNecessarios = distanciaKm / consumoCombustivel;
      const custoCombustivel = litrosNecessarios * precoCombustivel;
      
      // Custo de manutenção (aproximado por km)
      const custoManutencao = distanciaKm * (
        routeResult.tipoVeiculo === 'caminhao' || routeResult.tipoVeiculo === 'caminhao_2_eixos' 
          ? 0.95 // R$/km para caminhões
          : routeResult.tipoVeiculo === 'moto' 
            ? 0.15 // R$/km para motos
            : 0.35 // R$/km para carros
      );
      
      // Custo total
      const custoTotal = custoCombustivel + valorPedagio + custoManutencao;
      
      // Economia (em comparação com a rota não otimizada)
      let economia = 0;
      let economiaPercentual = 0;
      
      if (routeResult.rotasAlternativas && routeResult.rotasAlternativas.length > 1) {
        // Encontrar a rota mais longa para comparação
        const rotaLonga = [...routeResult.rotasAlternativas].sort((a, b) => 
          b.distanciaNumerica - a.distanciaNumerica
        )[0];
        
        const distanciaLonga = rotaLonga.distanciaNumerica / 1000; // Converter para km
        const litrosLonga = distanciaLonga / consumoCombustivel;
        const combustivelLonga = litrosLonga * precoCombustivel;
        const manutencaoLonga = distanciaLonga * (
          routeResult.tipoVeiculo === 'caminhao' || routeResult.tipoVeiculo === 'caminhao_2_eixos' 
            ? 0.95 
            : routeResult.tipoVeiculo === 'moto' 
              ? 0.15 
              : 0.35
        );
        
        const custoLonga = combustivelLonga + valorPedagio + manutencaoLonga;
        economia = custoLonga - custoTotal;
        economiaPercentual = (economia / custoLonga) * 100;
      }
      
      return {
        combustivel: parseFloat(custoCombustivel.toFixed(2)),
        pedagios: parseFloat(valorPedagio.toFixed(2)),
        manutencao: parseFloat(custoManutencao.toFixed(2)),
        total: parseFloat(custoTotal.toFixed(2)),
        economia: parseFloat(economia.toFixed(2)),
        economiaPercentual: parseFloat(economiaPercentual.toFixed(1))
      };
    };
    
    const generateCompareData = (economia: EconomyData) => {
      // Dados comparativos para gráfico de barras
      return [
        { name: 'Rota Atual', value: economia.total, fill: '#3b82f6' },
        { 
          name: 'Sem Otimização', 
          value: economia.economia > 0 ? economia.total + economia.economia : economia.total * 1.15, 
          fill: '#ef4444' 
        }
      ];
    };
    
    const generateBreakdownData = (economia: EconomyData) => {
      // Dados para o gráfico de pizza
      return [
        { name: 'Combustível', value: economia.combustivel, color: '#3b82f6' },
        { name: 'Pedágios', value: economia.pedagios, color: '#f97316' },
        { name: 'Manutenção', value: economia.manutencao, color: '#84cc16' }
      ];
    };
    
    const generateHistoricalData = () => {
      // Dados históricos de economia (simulados)
      const baseValue = Math.round(Math.random() * 50) + 50;
      return [
        { name: 'Jan', economia: baseValue },
        { name: 'Fev', economia: baseValue + Math.round(Math.random() * 20) - 10 },
        { name: 'Mar', economia: baseValue + Math.round(Math.random() * 30) - 15 },
        { name: 'Abr', economia: baseValue + Math.round(Math.random() * 20) },
        { name: 'Mai', economia: baseValue + Math.round(Math.random() * 40) - 5 },
        { name: 'Jun', economia: baseValue + Math.round(Math.random() * 25) + 15 }
      ];
    };
    
    // Calculando todos os dados de uma vez
    const economiaDados = calcularCustos();
    
    // Configurando os dados para os gráficos
    setEconomyData(economiaDados);
    setCompareData(generateCompareData(economiaDados));
    setBreakdownData(generateBreakdownData(economiaDados));
    setHistoricalData(generateHistoricalData());
    
    // Finalizando o carregamento após um pequeno delay para efeito visual
    setTimeout(() => {
      setLoading(false);
    }, 600);
  }, [routeResult]);
  
  if (!routeResult || !economyData) {
    return (
      <Card className="w-full">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <DollarSign className="h-5 w-5 text-primary" />
            <span>Dashboard de Economia</span>
          </CardTitle>
          <CardDescription>
            Calcule uma rota para ver a análise econômica
          </CardDescription>
        </CardHeader>
        <CardContent className="min-h-[240px] flex items-center justify-center">
          <p className="text-muted-foreground">Aguardando cálculo de rota...</p>
        </CardContent>
      </Card>
    );
  }
  
  // Cores para os gráficos
  const COLORS = ['#3b82f6', '#f97316', '#84cc16', '#8b5cf6'];
  
  return (
    <Card className="w-full overflow-hidden">
      <CardHeader className="pb-3">
        <div className="flex justify-between items-center">
          <CardTitle className="flex items-center gap-2">
            <DollarSign className="h-5 w-5 text-primary" />
            <span>Dashboard de Economia</span>
          </CardTitle>
          {economyData.economia > 0 && (
            <Badge className="bg-green-100 text-green-800 hover:bg-green-200">
              <TrendingDown className="h-3 w-3 mr-1" />
              Economia de R$ {economyData.economia.toFixed(2)}
            </Badge>
          )}
        </div>
        <CardDescription>
          Análise de custos e economia da rota {routeResult.origem} {routeResult.paradas?.length ? `→ ${routeResult.paradas[routeResult.paradas.length - 1]}` : ''}
        </CardDescription>
      </CardHeader>
      
      <CardContent className="p-0">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <div className="px-6">
            <TabsList className="grid grid-cols-3 mb-4">
              <TabsTrigger value="geral" className="text-xs sm:text-sm">
                <BarChart2 className="h-3 w-3 mr-1 sm:h-4 sm:w-4" />
                <span className="hidden sm:inline">Custos</span>
                <span className="sm:hidden">Custos</span>
              </TabsTrigger>
              <TabsTrigger value="detalhes" className="text-xs sm:text-sm">
                <PieChartIcon className="h-3 w-3 mr-1 sm:h-4 sm:w-4" />
                <span className="hidden sm:inline">Detalhes</span>
                <span className="sm:hidden">Detalhes</span>
              </TabsTrigger>
              <TabsTrigger value="historico" className="text-xs sm:text-sm">
                <TrendingUp className="h-3 w-3 mr-1 sm:h-4 sm:w-4" />
                <span className="hidden sm:inline">Histórico</span>
                <span className="sm:hidden">Histórico</span>
              </TabsTrigger>
            </TabsList>
          </div>
          
          <TabsContent value="geral" className="m-0">
            <div className="p-4 border-t pt-6">
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-6">
                <div className="flex flex-col justify-center items-center">
                  <Fuel className="h-5 w-5 text-blue-500 mb-1" />
                  <span className="text-xs text-muted-foreground">Combustível</span>
                  <span className="font-semibold">R$ {economyData.combustivel.toFixed(2)}</span>
                </div>
                <div className="flex flex-col justify-center items-center">
                  <DollarSign className="h-5 w-5 text-orange-500 mb-1" />
                  <span className="text-xs text-muted-foreground">Pedágios</span>
                  <span className="font-semibold">R$ {economyData.pedagios.toFixed(2)}</span>
                </div>
                <div className="flex flex-col justify-center items-center">
                  <Timer className="h-5 w-5 text-green-500 mb-1" />
                  <span className="text-xs text-muted-foreground">Manutenção</span>
                  <span className="font-semibold">R$ {economyData.manutencao.toFixed(2)}</span>
                </div>
                <div className="flex flex-col justify-center items-center">
                  <TrendingDown className="h-5 w-5 text-purple-500 mb-1" />
                  <span className="text-xs text-muted-foreground">Economia</span>
                  <span className="font-semibold">
                    {economyData.economiaPercentual > 0 
                      ? `${economyData.economiaPercentual}%` 
                      : 'N/A'}
                  </span>
                </div>
              </div>
              
              <div className="w-full h-[240px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={compareData}
                    margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                    barSize={40}
                    className={loading ? 'opacity-0' : 'opacity-100 transition-opacity duration-1000'}
                  >
                    <CartesianGrid strokeDasharray="3 3" vertical={false} />
                    <XAxis dataKey="name" />
                    <YAxis 
                      tickFormatter={(value) => `R$ ${value}`} 
                      domain={[0, 'dataMax * 1.1']}
                    />
                    <Tooltip 
                      formatter={(value: number) => [`R$ ${value.toFixed(2)}`, 'Custo']}
                      contentStyle={{ borderRadius: '8px' }}
                    />
                    <Bar 
                      dataKey="value" 
                      fill="#3b82f6" 
                      radius={[4, 4, 0, 0]}
                      animationDuration={1200}
                    >
                      {compareData?.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.fill} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="detalhes" className="m-0">
            <div className="p-4 border-t pt-6">
              <div className="flex flex-col space-y-2 mb-4">
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">Custo Total da Viagem:</span>
                  <span className="font-semibold">R$ {economyData.total.toFixed(2)}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm">Distância:</span>
                  <span>{routeResult.distanciaTotal}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm">Tempo Estimado:</span>
                  <span>{routeResult.tempoTotal}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm">Veículo:</span>
                  <span className="capitalize">
                    {routeResult.tipoVeiculo === 'caminhao_2_eixos' 
                      ? 'Caminhão 2 Eixos' 
                      : routeResult.tipoVeiculo}
                  </span>
                </div>
              </div>
              
              <div className="w-full h-[240px]">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart
                    className={loading ? 'opacity-0' : 'opacity-100 transition-opacity duration-1000'}
                  >
                    <Pie
                      data={breakdownData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                      nameKey="name"
                      label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                      animationDuration={1200}
                      animationBegin={300}
                    >
                      {breakdownData?.map((entry, index) => (
                        <Cell 
                          key={`cell-${index}`} 
                          fill={entry.color || COLORS[index % COLORS.length]} 
                        />
                      ))}
                    </Pie>
                    <Tooltip 
                      formatter={(value: number) => [`R$ ${value.toFixed(2)}`, 'Custo']} 
                      contentStyle={{ borderRadius: '8px' }}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="historico" className="m-0">
            <div className="p-4 border-t pt-6">
              <div className="flex justify-between items-center mb-4">
                <h4 className="text-sm font-medium">Economia histórica (últimos 6 meses)</h4>
                <Badge variant="outline" className="text-xs">
                  <Calendar className="h-3 w-3 mr-1" />
                  2023-2024
                </Badge>
              </div>
              
              <div className="w-full h-[240px]">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart
                    data={historicalData}
                    margin={{ top: 10, right: 30, left: 0, bottom: 0 }}
                    className={loading ? 'opacity-0' : 'opacity-100 transition-opacity duration-1000'}
                  >
                    <defs>
                      <linearGradient id="colorEconomia" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.8}/>
                        <stop offset="95%" stopColor="#3b82f6" stopOpacity={0.1}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} />
                    <XAxis dataKey="name" />
                    <YAxis tickFormatter={(value) => `${value}%`} />
                    <Tooltip 
                      formatter={(value: number) => [`${value}%`, 'Economia']} 
                      contentStyle={{ borderRadius: '8px' }}
                    />
                    <Area 
                      type="monotone" 
                      dataKey="economia" 
                      stroke="#3b82f6" 
                      fillOpacity={1} 
                      fill="url(#colorEconomia)"
                      animationDuration={1200}
                      animationBegin={300}
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
              
              <div className="mt-4 text-center">
                <p className="text-xs text-muted-foreground italic">
                  Baseado nas economias calculadas de rotas similares
                </p>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}