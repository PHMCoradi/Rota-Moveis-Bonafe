import { useMutation } from "@tanstack/react-query";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Printer, Save, Download, Share2, MapPin, AlertCircle } from "lucide-react";
import { RouteResponse } from "@shared/schema";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { brazilianConfig, formatBR } from "@/lib/locale";
import { findHolidaysInRange, formatHolidayList, extractDayAndMonth } from "@/lib/holidays";

interface RouteActionsProps {
  routeResult: RouteResponse;
}

// Função utilitária para extrair apenas o nome da cidade de um endereço completo
const extrairCidade = (endereco?: string): string => {
  // Se o endereço não foi fornecido, retorna uma string vazia
  if (!endereco) return '';
  
  // Verificar se o endereço já está no formato Cidade-UF (como "Dois Córregos-SP")
  if (endereco.includes('-') && endereco.split('-').length === 2) {
    return endereco;
  }
  
  // Tenta extrair no formato "Cidade-UF" ou "Cidade, UF"
  const cidadeComEstado = endereco.match(/([A-Za-zÀ-ÖØ-öø-ÿ\s]+)[-,]\s*([A-Z]{2})/);
  if (cidadeComEstado && cidadeComEstado[1] && cidadeComEstado[2]) {
    return cidadeComEstado[1].trim() + "-" + cidadeComEstado[2].trim();
  }
  
  // Tenta extrair somente a cidade
  const cidade = endereco.split(",")[0];
  if (cidade) {
    return cidade.trim();
  }
  
  // Se não conseguir extrair, retorna o endereço original
  return endereco;
};

export function RouteActions({ routeResult }: RouteActionsProps) {
  const { toast } = useToast();
  const [saveDialogOpen, setSaveDialogOpen] = useState(false);
  const [shareDialogOpen, setShareDialogOpen] = useState(false);
  const [routeName, setRouteName] = useState("");
  const [shareLink, setShareLink] = useState("");

  const saveRouteMutation = useMutation({
    mutationFn: async (data: { nome: string, rota: RouteResponse }) => {
      const response = await apiRequest("POST", "/api/routes/save", data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Rota salva com sucesso!",
        description: "A rota foi salva e pode ser acessada posteriormente.",
      });
      setSaveDialogOpen(false);
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Erro ao salvar rota",
        description: error instanceof Error ? error.message : "Ocorreu um erro ao salvar a rota.",
      });
    },
  });

  const handlePrint = () => {
    const printWindow = window.open('', '_blank');
    if (!printWindow) {
      toast({
        variant: "destructive",
        title: "Erro",
        description: "Não foi possível abrir uma nova janela para impressão. Verifique se o bloqueador de pop-ups está ativado.",
      });
      return;
    }
    
    // Extrair apenas as cidades dos endereços
    const origem = extrairCidade(routeResult.origem);
    const destino = extrairCidade(routeResult.destino);
    
    // Usar paradas na ordem otimizada se disponível
    let paradas: string[] = [];
    if (routeResult.optimized && routeResult.optimizedWaypointsOrder) {
      // Se a rota foi otimizada e temos a ordem otimizada, usamos essa ordem
      paradas = routeResult.optimizedWaypointsOrder.map(p => extrairCidade(p));
      console.log("Usando paradas otimizadas para impressão:", paradas);
    } else if (routeResult.paradas) {
      // Caso contrário, usamos a ordem original
      paradas = routeResult.paradas.map(p => extrairCidade(p));
      console.log("Usando paradas originais para impressão:", paradas);
    }
    
    // Obter as instruções formatadas (se disponíveis)
    const instrucoes = routeResult.instrucoes || [];
    
    // Para debug - verificar se temos paradas
    console.log("Paradas para impressão:", paradas, routeResult.paradas);
    
    // Formatação usando locale do Brasil
    const dataGerada = new Date().toLocaleDateString('pt-BR', { 
      day: '2-digit', 
      month: '2-digit', 
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
    
    // Gerando resumo detalhado da rota
    const rotaCompleta = origem ? [origem] : [];
    if (paradas && paradas.length > 0) {
      rotaCompleta.push(...paradas);
    }
    if (destino) {
      rotaCompleta.push(destino);
    }
    
    // Verificar datas e feriados
    const { dataInicioEntrega: dataInicio, dataFimEntrega: dataFim } = routeResult;
    
    // Verificar feriados nas cidades da rota se tiver datas definidas
    const feriados = (dataInicio && dataFim) 
      ? findHolidaysInRange(dataInicio, dataFim, rotaCompleta) 
      : [];
    
    printWindow.document.write(`
      <!DOCTYPE html>
      <html lang="pt-BR">
      <head>
        <title>Relatório de Rota - RotaExpress</title>
        <meta charset="UTF-8">
        <style>
          :root {
            --color-primary: #2563eb;
            --color-origin: #22c55e;
            --color-stop: #f59e0b;
            --color-destination: #ef4444;
            --color-bg: #f8fafc;
            --color-border: #e2e8f0;
            --color-text: #1e293b;
            --color-text-light: #64748b;
          }
          body { 
            font-family: 'Arial', 'Helvetica', sans-serif; 
            margin: 0; 
            padding: 20px;
            color: var(--color-text);
            background-color: var(--color-bg);
          }
          h1, h2, h3 { color: var(--color-primary); }
          h1 { 
            text-align: center; 
            font-size: 24px;
            margin-bottom: 0;
          }
          h2 { 
            font-size: 18px;
            border-bottom: 1px solid var(--color-border);
            padding-bottom: 8px;
          }
          .header { 
            margin-bottom: 30px;
            text-align: center;
          }
          .header-date {
            color: var(--color-text-light);
            font-size: 14px;
          }
          .route-map {
            margin: 30px 0;
            padding: 15px;
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
          }
          .route-overview {
            font-size: 18px;
            text-align: center;
            margin: 20px 0;
            color: var(--color-primary);
          }
          .city-list { margin: 20px 0; }
          .route-section {
            padding: 15px;
            margin-bottom: 20px;
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
          }
          .route-section-title {
            font-weight: bold;
            margin-bottom: 15px;
            display: flex;
            align-items: center;
          }
          .city-item { 
            display: flex; 
            align-items: center; 
            margin: 10px 0; 
            padding: 12px; 
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 1px 2px rgba(0,0,0,0.05);
          }
          .city-info-title {
            font-weight: bold;
            font-size: 16px;
          }
          .city-info-subtitle {
            font-size: 13px;
            color: var(--color-text-light);
          }
          .city-marker { 
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 36px; 
            height: 36px; 
            border-radius: 50%; 
            margin-right: 15px; 
            color: white; 
            font-weight: bold;
            font-size: 16px;
          }
          .origin-marker { background-color: var(--color-origin); }
          .stop-marker { background-color: var(--color-stop); }
          .destination-marker { background-color: var(--color-destination); }
          .city-info { flex-grow: 1; }
          .city-address {
            font-size: 13px;
            color: var(--color-text-light);
            margin-top: 4px;
          }
          .city-distance { 
            text-align: right; 
            color: var(--color-text-light);
            min-width: 120px;
            font-size: 14px;
          }
          .distance-value {
            font-weight: bold;
            color: var(--color-primary);
          }
          .time-value {
            color: var(--color-text);
          }
          .route-summary { 
            background-color: #e0f2fe; 
            padding: 15px; 
            border-radius: 8px; 
            margin: 20px 0; 
            text-align: center;
            font-weight: bold;
            color: var(--color-primary);
            border: 1px solid #bae6fd;
          }
          .summary-stats {
            display: flex;
            justify-content: space-around;
            margin-top: 10px;
          }
          .summary-stat {
            text-align: center;
          }
          .summary-value {
            font-size: 20px;
            color: var(--color-text);
          }
          .summary-label {
            font-size: 14px;
            color: var(--color-text-light);
            font-weight: normal;
          }
          .paradas-stats {
            text-align: left;
            border-top: 1px solid var(--color-border);
            margin-top: 15px;
            padding-top: 10px;
          }
          .paradas-title {
            font-weight: bold;
            margin-bottom: 10px;
          }
          .arrow { 
            display: block; 
            text-align: center; 
            margin: 10px 0; 
            font-size: 20px; 
            color: var(--color-text-light); 
          }
          .route-detail {
            margin-top: 40px;
          }
          .city-pair {
            margin-bottom: 30px;
            border-left: 3px solid var(--color-primary);
            padding-left: 15px;
          }
          .city-pair-title {
            font-size: 16px;
            font-weight: bold;
            margin-bottom: 10px;
          }
          .city-pair-stats {
            font-size: 14px;
            color: var(--color-text-light);
            margin-bottom: 10px;
          }
          .footer { 
            margin-top: 40px; 
            text-align: center; 
            font-size: 12px; 
            color: var(--color-text-light);
            border-top: 1px solid var(--color-border);
            padding-top: 20px;
          }
          .delivery-date-section {
            margin: 15px 0;
            padding: 12px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
          }
          .date-title {
            font-weight: bold;
            display: flex;
            align-items: center;
            margin-bottom: 10px;
            color: var(--color-primary);
          }
          .date-info {
            margin-top: 5px;
            font-size: 14px;
          }
          .holiday-section {
            margin-top: 10px;
            padding: 12px;
            background-color: #fffbeb;
            border-radius: 8px;
            border: 1px solid #fef3c7;
          }
          .holiday-title {
            color: #d97706;
            font-weight: bold;
            display: flex;
            align-items: center;
            margin-bottom: 8px;
            font-size: 15px;
          }
          .holiday-list {
            font-size: 14px;
            color: #92400e;
          }
          .holiday-item {
            margin: 5px 0;
            padding: 5px 0;
            border-bottom: 1px dashed #fde68a;
          }
          .holiday-item:last-child {
            border-bottom: none;
          }
          .holiday-date {
            display: inline-block;
            background-color: #fef3c7;
            padding: 2px 6px;
            border-radius: 4px;
            margin-right: 8px;
            font-weight: bold;
          }
          .holiday-type {
            display: inline-block;
            font-size: 11px;
            padding: 2px 6px;
            border-radius: 10px;
            background-color: #fef3c7;
            color: #92400e;
            margin-left: 5px;
          }
          .holiday-type-national {
            background-color: #fee2e2;
            color: #b91c1c;
          }
          .holiday-type-city {
            background-color: #e0f2fe;
            color: #0369a1;
          }
          @media print {
            body { 
              font-size: 12pt;
              background-color: white;
            }
            .route-section, .city-item {
              box-shadow: none;
              border: 1px solid #eee;
            }
            button { display: none; }
            .no-print { display: none; }
            .page-break { page-break-after: always; }
          }
        </style>
      </head>
      <body>
        <div class="header">
          <h1>Relatório de Rota - RotaExpress</h1>
          <div class="header-date">Gerado em: ${dataGerada}</div>
        </div>
        
        <div class="route-summary">
          <div>Resumo do Percurso</div>
          <div class="summary-stats">
            <div class="summary-stat">
              <div class="summary-value">${rotaCompleta.length} cidades</div>
              <div class="summary-label">Total de pontos</div>
            </div>
            <div class="summary-stat">
              <div class="summary-value">${routeResult.distanciaTotal}</div>
              <div class="summary-label">Distância total</div>
            </div>
            <div class="summary-stat">
              <div class="summary-value">${routeResult.tempoTotal}</div>
              <div class="summary-label">Tempo estimado</div>
            </div>
          </div>
          
          ${paradas.length > 0 ? `
          <div class="paradas-stats">
            <div class="paradas-title">Sequência da Rota:</div>
            <div>${rotaCompleta.join(' → ')}</div>
          </div>
          ` : ''}
        </div>
        
        <div class="route-section">
          <div class="route-section-title">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="mr-2"><path d="M19 9h2v12h-2a4 4 0 0 1-4-4V5a2 2 0 0 0-2-2H2"></path><circle cx="9" cy="19" r="2"></circle><circle cx="19" cy="19" r="2"></circle><circle cx="9" cy="5" r="2"></circle><line x1="9" y1="7" x2="9" y2="17"></line></svg>
            Detalhamento da Rota
          </div>
          
          <div class="city-list">
            <!-- Cidade origem -->
            <div class="city-item">
              <div class="city-marker origin-marker">O</div>
              <div class="city-info">
                <div class="city-info-title">${origem}</div>
                <div class="city-info-subtitle">Origem</div>
                <div class="city-address">${routeResult.origem}</div>
              </div>
            </div>
            
            ${paradas.length > 0 ? '<div class="arrow">↓</div>' : ''}
            
            <!-- Paradas -->
            ${paradas && paradas.length > 0 ? paradas.map((parada, idx) => `
              <div class="city-item">
                <div class="city-marker stop-marker">${idx + 1}</div>
                <div class="city-info">
                  <div class="city-info-title">${parada}</div>
                  <div class="city-info-subtitle">Parada ${idx + 1}</div>
                  <div class="city-address">${routeResult.paradas ? routeResult.paradas[idx] : ''}</div>
                </div>
                ${instrucoes[idx] ? 
                  `<div class="city-distance">
                    <div class="distance-value">${instrucoes[idx].distance}</div>
                    <div class="time-value">${instrucoes[idx].duration}</div>
                  </div>` : ''
                }
              </div>
              <div class="arrow">↓</div>
            `).join('') : ''}
            
            <!-- Destino -->
            ${routeResult.destino ? `
            <div class="city-item">
              <div class="city-marker destination-marker">D</div>
              <div class="city-info">
                <div class="city-info-title">${destino}</div>
                <div class="city-info-subtitle">Destino Final</div>
                <div class="city-address">${routeResult.destino}</div>
              </div>
              ${instrucoes.length > paradas.length ? 
                `<div class="city-distance">
                  <div class="distance-value">${instrucoes[paradas.length].distance}</div>
                  <div class="time-value">${instrucoes[paradas.length].duration}</div>
                </div>` : ''
              }
            </div>
            ` : paradas && paradas.length > 0 ? `
            <!-- Última parada como destino -->
            <div class="city-item">
              <div class="city-marker destination-marker">D</div>
              <div class="city-info">
                <div class="city-info-title">${paradas[paradas.length - 1] || ''}</div>
                <div class="city-info-subtitle">Destino (última parada)</div>
                <div class="city-address">${routeResult.paradas ? routeResult.paradas[paradas.length - 1] : ''}</div>
              </div>
            </div>
            ` : ''}
          </div>
        </div>
        
        ${dataInicio && dataFim ? `
        <div class="delivery-date-section">
          <div class="date-title">
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="margin-right: 8px">
              <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
              <line x1="16" y1="2" x2="16" y2="6"></line>
              <line x1="8" y1="2" x2="8" y2="6"></line>
              <line x1="3" y1="10" x2="21" y2="10"></line>
            </svg>
            Período de Entrega
          </div>
          <div class="date-info">
            <strong>Data Início:</strong> ${dataInicio} &nbsp; | &nbsp; <strong>Data Final:</strong> ${dataFim}
          </div>
          
          ${feriados.length > 0 ? `
          <div class="holiday-section">
            <div class="holiday-title">
              <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="margin-right: 6px">
                <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
                <line x1="16" y1="2" x2="16" y2="6"></line>
                <line x1="8" y1="2" x2="8" y2="6"></line>
                <line x1="3" y1="10" x2="21" y2="10"></line>
              </svg>
              Atenção - Feriados no período da rota:
            </div>
            <div class="holiday-list">
              ${feriados.map(feriado => {
                const { day, month } = extractDayAndMonth(feriado.date);
                const data = `${day.toString().padStart(2, '0')}/${month.toString().padStart(2, '0')}`;
                const tipo = feriado.type === 'nacional' ? 'Nacional' : feriado.type === 'estadual' ? 'Estadual' : 'Municipal';
                const cidade = feriado.location ? ` em ${feriado.location.split('-')[0]}` : '';
                return `<div class="holiday-item">
                  <span class="holiday-date">${data}</span>
                  <strong>${feriado.name}</strong>
                  <span class="holiday-type ${feriado.type === 'nacional' ? 'holiday-type-nacional' : 'holiday-type-city'}">${tipo}${cidade}</span>
                </div>`;
              }).join('')}
            </div>
          </div>
          ` : ''}
        </div>
        ` : ''}
        
        <div class="footer">
          <p>Documento gerado por RotaExpress - Calculadora de Rotas para Transportadoras © ${new Date().getFullYear()}</p>
        </div>
        
        <script>
          // Auto-print when loaded
          window.onload = function() {
            setTimeout(function() {
              window.print();
            }, 500);
          }
        </script>
      </body>
      </html>
    `);
    
    printWindow.document.close();
  };

  const handleShareRoute = () => {
    try {
      // Criar um objeto com os dados essenciais da rota para compartilhamento
      const routeData = {
        origem: routeResult.origem,
        paradas: routeResult.paradas || [],
        otimizar: routeResult.optimized || false,
        dataInicio: routeResult.dataInicioEntrega,
        dataFim: routeResult.dataFimEntrega,
        tipoVeiculo: routeResult.tipoVeiculo
      };
      
      // Converter para string JSON e depois para Base64 para ficar mais compacto
      const routeJson = JSON.stringify(routeData);
      const encodedRoute = btoa(encodeURIComponent(routeJson));
      
      // Construir o link de compartilhamento
      const baseUrl = window.location.origin;
      const shareUrl = `${baseUrl}/?rota=${encodedRoute}`;
      
      // Definir o link no estado para exibir no diálogo
      setShareLink(shareUrl);
      setShareDialogOpen(true);
      
      console.log("Link de compartilhamento gerado:", shareUrl);
    } catch (error) {
      console.error("Erro ao gerar link de compartilhamento:", error);
      toast({
        variant: "destructive",
        title: "Erro ao gerar link",
        description: "Não foi possível criar o link de compartilhamento."
      });
    }
  };
  
  const copyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(shareLink);
      toast({
        title: "Link copiado!",
        description: "O link foi copiado para a área de transferência."
      });
    } catch (error) {
      console.error("Erro ao copiar para a área de transferência:", error);
      toast({
        variant: "destructive",
        title: "Erro ao copiar",
        description: "Não foi possível copiar o link. Tente selecioná-lo manualmente."
      });
    }
  };

  const handleExportCSV = () => {
    // Formatação da data usando locale brasileiro
    const dataAtual = new Date();
    const dataFormatada = dataAtual.toLocaleDateString('pt-BR');
    
    // Extrair apenas as cidades dos endereços
    const origem = extrairCidade(routeResult.origem);
    const destino = extrairCidade(routeResult.destino);
    
    // Usar paradas na ordem otimizada se disponível
    let paradas: string[] = [];
    if (routeResult.optimized && routeResult.optimizedWaypointsOrder) {
      // Se a rota foi otimizada e temos a ordem otimizada, usamos essa ordem
      paradas = routeResult.optimizedWaypointsOrder.map(p => extrairCidade(p));
      console.log("Usando paradas otimizadas para exportação CSV:", paradas);
    } else if (routeResult.paradas) {
      // Caso contrário, usamos a ordem original
      paradas = routeResult.paradas.map(p => extrairCidade(p));
      console.log("Usando paradas originais para exportação CSV:", paradas);
    }
    
    // Endereços completos para referência
    const enderecoOrigem = routeResult.origem || '';
    const enderecoDestino = routeResult.destino || '';
    const enderecosParadas = routeResult.paradas || [];
    
    // Preparar dados
    const instrucoes = routeResult.instrucoes || [];
    
    // Cabeçalho no formato brasileiro
    let csv = "Tipo do Ponto;Cidade;Endereço Completo;Distância;Tempo Estimado;Sequência\n";
    
    // Adicionar informações da origem
    csv += `Origem;${origem};${enderecoOrigem};-;-;1\n`;
    
    // Adicionar informações de datas de entrega, se disponíveis
    if (routeResult.dataInicioEntrega && routeResult.dataFimEntrega) {
      csv = "Datas de Entrega\n" + 
            `Data Início;${routeResult.dataInicioEntrega}\n` +
            `Data Final;${routeResult.dataFimEntrega}\n` +
            "\n" + csv;
      
      // Adicionar informações sobre feriados, se houver
      const rotaCompleta = [origem, ...paradas];
      if (destino) rotaCompleta.push(destino);
      
      const feriados = findHolidaysInRange(routeResult.dataInicioEntrega, routeResult.dataFimEntrega, rotaCompleta);
      if (feriados.length > 0) {
        let feriadosStr = "Feriados no período da rota\n";
        feriadosStr += "Nome;Data;Tipo;Cidade\n";
        feriados.forEach(feriado => {
          const { day, month } = extractDayAndMonth(feriado.date);
          const data = `${day.toString().padStart(2, '0')}/${month.toString().padStart(2, '0')}`;
          const tipo = feriado.type === 'nacional' ? 'Nacional' : feriado.type === 'estadual' ? 'Estadual' : 'Municipal';
          const cidade = feriado.location ? feriado.location.split('-')[0] : 'Todas as cidades';
          feriadosStr += `${feriado.name};${data};${tipo};${cidade}\n`;
        });
        csv = feriadosStr + "\n" + csv;
      }
    }
    
    // Adicionar informações das paradas
    if (paradas.length > 0) {
      for (let i = 0; i < paradas.length; i++) {
        const distancia = i < instrucoes.length ? instrucoes[i].distance : '-';
        const tempo = i < instrucoes.length ? instrucoes[i].duration : '-';
        
        csv += `Parada;${paradas[i]};${enderecosParadas[i]};${distancia};${tempo};${i + 2}\n`;
      }
    }
    
    // Adicionar informações do destino
    if (routeResult.destino) {
      const distanciaDestino = instrucoes.length > paradas.length ? 
        instrucoes[paradas.length].distance : routeResult.distanciaTotal;
      const tempoDestino = instrucoes.length > paradas.length ? 
        instrucoes[paradas.length].duration : routeResult.tempoTotal;
      
      csv += `Destino;${destino};${enderecoDestino};${distanciaDestino};${tempoDestino};${paradas.length + 2}\n`;
    } else if (paradas && paradas.length > 0) {
      // Use a última parada como destino
      const ultimaParada = paradas[paradas.length - 1];
      const ultimoEnderecoParada = enderecosParadas[paradas.length - 1];
      csv += `Destino (última parada);${ultimaParada};${ultimoEnderecoParada};-;-;${paradas.length + 1}\n`;
    }
    
    // Calcular o número total de pontos na rota
    let totalPontos = 1; // Começa com 1 (origem)
    totalPontos += paradas.length; // Adiciona as paradas
    if (routeResult.destino) totalPontos += 1; // Adiciona o destino se existir
    
    // Linha final com totais
    csv += `\nTOTAL DA ROTA;;Pontos: ${totalPontos};${routeResult.distanciaTotal};${routeResult.tempoTotal};\n`;
    
    // Criar arquivo para download
    // Nota: O separador ';' é mais comum no Brasil do que ',' para CSVs
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `rota_${dataFormatada.replace(/\//g, '-')}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    toast({
      title: "Relatório exportado",
      description: "O arquivo CSV foi baixado com sucesso no formato brasileiro.",
    });
  };

  const handleSaveRoute = () => {
    saveRouteMutation.mutate({
      nome: routeName.trim() || `Rota ${new Date().toLocaleDateString('pt-BR')}`,
      rota: routeResult
    });
  };

  return (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold">Ações</h3>
      
      <div className="grid grid-cols-2 gap-2">
        <Button 
          variant="outline" 
          onClick={handlePrint}
          className="flex items-center justify-center"
        >
          <Printer className="mr-2 h-4 w-4" />
          Imprimir
        </Button>
        
        <Button 
          variant="outline" 
          onClick={handleExportCSV}
          className="flex items-center justify-center"
        >
          <Download className="mr-2 h-4 w-4" />
          Exportar CSV
        </Button>
        
        <Dialog open={shareDialogOpen} onOpenChange={setShareDialogOpen}>
          <DialogTrigger asChild>
            <Button 
              variant="outline" 
              onClick={handleShareRoute}
              className="flex items-center justify-center"
            >
              <Share2 className="mr-2 h-4 w-4" />
              Compartilhar
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Compartilhar Rota</DialogTitle>
              <DialogDescription>
                Compartilhe esta rota enviando o link abaixo.
              </DialogDescription>
            </DialogHeader>
            
            <div className="py-4">
              <Label htmlFor="shareLink">Link de Compartilhamento</Label>
              <div className="flex mt-2">
                <Input 
                  id="shareLink" 
                  value={shareLink} 
                  readOnly
                  className="flex-1 pr-12 font-mono text-sm"
                />
                <Button 
                  className="ml-2" 
                  onClick={copyToClipboard}
                  variant="secondary"
                >
                  Copiar
                </Button>
              </div>
              <p className="text-sm text-muted-foreground mt-2">
                Este link contém todos os dados da sua rota, incluindo origem, paradas e datas.
              </p>
            </div>
            
            <DialogFooter>
              <Button 
                variant="outline" 
                onClick={() => setShareDialogOpen(false)}
              >
                Fechar
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
        
        <Dialog open={saveDialogOpen} onOpenChange={setSaveDialogOpen}>
          <DialogTrigger asChild>
            <Button 
              variant="outline" 
              className="flex items-center justify-center"
            >
              <Save className="mr-2 h-4 w-4" />
              Salvar Rota
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Salvar Rota</DialogTitle>
              <DialogDescription>
                Salve esta rota para acessá-la facilmente no futuro.
              </DialogDescription>
            </DialogHeader>
            
            <div className="py-4">
              <Label htmlFor="routeName">Nome da Rota</Label>
              <Input 
                id="routeName" 
                value={routeName} 
                onChange={(e) => setRouteName(e.target.value)}
                placeholder="Ex: Entrega Semanal"
              />
            </div>
            
            <DialogFooter>
              <Button 
                variant="outline" 
                onClick={() => setSaveDialogOpen(false)}
              >
                Cancelar
              </Button>
              <Button 
                onClick={handleSaveRoute}
                disabled={saveRouteMutation.isPending}
                className="transportadora-primary"
              >
                {saveRouteMutation.isPending ? "Salvando..." : "Salvar"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}
