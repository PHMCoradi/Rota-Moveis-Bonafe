import React, { useEffect, useState } from "react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Calendar, MapPin, Info, AlertCircle, Gift, PartyPopper } from "lucide-react";
import { Separator } from "@/components/ui/separator";
import { findHolidaysInRange } from "@/lib/holidays";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { extractCityAndStateFromAddress } from "@/lib/holidays";
import { CityAnniversaryButton } from "./CityAnniversaryButton";
import { CityAnniversaryPopup } from "./CityAnniversaryPopup";
import { getCityTrivia } from "@/lib/cityTrivia";

interface PeriodEvent {
  date: string;
  name: string;
  type: 'nacional' | 'estadual' | 'municipal' | 'aniversario';
  location?: string;
  description?: string;
}

interface PeriodEventsProps {
  origem: string;
  paradas: string[];
  destino?: string;
  dataInicioEntrega?: string;
  dataFimEntrega?: string;
}

export function PeriodEvents({ 
  origem, 
  paradas, 
  destino, 
  dataInicioEntrega,
  dataFimEntrega 
}: PeriodEventsProps) {
  const [eventos, setEventos] = useState<PeriodEvent[]>([]);
  const [cidadesNaRota, setCidadesNaRota] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);
  const [showCityAnniversaryPopup, setShowCityAnniversaryPopup] = useState(false);
  const [currentCity, setCurrentCity] = useState('');
  const [anniversaryDate, setAnniversaryDate] = useState('');
  const [selectedEventType, setSelectedEventType] = useState<'aniversario' | 'municipal' | null>(null);
  const [selectedCityEvents, setSelectedCityEvents] = useState<PeriodEvent[]>([]);

  // Função para formatar a data no formato DD/MM/YYYY
  const formatDate = (date: string): string => {
    const year = new Date().getFullYear();
    return `${date}/${year}`;
  };

  useEffect(() => {
    // Função para extrair cidades da rota
    const extrairCidades = () => {
      setLoading(true);
      const todasParadas = [origem, ...paradas];
      if (destino && !paradas.includes(destino)) {
        todasParadas.push(destino);
      }

      // Extrair nomes de cidades de cada parada
      const cidades = todasParadas
        .map(endereco => {
          // Verificar se é um CEP
          if (/^\d{5}-?\d{3}$/.test(endereco.trim())) {
            // Mapeamento de CEPs conhecidos para cidades
            if (endereco.startsWith('14') && !endereco.startsWith('140')) {
              return "Ribeirão Preto-SP";
            } else if (endereco.startsWith('17')) {
              return "Bauru-SP";
            } else if (endereco.startsWith('13')) {
              return "Campinas-SP";
            } else if (endereco.startsWith('01') || endereco.startsWith('02') || 
                      endereco.startsWith('03') || endereco.startsWith('04') || 
                      endereco.startsWith('05') || endereco.startsWith('06') || 
                      endereco.startsWith('07') || endereco.startsWith('08')) {
              return "São Paulo-SP";
            }
            // CEP específico de Dois Córregos
            else if (endereco.startsWith('17300')) {
              return "Dois Córregos-SP";
            }
            // Rua Arnaldo Victaliano
            else if (endereco.startsWith('14091')) {
              return "Ribeirão Preto-SP";
            }
          }
          
          // Alguns endereços específicos
          if (endereco.toLowerCase().includes('arnaldo victaliano')) {
            return "Ribeirão Preto-SP";
          } else if (endereco.toLowerCase().includes('botafogo') && endereco.toLowerCase().includes('vila coradi')) {
            return "Dois Córregos-SP";
          }
          
          // Caso padrão: extrair da função comum
          const cidadeInfo = extractCityAndStateFromAddress(endereco);
          return cidadeInfo.uf ? `${cidadeInfo.cidade}-${cidadeInfo.uf}` : cidadeInfo.cidade || '';
        })
        .filter(cidade => cidade) // Remove valores vazios
        .filter((cidade, index, self) => 
          // Remover duplicatas
          index === self.findIndex(c => c === cidade)
        );

      // Mantém lista de cidades para exibição
      setCidadesNaRota(cidades);
      
      // Verificar eventos no período se tiver datas
      if (dataInicioEntrega && dataFimEntrega) {
        console.log(`Verificando eventos no período de ${dataInicioEntrega} a ${dataFimEntrega} para cidades:`, cidades);
        
        const eventosEncontrados = findHolidaysInRange(
          dataInicioEntrega,
          dataFimEntrega,
          cidades
        );
        
        setEventos(eventosEncontrados);
      } else {
        setEventos([]);
      }
      
      setLoading(false);
    };

    extrairCidades();
  }, [origem, paradas, destino, dataInicioEntrega, dataFimEntrega]);

  // Se não tiver paradas ou origem, não mostra nada
  if (!origem && paradas.length === 0) {
    return null;
  }

  // Se não tiver datas, não mostra nada
  if (!dataInicioEntrega || !dataFimEntrega) {
    return null;
  }
  
  // Agrupar eventos por tipo
  const eventosPorTipo = {
    nacional: eventos.filter(evento => evento.type === 'nacional'),
    estadual: eventos.filter(evento => evento.type === 'estadual'),
    municipal: eventos.filter(evento => evento.type === 'municipal'),
    aniversario: eventos.filter(evento => evento.type === 'aniversario')
  };

  // Verificar se temos eventos para mostrar
  const temEventos = eventos.length > 0;
  
  // Lidar com o clique no botão de aniversário da cidade
  const handleShowCityAnniversary = (cidade: string, data: string, tipo: 'aniversario' | 'municipal' = 'aniversario') => {
    // Limpar o nome da cidade (remover UF se presente)
    const nomeCidade = cidade.split('-')[0].trim();
    setCurrentCity(nomeCidade);
    setAnniversaryDate(data);
    setSelectedEventType(tipo);
    
    // Se for municipal, pegar todas os eventos municipais da cidade
    if (tipo === 'municipal') {
      const eventosMunicipais = eventos.filter(evento => 
        evento.type === 'municipal' && 
        evento.location && 
        evento.location.toLowerCase().includes(nomeCidade.toLowerCase())
      );
      setSelectedCityEvents(eventosMunicipais);
    }
    
    // Mostrar o popup
    setShowCityAnniversaryPopup(true);
  };
  
  // Função para renderizar botões de eventos para cada cidade
  const renderCityEventButtons = () => {
    // Agrupar eventos por cidade
    const cidadesComEventos = new Map<string, { aniversarios: PeriodEvent[], municipais: PeriodEvent[] }>();
    
    // Organizar eventos por cidade
    eventos.forEach(evento => {
      if (!evento.location) return;
      
      if (!cidadesComEventos.has(evento.location)) {
        cidadesComEventos.set(evento.location, { aniversarios: [], municipais: [] });
      }
      
      const eventosDestaCidade = cidadesComEventos.get(evento.location)!;
      
      if (evento.type === 'aniversario') {
        eventosDestaCidade.aniversarios.push(evento);
      } else if (evento.type === 'municipal') {
        eventosDestaCidade.municipais.push(evento);
      }
    });
    
    // Se não há cidades com eventos, retorna null
    if (cidadesComEventos.size === 0) return null;
    
    return (
      <div className="mt-4 space-y-2">
        <h4 className="text-sm font-medium flex items-center">
          <Gift className="h-4 w-4 mr-2 text-amber-500" />
          Eventos Especiais por Cidade
        </h4>
        
        <div className="flex flex-wrap gap-2">
          {Array.from(cidadesComEventos).map(([cidade, { aniversarios, municipais }]) => (
            <div key={cidade} className="flex flex-col space-y-1">
              {aniversarios.length > 0 && (
                <Button 
                  variant="outline" 
                  size="sm"
                  className="bg-amber-50 border-amber-200 text-amber-700 hover:bg-amber-100"
                  onClick={() => handleShowCityAnniversary(cidade, aniversarios[0].date, 'aniversario')}
                >
                  <PartyPopper className="h-3 w-3 mr-1" />
                  {cidade.split('-')[0]} ({aniversarios[0].date})
                </Button>
              )}
              
              {municipais.length > 0 && (
                <Button 
                  variant="outline" 
                  size="sm"
                  className="bg-blue-50 border-blue-200 text-blue-700 hover:bg-blue-100"
                  onClick={() => handleShowCityAnniversary(cidade, municipais[0].date, 'municipal')}
                >
                  <Calendar className="h-3 w-3 mr-1" />
                  Feriados {cidade.split('-')[0]} ({municipais.length})
                </Button>
              )}
            </div>
          ))}
        </div>
      </div>
    );
  };

  return (
    <>
      <Card className="mt-4 border border-blue-200 bg-blue-50">
        <CardHeader className="pb-2">
          <CardTitle className="text-lg flex items-center gap-2">
            <Calendar className="h-5 w-5 text-blue-600" /> Eventos no Período
          </CardTitle>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="py-2 text-center text-sm text-gray-500">
              Verificando eventos...
            </div>
          ) : temEventos ? (
            <div className="space-y-2">
              <Alert className="bg-blue-100 border-blue-300">
                <Info className="h-4 w-4 text-blue-600" />
                <AlertTitle>Eventos durante o período de entrega</AlertTitle>
                <AlertDescription>
                  Existem {eventos.length} eventos nas cidades da rota entre {dataInicioEntrega} e {dataFimEntrega}.
                </AlertDescription>
              </Alert>
              
              <ScrollArea className="h-[300px]">
                <Accordion type="single" collapsible className="w-full">
                  {Object.entries(eventosPorTipo)
                    .filter(([_, listaEventos]) => listaEventos.length > 0)
                    .map(([tipo, listaEventos], index) => (
                      <AccordionItem key={tipo} value={`tipo-${index}`}>
                        <AccordionTrigger className="py-2 px-3 hover:bg-blue-100 text-blue-800 font-medium">
                          {tipo === 'nacional' ? 'Feriados Nacionais' : 
                           tipo === 'estadual' ? 'Feriados Estaduais' : 
                           tipo === 'municipal' ? 'Feriados Municipais' : 
                           'Aniversários de Cidades'} ({listaEventos.length})
                        </AccordionTrigger>
                        <AccordionContent className="px-3 pb-3 bg-white rounded-md">
                          <div className="space-y-3">
                            {listaEventos.map((evento, i) => (
                              <div key={i} className="border-b pb-2 text-gray-700">
                                <div className="flex gap-2 items-start">
                                  <Calendar className="h-4 w-4 text-blue-600 mt-1" />
                                  <div>
                                    <h4 className="font-medium">{evento.name}</h4>
                                    <div className="text-sm flex flex-wrap gap-2 mt-1">
                                      <Badge variant="outline" className="bg-blue-50">
                                        {evento.date}
                                      </Badge>
                                      {evento.location && (
                                        <Badge variant="outline" className="bg-blue-50">
                                          {evento.location}
                                        </Badge>
                                      )}
                                    </div>
                                    {evento.description && (
                                      <p className="text-sm mt-1 text-gray-600">{evento.description}</p>
                                    )}
                                  </div>
                                </div>
                              </div>
                            ))}
                          </div>
                        </AccordionContent>
                      </AccordionItem>
                    ))}
                </Accordion>
              </ScrollArea>
              
              {/* Botões para eventos especiais por cidade */}
              {renderCityEventButtons()}
            </div>
          ) : (
            <div className="py-2 text-gray-700">
              <Alert className="bg-green-50 border-green-200">
                <Info className="h-4 w-4 text-green-600" />
                <AlertTitle>Nenhum evento no período</AlertTitle>
                <AlertDescription>
                  Não foram encontrados feriados ou eventos especiais nas cidades da sua rota durante o período de entrega.
                  <div className="mt-2">
                    <span className="text-xs text-gray-600">Cidades verificadas:</span>
                    <div className="flex flex-wrap gap-1 mt-1">
                      {cidadesNaRota.map((cidade, i) => (
                        <Badge key={i} variant="outline" className="bg-white">{cidade}</Badge>
                      ))}
                    </div>
                  </div>
                </AlertDescription>
              </Alert>
              <p className="text-xs mt-3 text-gray-500">
                Período verificado: {dataInicioEntrega} a {dataFimEntrega}
              </p>
            </div>
          )}
        </CardContent>
      </Card>
      
      {/* Pop-up de aniversário de cidade (fora do card principal para não fechar) */}
      {showCityAnniversaryPopup && selectedEventType === 'aniversario' && (
        <CityAnniversaryPopup 
          city={currentCity} 
          date={anniversaryDate} 
          onClose={() => setShowCityAnniversaryPopup(false)} 
        />
      )}
      
      {/* Pop-up de feriados municipais (fora do card principal para não fechar) */}
      {showCityAnniversaryPopup && selectedEventType === 'municipal' && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg shadow-lg max-w-md w-full max-h-[80vh] overflow-y-auto">
            <div className="p-5">
              <div className="flex justify-between items-start mb-4">
                <h3 className="text-lg font-semibold text-gray-900 flex items-center">
                  <Calendar className="h-5 w-5 mr-2 text-blue-600" />
                  Feriados Municipais de {currentCity}
                </h3>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  onClick={() => setShowCityAnniversaryPopup(false)}
                  className="h-8 w-8 p-0 rounded-full"
                >
                  <span className="sr-only">Fechar</span>
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-x"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>
                </Button>
              </div>
              
              <div className="text-sm text-gray-600 mb-4">
                Feriados oficiais da cidade durante o período da sua entrega
              </div>
              
              <div className="space-y-3">
                {selectedCityEvents.map((event, index) => (
                  <div key={index} className="border-b border-gray-200 pb-3">
                    <h4 className="font-medium text-gray-900">{event.name}</h4>
                    <div className="mt-1 flex items-center gap-1 text-sm text-gray-600">
                      <Calendar className="h-3 w-3" /> {event.date}
                    </div>
                    {event.description && (
                      <p className="mt-1 text-sm text-gray-700">{event.description}</p>
                    )}
                  </div>
                ))}
              </div>
              
              {/* Informações adicionais sobre a cidade */}
              <div className="mt-4 pt-3 border-t border-gray-200">
                <p className="text-xs text-gray-500">
                  Verifique possíveis alterações no funcionamento do comércio local nestas datas.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}