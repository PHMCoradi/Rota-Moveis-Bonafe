import { pgTable, text, serial, integer, boolean, json, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Usuario da transportadora
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  nome: text("nome"),
  empresa: text("empresa"),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  nome: true,
  empresa: true,
});

// Rotas calculadas
export const routes = pgTable("routes", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  nome: text("nome").notNull(),
  origem: text("origem").notNull(),
  destino: text("destino").notNull(),
  paradas: json("paradas").$type<string[]>().default([]),
  distanciaTotal: text("distancia_total"),
  tempoTotal: text("tempo_total"),
  dataCriacao: timestamp("data_criacao").defaultNow(),
  rotaJSON: json("rota_json").$type<any>(),
});

export const insertRouteSchema = createInsertSchema(routes).omit({
  id: true,
  dataCriacao: true,
});

// Waypoints - pontos de parada
export const waypoints = pgTable("waypoints", {
  id: serial("id").primaryKey(),
  routeId: integer("route_id").references(() => routes.id),
  endereco: text("endereco").notNull(),
  ordem: integer("ordem").notNull(),
});

export const insertWaypointSchema = createInsertSchema(waypoints).omit({
  id: true,
});

// Define tipos
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertRoute = z.infer<typeof insertRouteSchema>;
export type Route = typeof routes.$inferSelect;

export type InsertWaypoint = z.infer<typeof insertWaypointSchema>;
export type Waypoint = typeof waypoints.$inferSelect;

// Tipo de veículo para cálculo de pedágio
export const vehicleTypes = [
  "carro", // Carro de passeio
  "moto", // Motocicleta
  "caminhao", // Caminhão (genérico)
  "caminhao_2_eixos", // Caminhão 2 eixos
] as const;

export type VehicleType = typeof vehicleTypes[number];

// Esquema para requisição de cálculo de rota
export const routeRequestSchema = z.object({
  origem: z.string().min(1, "A origem é obrigatória"),
  paradas: z.array(z.string()).optional(),
  nome: z.string().optional(),
  otimizar: z.union([z.boolean(), z.string(), z.number()]).transform(val => {
    // Conversão mais estrita e explícita para booleano primitivo
    if (typeof val === 'string') {
      return val.toLowerCase() === 'true';
    } else if (typeof val === 'number') {
      return val === 1;
    } else if (typeof val === 'object' && val !== null) {
      // Se for um objeto (por exemplo, um objeto booleano do React), converter para primitivo
      return !!val;
    }
    // Se já for um booleano, garantir que seja um primitivo
    return val === true;
  }).default(true), // Por padrão, a otimização está ativada
  dataInicioEntrega: z.string().optional(), // Data inicial de entrega (opcional)
  dataFimEntrega: z.string().optional(),    // Data final de entrega (opcional)
  tipoVeiculo: z.enum(vehicleTypes).default("caminhao_2_eixos"), // Tipo de veículo para cálculo de pedágio
});

export type RouteRequest = z.infer<typeof routeRequestSchema>;

// Esquema para instruções de rota
export const routeInstructionSchema = z.object({
  summary: z.string(),
  distance: z.string(),
  duration: z.string(),
  steps: z.array(
    z.object({
      instruction: z.string(),
      distance: z.string(),
      duration: z.string(),
    })
  ),
});

// Esquema para resposta de rota
// Definição do schema para pedágios e balanças no percurso
export const routePOISchema = z.object({
  tipo: z.enum(['tollbooth', 'weighingstation']),
  nome: z.string(),
  posicao: z.tuple([z.number(), z.number()]),
  detalhe: z.string().optional(),
  valor: z.string().optional(),
  naRota: z.boolean().optional(), // Indica se o ponto está na rota (true) ou apenas próximo
});

// Schema para rotas alternativas
export const rotaAlternativaSchema = z.object({
  polyline: z.string(), // Geometria da rota
  distancia: z.string(), // Distância formatada
  tempo: z.string(),     // Tempo formatado
  distanciaNumerica: z.number(), // Valor numérico para comparação
  tempoNumerico: z.number(),     // Valor numérico para comparação
  destaque: z.boolean().optional(), // Se esta é a rota principal
});

export const routeResponseSchema = z.object({
  distanciaTotal: z.string(),
  tempoTotal: z.string(),
  rota: z.any(),
  origem: z.string(),
  destino: z.string().optional(), // Destino agora é opcional na resposta também
  paradas: z.array(z.string()).optional(),
  instrucoes: z.array(routeInstructionSchema).optional(),
  optimized: z.boolean().optional(),
  originalWaypointsOrder: z.array(z.string()).optional(),
  optimizedWaypointsOrder: z.array(z.string()).optional(),
  dataInicioEntrega: z.string().optional(), // Data inicial de entrega (opcional)
  dataFimEntrega: z.string().optional(),    // Data final de entrega (opcional)
  valorPedagios: z.string().optional(), // Valor total de pedágios na rota
  tipoVeiculo: z.enum(vehicleTypes).optional(), // Tipo de veículo usado para calcular o pedágio
  pontosInteresse: z.array(routePOISchema).optional(), // Pedágios e balanças no percurso
  rotasAlternativas: z.array(rotaAlternativaSchema).optional(), // Rotas alternativas
});

export type RouteInstruction = z.infer<typeof routeInstructionSchema>;
export type RoutePointOfInterest = z.infer<typeof routePOISchema>;
export type RouteAlternative = z.infer<typeof rotaAlternativaSchema>;
export type RouteResponse = z.infer<typeof routeResponseSchema>;

// Tabela para armazenar os CEPs
export const ceps = pgTable('ceps', {
  id: serial('id').primaryKey(),
  cep: text('cep').notNull().unique(),
  logradouro: text('logradouro').notNull(),
  bairro: text('bairro'),
  cidade: text('cidade').notNull(),
  estado: text('estado').notNull(),
  latitude: text('latitude'),
  longitude: text('longitude'),
});

// Schemas Zod para validação
export const insertCepSchema = createInsertSchema(ceps).omit({
  id: true,
});

export type InsertCep = z.infer<typeof insertCepSchema>;
export type Cep = typeof ceps.$inferSelect;
